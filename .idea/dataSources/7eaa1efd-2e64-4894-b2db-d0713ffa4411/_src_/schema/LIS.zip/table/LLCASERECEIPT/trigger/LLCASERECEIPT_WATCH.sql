CREATE TRIGGER LLCASERECEIPT_WATCH
AFTER DELETE
  ON LLCASERECEIPT
FOR EACH ROW
  declare
  ip varchar2(20);
  currtime date;
begin
  select SYSDATE into currtime from dual;
 select sys_context('userenv','ip_address') into ip from dual ;
 insert into llcasereceiptwatch values (ip, :old.clmno, :old.feeitemcode,'llcasereceipt',currtime);
end llcasereceipt_watch;
/
