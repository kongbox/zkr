CREATE TRIGGER TRIGGER_LCGRPCONT
AFTER INSERT OR UPDATE
  ON LCGRPCONT
FOR EACH ROW
  BEGIN
   IF (:new.peoples2 is  null or :new.peoples2='') then
     RAISE_APPLICATION_ERROR(-20001, 'peoples2 为空 或 peoples2 为 null');
  END IF;
END;
/
