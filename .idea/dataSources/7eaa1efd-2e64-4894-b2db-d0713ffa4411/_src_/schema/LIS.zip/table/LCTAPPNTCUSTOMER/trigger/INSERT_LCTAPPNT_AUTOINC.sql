CREATE TRIGGER INSERT_LCTAPPNT_AUTOINC
BEFORE INSERT
  ON LCTAPPNTCUSTOMER
FOR EACH ROW
  begin
            select lctappntcustomer_autoinc.nextval into :new.Id from dual;
          end;
/
