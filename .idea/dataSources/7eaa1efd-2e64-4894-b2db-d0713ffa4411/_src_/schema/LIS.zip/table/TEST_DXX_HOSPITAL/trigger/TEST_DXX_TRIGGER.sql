CREATE TRIGGER TEST_DXX_TRIGGER
BEFORE INSERT
  ON TEST_DXX_HOSPITAL
FOR EACH ROW
  declare
    nextid number;
  begin
    IF:new.hoscode IS NULL or :new.hoscode=0 THEN
    select test_dxx_sequence.nextval
    into nextid
    from sys.dual;
    :new.hoscode:=nextid;
    end if;
    end test_dxx_trigger;
/
