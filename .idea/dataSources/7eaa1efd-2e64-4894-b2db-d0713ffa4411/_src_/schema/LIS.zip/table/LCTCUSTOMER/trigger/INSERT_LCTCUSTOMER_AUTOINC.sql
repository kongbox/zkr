CREATE TRIGGER INSERT_LCTCUSTOMER_AUTOINC
BEFORE INSERT
  ON LCTCUSTOMER
FOR EACH ROW
  begin
               select lctcustomer_autoinc.nextval into :new.Id from dual;
          end;
/
