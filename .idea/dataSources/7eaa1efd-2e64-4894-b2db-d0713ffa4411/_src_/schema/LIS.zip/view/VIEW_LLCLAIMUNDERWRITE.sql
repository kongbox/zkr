CREATE VIEW VIEW_LLCLAIMUNDERWRITE AS select clmNo, riskcode from llclaimunderwrite   where clmNo in(select clmNo from llclaim where clmstate in('2','3'))
/
