CREATE VIEW VATDISTILLCLASS0000020 AS select '0000020' as classid,
       (select l.grpcontno from lcgrppol l where l.grppolno = a.GrpPolNo) grpcontno,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.EndorsementNo,
       (select l.riskcode from lcgrppol l where l.grppolno = a.GrpPolNo) riskcode,
       (select l.cvalidate from lcgrppol l where l.grppolno = a.GrpPolNo) cvalidate,
       a.edorvalidate,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.makedate,
       a.GetConfirmDate,
       a.EnterAccDate,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype
  from grppolljagetendorse a
 where a.FeeOperationType not in
       ('ZT', '01', 'CT', '08', 'LT', 'RT', 'FT', 'WT', 'RD', 'CR', 'XT', 'MT')
   and a.FeeFinaType in ('TB', 'TF')
--屏蔽定期寿险
   AND not  EXISTS (SELECT 1 FROM LMRiskApp app WHERE app.risktype4 = '3' AND app.risktype2 = 'L'
   AND app.riskcode = (SELECT l.riskcode FROM lcgrppol l WHERE l.grppolno = a.GrpPolNo))
   and a.getmoney < 0
   and not exists (select 'X'
          from Lpgrpedormain b
         where b.edoracceptno = a.endorsementno
           and b.balaflag = '0')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000020'
           and i.flag = '1'
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))
/
