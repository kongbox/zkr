CREATE VIEW SMPRODUCT_V AS select
  NamedObject_ID_sequenceID_ id,
  Product_ownerID_ ownerID,
  Product_ownerType_ ownerType,
  Product_productID_ productID,
  Product_dependencies_ dependencies,
  Product_sharable_ sharable,
  Product_selected_ selected,
  Product_prdFile_ prdfile
from SMproduct_s
/
