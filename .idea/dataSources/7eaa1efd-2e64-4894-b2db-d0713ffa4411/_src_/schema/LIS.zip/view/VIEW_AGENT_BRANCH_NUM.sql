CREATE VIEW VIEW_AGENT_BRANCH_NUM AS ( select count(*) branch_num,founddate,branchtype     from labranchgroup    group by founddate,branchtype)
/
