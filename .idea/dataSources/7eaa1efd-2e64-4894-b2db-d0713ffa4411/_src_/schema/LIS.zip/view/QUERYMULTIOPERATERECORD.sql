CREATE VIEW QUERYMULTIOPERATERECORD AS select la.rgtno,
       la.mngcom,
       la.caseno,
     (  la.clmno || la.customerno) subcase,
       la.customerno,
       (select name
          from lcinsured
         where '1509441713000' = '1509441713000'
           and insuredno = la.customerno
           and contno = la.contno) name,
       (select nvl(sum(standpay), 0)
          from llclaimdetail
         where clmno = la.caseno
           and polno = b.polno
           and caserelano = b.caserelano
           and getdutykind = b.getdutykind
           and givetype = '0') standpay,
       la.endcasedate,
       b.appntname,
       b.grpcontno,
       (select riskname from lmrisk where riskcode = b.riskcode) riskname,
       (select diagnose || icdname
          from llaccidentbill
         where 1 = 1
           and subrptno = la.clmno || la.customerno
           and rownum = '1') diagnosename,
       (select nvl(sum(realpay), 0)
          from llclaimdetail
         where clmno = la.caseno
           and polno = b.polno
           and caserelano = b.caserelano
           and getdutykind = b.getdutykind
           and givetype = '0')realpay,
       case
         when exists (select 'X'
                 from LLClaimUWMain
                where clmno = la.clmno
                  and insuredno = la.customerno
                  and auditconclusion = '1') then
          '拒付'
         else
          decode(la.ClmState, '80', '拒付', '70', '拒付', '给付')
       END ClmStatedesc,
       (SELECT codename
          FROM ldcode
         where codetype = 'llrgtnature'
           AND code = (SELECT e.RgtNature
                         FROM llcase e
                        where e.caseno = la.clmno
                          and e.customerno = la.customerno)) RgtNature,
       (SELECT ld.codename
          FROM LLClaimUWMain aa, ldcode ld
         where aa.clmno = la.clmno
           and aa.insuredno = la.customerno
           AND ld.codetype = 'llclaimconclusion'
           AND ld.code = aa.AuditConclusion) AuditConclusion,
       (select DECODE((select count(1)
                        from LLClaimUWAppeal ll
                       where ll.clmno = la.clmno
                         and ll.insuredno = la.customerno),
                      '0',
                      '无',
                      '有')
          from dual) AppealCon,
       CASE
         WHEN (SELECT count(1)
                 FROM LLClaimUWMain s
                where s.clmno = la.clmno
                  AND s.insuredno = la.customerno
                  AND S.specialremark is not null) > 0 THEN
          '有'
         ELSE
          CASE
         WHEN (SELECT count(1)
                 FROM lbmission sn
                where sn.missionprop1 = la.clmno || la.customerno
                  AND sn.activityid = '0000005696') > 1 THEN
          '有'
         ELSE
          '无'
       END END uwmain,
       createReport.createReport_time,
       scanReport.scanReport_time,
       billReport.billReport_time,
       checkReport.checkReport_time,
       recheckReport.recheckReport_time,
       endReport.endReport_time,
       inqReport.inqReport_time
  from llclaim la
  join llclaimpolicy b on la.clmno = b.clmno
                      and la.customerno = b.insuredno
                      and la.contno = b.contno
  join lcgrpcont c on b.grpcontno = c.grpcontno
  left join (select d.caseno,
                    d.customerno,
                    row_number() over(partition by d.caseno, d.customerno order by d.operatecount desc) as rt
               from lloperaterecord d
              where d.stateid = '100') d1 on la.caseno = d1.caseno
                                         AND la.customerno = d1.customerno
                                         AND d1.rt = 1
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) createReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '20') createReport on d1.caseno = createReport.caseno
                                        AND d1.customerno = createReport.customerno
                                        AND createReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) scanReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '30') scanReport on d1.caseno = scanReport.caseno
                                        AND d1.customerno = scanReport.customerno
                                        AND scanReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) billReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '50') billReport on d1.caseno = billReport.caseno
                                        AND d1.customerno = billReport.customerno
                                        AND billReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) checkReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '80') checkReport on d1.caseno = checkReport.caseno
                                        AND d1.customerno = checkReport.customerno
                                        AND checkReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) recheckReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '100') recheckReport on d1.caseno = recheckReport.caseno
                                         AND d1.customerno = recheckReport.customerno
                                         AND recheckReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) endReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '150') endReport on d1.caseno = endReport.caseno
                                         AND d1.customerno = endReport.customerno
                                         AND endReport.rt = '1'
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) inqReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '230') inqReport on d1.caseno = inqReport.caseno
                                         AND d1.customerno = inqReport.customerno
                                         AND inqReport.rt = '1'
 where 1 = 1
   and la.clmstate in ('60', '70', '80')
/
