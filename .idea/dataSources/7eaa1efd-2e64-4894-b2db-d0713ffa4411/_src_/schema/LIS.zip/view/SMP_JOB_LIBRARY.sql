CREATE VIEW SMP_JOB_LIBRARY AS select owner, libname, jobname, destinationtype, jobid
  from smp_job_library_ where user = owner WITH CHECK OPTION
/
