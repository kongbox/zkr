CREATE VIEW VIEW_LABRANCHGROUP AS SELECT Name,ManageCom,BranchLevel,BranchAttr,AgentGroup,UpBranch  	FROM  	LABranchGroup
/
