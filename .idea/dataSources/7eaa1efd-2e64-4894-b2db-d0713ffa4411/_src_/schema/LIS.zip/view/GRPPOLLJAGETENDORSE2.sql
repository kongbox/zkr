CREATE VIEW GRPPOLLJAGETENDORSE2 AS select ActuGetNo as ActuGetNo, EndorsementNo as EndorsementNo,ManageCom as ManageCom, FeeOperationType as FeeOperationType, FeeFinaType as FeeFinaType,
GrpPolNo as GrpPolNo, EnterAccDate as EnterAccDate,GetConfirmDate as GetConfirmDate,MakeDate as MakeDate,SubFeeOperationType,sum(GetMoney) as GetMoney from LJAGetEndorse
where grpcontno != '00000000000000000000'
group by  ActuGetNo , EndorsementNo ,ManageCom, FeeOperationType,
FeeFinaType ,  GrpPolNo , EnterAccDate,GetConfirmDate ,MakeDate,SubFeeOperationType
/
