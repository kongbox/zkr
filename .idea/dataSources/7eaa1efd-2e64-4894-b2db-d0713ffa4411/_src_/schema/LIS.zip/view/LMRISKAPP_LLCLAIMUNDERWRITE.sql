CREATE VIEW LMRISKAPP_LLCLAIMUNDERWRITE AS select realpay  from llclaimpolicy   where riskcode in(select riskcode from lmriskapp)  and clmno in(select clmno from llclaim where clmstate in('2','3'))
/
