CREATE VIEW IID AS (select count(*) count_agentnum from laagent)
/
