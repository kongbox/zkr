CREATE VIEW VATDISTILLCLASS0000080 AS select '0000080' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType) as KeyUnionValue,
       a.Managecom,
       a.MakeDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.SumMoney as SumActuPayMoney,
       a.SumPriceDiff,
       a.PayNo,
       a.PayDate,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.MakeDate,
       a.ValueDate,
       (select p.grpcontno from lcgrppol p where p.grppolno = a.GrpPolNo) as bussno,
       'TB' bussnotype
 FROM Grppollcinsureacctrace a
 WHERE a.Othertype = '2'
   AND a.Moneytype = 'BF'
   AND a.Summoney <> 0
   AND EXISTS (SELECT 'x'
          FROM Ljapaygrp
         WHERE Payno = a.Otherno
           AND Paycount > 1)
   AND EXISTS
 (SELECT 'x'
          FROM Lmriskapp
         WHERE Riskcode = a.Riskcode
           AND Risktype3 = '4')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000080'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType))
/
