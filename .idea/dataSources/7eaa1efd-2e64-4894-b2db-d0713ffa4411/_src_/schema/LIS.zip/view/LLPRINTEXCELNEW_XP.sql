CREATE VIEW LLPRINTEXCELNEW_XP AS select la.subrptno clmno,
       (select b.riskcode
          from llclaimpolicy b
         where la.subrptno = b.clmno
           and la.customerno = b.insuredno
           and la.contno = b.contno) riskcode,
       c.agentcom agentcom,
       la.subrptno rgtno,
       la.mngcom amngcom,
       (select m.mngcom
          from llclaim m
         where la.subrptno = m.clmno
           AND la.customerno = m.customerno
           AND la.contno = m.contno) bmngcom,
       la.subrptno caseno,
       la.subcaseno subcase,
       la.customerno customerno,
       la.customername name,
       (select nvl(sum(ad.standpay), 0)
          from llclaimdetail ad, llclaim ac, llclaimpolicy af
         where ad.clmno = ac.caseno
           and ad.polno = af.polno
           and ad.caserelano = af.caserelano
           and ad.getdutykind = af.getdutykind
           and ad.givetype = '0'
           AND ac.clmno = la.subrptno
           AND ac.customerno = la.customerno
           AND ac.contno = la.contno) standpay,
       (select lm.endcasedate
          from llclaim lm
         where lm.clmno = la.subrptno
           AND lm.customerno = la.customerno) endcasedate,
       b.grpname appntname,
       b.grpcontno grpcontno,
       (select riskname
          from lmrisk
         where riskcode = (select b.riskcode
                             from llclaimpolicy b
                            where la.subrptno = b.clmno
                              and la.customerno = b.insuredno
                              and la.contno = b.contno)) riskname,
       (select bi.diagnose || bi.icdname
          from llaccidentbill bi
         where 1 = 1
           and bi.subrptno = la.subrptno || la.customerno
           and rownum = '1') diagnosename,
       (select nvl(sum(al.realpay), 0)
          from llclaimdetail al, llclaimpolicy bl
         where al.clmno = la.subrptno
           and al.polno = bl.polno
           and al.caserelano = bl.caserelano
           and al.getdutykind = bl.getdutykind
           and al.givetype = '0') realpay,
       case
         when exists (select 'X'
                 from LLClaimUWMain ll, llclaim laa
                where ll.clmno = la.subrptno
                  and ll.clmno = laa.clmno
                  and ll.insuredno = laa.customerno
                  and ll.auditconclusion = '1') then
          '拒付'
         else
          decode((select clmstate
                   from llclaim m
                  where m.clmno = la.subrptno
                    AND rownum = 1),
                 '80',
                 '拒付',
                 '70',
                 '拒付',
                 '给付')
       END ClmStatedesc,
       (SELECT codename
          FROM ldcode
         where codetype = 'llrgtnature'
           AND code = (SELECT e.RgtNature
                         FROM llcase e
                        where e.caseno = la.subrptno
                          and e.customerno = la.customerno)) RgtNature,
       (SELECT ld.codename
          FROM LLClaimUWMain aa, ldcode ld
         where aa.clmno = la.subrptno
           and aa.insuredno = la.customerno
           AND ld.codetype = 'llclaimconclusion'
           AND ld.code = aa.AuditConclusion) AuditConclusion,
       (select DECODE((select count(1)
                        from LLClaimUWAppeal ll
                       where ll.clmno = la.subrptno
                         and ll.insuredno = la.customerno),
                      '0',
                      '无',
                      '有')
          from dual) AppealCon,
       CASE
         WHEN (select count(1)
                 from lloperaterecord d
                where d.caseno = la.subrptno
                  AND d.customerno = la.customerno
                  AND d.stateid IN ('190', '200', '210', '220')) > 0 THEN
          '有'
         ELSE
          CASE
            WHEN (SELECT count(1)
                    FROM LLClaimUWMain s
                   where s.clmno = la.subrptno
                     AND s.insuredno = la.customerno
                     AND (s.specialremark is not null OR s.examconclusion = '1' OR
                         s.auditconclusion = '5')) > 0 THEN
             '有'
            ELSE
             CASE
               WHEN (SELECT count(1)
                       FROM lbmission sn
                      where sn.missionprop1 = la.subrptno || la.customerno
                        AND sn.activityid = '0000005696') > 0 THEN
                '有'
               ELSE
                '无'
             END
          END
       END uwmain,
       reportOK.reportOK_time, --报案确认时间
       reportOK.reportOK_opeator, --报案操作人
       scanReport.scanReport_time, --扫描上载完成时间
       addReport.addReport_time, --立案客户新增时间
       createReport.createReport_time, --最终立案确认时间
       createReport.create_opeator, --立案环节操作人
       appBill.appBill_time, --账单录入申请时间
       billReport.billReport_time, --最终账单录入完毕时间
       billReport.bill_operator, --账单录入操作人
       backReportFromBill.brfb_time, --账单录入退回立案时间,185
       appCal.appCal_time, --审核理算申请时间
       checkReport.checkReport_time, --最终审核理算确认时间
       checkReport.check_operator, --审核理算操作人
       calBack.calBack_time, --最终审核理算回退时间,200
       appRecheck.appRecheck_time, --复核申请时间
       recheckReport.recheckReport_time, --最终复核结论确认时间
       recheckReport.operator operator1, --最终复核环节操作人
       recheckBack.recheckBack_time, --最终复核退回时间,210
       spAppReport.spAppReport_time, --审批申请时间
       spReport.spReport_time, --最终审批确认时间
       spReport.operator operator2, --最终审批操作人
       spBack.spBack_time, --审批退回时间,220
       endAppReport.endAppReport_time, --结案申请时间
       endReport.endReport_time, --结案时间
       endReport.endReport_operator, --结案操作人
       inqReport.inqReport_time, --提起调查时间
       inqConc.inqConc_time --调查完成时间
  from llsubreport la
  left join (select rptno, appntno, grpname, grpcontno from llreport) b
    on la.subrptno = b.rptno
  join lccollection c
    on b.grpcontno = c.acceptno
  left join (select d.caseno,
                    d.customerno,
                    row_number() over(partition by d.caseno, d.customerno order by d.operatecount desc) as rt
               from lloperaterecord d
              where d.stateid = '20') d1
    on la.subrptno = d1.caseno
   AND la.customerno = d1.customerno
   AND d1.rt = 1
--增加报案记录，根据现在记录的赔案号，客户号，保单号去llgrpreportsub表里查询报案号，根据查到的
--报案号去lloperaterecord表里找报案确认的时间
  left join (select d.serialno, d.customerno, d.contno, d.reportflag
               from llgrpreportsub d) report
    on la.contno = report.contno
   AND la.customerno = report.customerno
   AND la.subrptno = report.reportflag
--10理赔报案确认记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) reportOK_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator reportOK_opeator
               from lloperaterecord a
              where a.stateid = '10') reportOK
    on report.serialno = reportOK.caseno
   AND report.customerno = reportOK.customerno
   AND reportOK.rt = '1'
--15理赔立案新增客户记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) addReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator add_opeator
               from lloperaterecord a
              where a.stateid = '15') addReport
    on d1.caseno = addReport.caseno
   AND d1.customerno = addReport.customerno
   AND addReport.rt = '1'
--20理赔立案确认记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) createReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator create_opeator
               from lloperaterecord a
              where a.stateid = '20') createReport
    on d1.caseno = createReport.caseno
   AND d1.customerno = createReport.customerno
   AND createReport.rt = '1'
--30扫描上载完成记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) scanReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '30') scanReport
    on d1.caseno = scanReport.caseno
   AND d1.customerno = scanReport.customerno
   AND scanReport.rt = '1'
--40:申请账单录入记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) appBill_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '40') appBill
    on d1.caseno = appBill.caseno
   AND d1.customerno = appBill.customerno
   AND appBill.rt = '1'
--50账单录入完毕记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) billReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator bill_operator
               from lloperaterecord a
              where a.stateid = '50') billReport
    on d1.caseno = billReport.caseno
   AND d1.customerno = billReport.customerno
   AND billReport.rt = '1'
--60审核理算申请记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) appCal_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator appCal_operator
               from lloperaterecord a
              where a.stateid = '60') appCal
    on d1.caseno = appCal.caseno
   AND d1.customerno = appCal.customerno
   AND appCal.rt = '1'
--80审核理算初审确认记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) checkReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator check_operator
               from lloperaterecord a
              where a.stateid = '80') checkReport
    on d1.caseno = checkReport.caseno
   AND d1.customerno = checkReport.customerno
   AND checkReport.rt = '1'
--90理赔复核申请记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) appRecheck_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator appRecheck_operator
               from lloperaterecord a
              where a.stateid = '90') appRecheck
    on d1.caseno = appRecheck.caseno
   AND d1.customerno = appRecheck.customerno
   AND appRecheck.rt = '1'
--100理赔复核结论保存记录
  left join (select a.caseno,
                    a.customerno,
                    a.operator,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) recheckReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '100') recheckReport
    on d1.caseno = recheckReport.caseno
   AND d1.customerno = recheckReport.customerno
   AND recheckReport.rt = '1'
--120审批管理申请记录
  left join (select a.caseno,
                    a.customerno,
                    a.operator,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) spAppReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator spAppReport_opeator
               from lloperaterecord a
              where a.stateid = '120') spAppReport
    on d1.caseno = spAppReport.caseno
   AND d1.customerno = spAppReport.customerno
   AND spAppReport.rt = '1'
--130审批管理确认记录
  left join (select a.caseno,
                    a.customerno,
                    a.operator,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) spReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator create_opeator
               from lloperaterecord a
              where a.stateid = '130') spReport
    on d1.caseno = spReport.caseno
   AND d1.customerno = spReport.customerno
   AND spReport.rt = '1'
--140理赔结案申请记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) endAppReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '150') endAppReport
    on d1.caseno = endAppReport.caseno
   AND d1.customerno = endAppReport.customerno
   AND endAppReport.rt = '1'
--150理赔结案财务支付并结案记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) endReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator endReport_operator
               from lloperaterecord a
              where a.stateid = '150') endReport
    on d1.caseno = endReport.caseno
   AND d1.customerno = endReport.customerno
   AND endReport.rt = '1'
--185 账单录入退回立案记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) brfb_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator brfb_operator
               from lloperaterecord a
              where a.stateid = '185') backReportFromBill
    on d1.caseno = backReportFromBill.caseno
   AND d1.customerno = backReportFromBill.customerno
   AND backReportFromBill.rt = '1'
--200退回账单录入 ，最终审核理算回退
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) calBack_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator calBack_operator
               from lloperaterecord a
              where a.stateid = '200') calBack
    on d1.caseno = calBack.caseno
   AND d1.customerno = calBack.customerno
   AND calBack.rt = '1'
--210退回审核理算,最终复核退回时间
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) recheckBack_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator recheckBack_operator
               from lloperaterecord a
              where a.stateid = '210') recheckBack
    on d1.caseno = recheckBack.caseno
   AND d1.customerno = recheckBack.customerno
   AND recheckBack.rt = '1'
--220退回理赔复核（审批管理界面）,审批退回
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) spBack_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt,
                    a.operator spBack_operator
               from lloperaterecord a
              where a.stateid = '220') spBack
    on d1.caseno = spBack.caseno
   AND d1.customerno = spBack.customerno
   AND spBack.rt = '1'
--230发起调查记录
  left join (select a.caseno,
                    a.customerno,
                    (to_char(a.recorddate, 'yyyy-mm-dd') || ' ' ||
                    a.recordtime) inqReport_time,
                    row_number() over(partition by a.caseno, a.customerno order by a.operatecount desc) as rt
               from lloperaterecord a
              where a.stateid = '230') inqReport
    on d1.caseno = inqReport.caseno
   AND d1.customerno = inqReport.customerno
   AND inqReport.rt = '1'
  left join (select lc.clmno,
                    lc.subclmno,
                    (to_char(lc.modifydate, 'yyyy-mm-dd') || ' ' ||
                    lc.modifytime) inqConc_time,
                    row_number() over(partition by lc.subclmno order by lc.conno desc) as rt
               from LLInqConclusion lc) inqConc
    on d1.caseno = inqConc.clmno
   AND inqConc.subclmno = d1.caseno || d1.customerno
   AND inqConc.rt = '1'
 where 1 = 1

/
