CREATE VIEW VIEW_LJAPAYPERSON2 AS select sum(SumActuPayMoney),agentcode,agentgroup,makedate from ljapayperson group by agentcode,agentgroup,makedate
/
