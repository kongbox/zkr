CREATE VIEW SMHOST_FOLDER_MAP_V AS select
     f.id folder_id,
     h.id host_id
from SMhost_only_folder_v f,
     SMBreakableLinks b,
     SMhost_v h
where
     f.id = b.lhsid
and  h.id = b.rhsid
/
