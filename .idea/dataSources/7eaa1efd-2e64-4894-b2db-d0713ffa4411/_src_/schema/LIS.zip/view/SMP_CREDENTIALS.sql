CREATE VIEW SMP_CREDENTIALS AS SELECT service_type, service_name, username, password, role
	FROM smp_credentials$
	WHERE UPPER(owner) = user
/
