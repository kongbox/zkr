CREATE VIEW SMP_JOB_HISTORY AS select id, owner, name, type, agent_job_id, status, timestamp, destination,
   total_params, parameters, output_data, execution from SMP_JOB_HISTORY_
   where owner = user WITH CHECK OPTION
/
