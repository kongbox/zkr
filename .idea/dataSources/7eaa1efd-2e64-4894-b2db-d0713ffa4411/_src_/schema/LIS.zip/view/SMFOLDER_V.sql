CREATE VIEW SMFOLDER_V AS select
  NamedObject_ID_sequenceID_ id,
  Folder_folderName_ name,
  Folder_description_ description
from SMFolder_s
/
