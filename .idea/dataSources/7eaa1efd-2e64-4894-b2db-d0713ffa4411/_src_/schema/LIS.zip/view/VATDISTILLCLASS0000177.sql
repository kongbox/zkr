CREATE VIEW VATDISTILLCLASS0000177 AS select '0000177' as classid,
       (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.ManageCom || ',' || a.edorno || ',' || c.riskcode ) as KeyUnionValue,
       a.edorno as bussno,
       a.grpcontno,
       a.managecom,
       c.riskcode,
       'BQ' as bussnotype,
       greatest(a.edorvalidate,a.confdate) as checkdate,
       a.makedate,
       c.serialno,
       c.commonprem,
       c.commonmanagecom
  from lpgrpedormain a, lcgrpcont b, LJACommonInsuRisk c
 where 1 = 1
   and a.grpcontno = c.grpcontno
   and a.grpcontno = b.grpcontno
   and a.edorno = c.otherno
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000177'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue = (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.ManageCom || ',' || a.edorno || ',' || c.riskcode ))
   and a.edorno in
       (select a.endorsementno
          from grppolljagetendorse a, LMRiskApp b, LCGrpPol c
         where a.FeeFinaType in ('BF', 'GL')
           and a.FeeOperationType <> 'RE'
           and a.grppolno = c.grppolno
           and b.riskcode = c.riskcode
           and b.risktype3 not in ('3', '4', '8', '2')
           and a.getmoney > 0
           and not exists (select 'X'
                  from ljagetendorse
                 where endorsementno = a.endorsementno
                   and FeeFinaType = 'EY')
        union
        select a.endorsementno
          from grppolljagetendorse a, LMRiskApp b, LCGrpPol c
         where a.FeeFinaType in ('BF', 'GL')
           and a.FeeOperationType <> 'RE'
           and a.grppolno = c.grppolno
           and b.riskcode = c.riskcode
           and b.risktype3 not in ('3', '4', '8', '2')
          UNION
           select a.endorsementno
             from grppolljagetendorse a, LMRiskApp b, LCGrpPol c
            where 1 = 1
              and a.GrpPolNo = c.GrpPolNo
              and a.FeeOperationType in ('01', '08', '02')
              and c.riskcode = b.riskcode
              and b.RiskPeriod != 'L')
/
