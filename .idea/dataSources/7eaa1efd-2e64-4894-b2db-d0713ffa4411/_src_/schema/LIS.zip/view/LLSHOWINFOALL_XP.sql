CREATE VIEW LLSHOWINFOALL_XP AS select
a.subrptno clmno,
(select b.riskcode from llclaimpolicy b where a.subrptno = b.clmno
                      and a.customerno = b.insuredno
                      and a.contno = b.contno)riskcode,
c.agentcom agentcom,
a.subrptno rgtno,
 a.mngcom amngcom,
(select m.mngcom from llclaim m where a.subrptno = m.clmno AND a.customerno = m.customerno AND a.contno = m.contno) bmngcom,
a.subrptno caseno,
a.subcaseno subcase,
a.customerno customerno,
a.customername name,
(select nvl(sum(ad.standpay), 0)
          from llclaimdetail ad,llclaim ac ,llclaimpolicy af
         where ad.clmno = ac.caseno
           and ad.polno = af.polno
           and ad.caserelano = af.caserelano
           and ad.getdutykind = af.getdutykind
           and ad.givetype = '0'
           AND ac.clmno = a.subrptno AND ac.customerno = a.customerno AND ac.contno = a.contno) standpay,
 (select lm.endcasedate from llclaim lm where lm.clmno = a.subrptno AND lm.customerno = a.customerno ) endcasedate,
b.grpname appntname,
b.grpcontno grpcontno,
 (select riskname from lmrisk where riskcode = (select b.riskcode from llclaimpolicy b where a.subrptno = b.clmno
                      and a.customerno = b.insuredno
                      and a.contno = b.contno)) riskname,
   (select bi.diagnose || bi.icdname
          from llaccidentbill bi
         where 1 = 1
           and bi.subrptno = a.subrptno || a.customerno
           and rownum = '1') diagnosename,
       (select nvl(sum(al.realpay), 0)
          from llclaimdetail al,llclaimpolicy bl
         where al.clmno = a.subrptno
           and al.polno = bl.polno
           and al.caserelano = bl.caserelano
           and al.getdutykind = bl.getdutykind
           and al.givetype = '0')realpay,
  case
         when exists (select 'X'
                 from LLClaimUWMain ll,llclaim la
                where la.clmno = a.subrptno
                  and ll.clmno = la.clmno
                  and ll.insuredno = la.customerno
                  and ll.auditconclusion = '1') then
          '拒付'
         else
          decode((select clmstate from llclaim m where m.clmno = a.subrptno AND rownum=1), '80', '拒付', '70', '拒付', '给付')
       END ClmStatedesc,
         (SELECT codename
          FROM ldcode
         where codetype = 'llrgtnature'
           AND code = (SELECT e.RgtNature
                         FROM llcase e
                        where e.caseno = a.subrptno
                          and e.customerno = a.customerno)) RgtNature,
  (SELECT ld.codename
          FROM LLClaimUWMain aa, ldcode ld
         where aa.clmno = a.subrptno
           and aa.insuredno = a.customerno
           AND ld.codetype = 'llclaimconclusion'
           AND ld.code = aa.AuditConclusion) AuditConclusion,
       (select DECODE((select count(1)
                        from LLClaimUWAppeal ll
                       where ll.clmno = a.subrptno
                         and ll.insuredno = a.customerno),
                      '0',
                      '无',
                      '有')
          from dual) AppealCon,
       CASE
         WHEN (select count(1)
                  from lloperaterecord d
                  where d.caseno=a.subrptno
                  AND d.customerno=a.customerno
                  AND d.stateid IN ('190','200','210','220')  )>0 THEN
                  '有'
           ELSE
           CASE
         WHEN (SELECT count(1)
                 FROM LLClaimUWMain s
                where s.clmno = a.subrptno
                  AND s.insuredno = a.customerno
                  AND ( s.specialremark is not null OR s.examconclusion ='1' OR s.auditconclusion='5') ) > 0 THEN
          '有'
         ELSE
          CASE
         WHEN (SELECT count(1)
                 FROM lbmission sn
                where sn.missionprop1 = a.subrptno || a.customerno
                  AND sn.activityid = '0000005696') > 0 THEN
          '有'
         ELSE
          '无'
       END END END  uwmain from llsubreport a
  left join (select rptno, appntno, grpname, grpcontno from llreport) b on a.subrptno =
    b.rptno
  join lccollection c on b.grpcontno = c.acceptno
 where 1 = 1
/
