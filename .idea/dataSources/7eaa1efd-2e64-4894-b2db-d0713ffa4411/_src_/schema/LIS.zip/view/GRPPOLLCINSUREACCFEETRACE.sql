CREATE VIEW GRPPOLLCINSUREACCFEETRACE AS select RiskCode,OtherNo,OtherType,MoneyType,FeeCode,
GrpPolNo,ManageCom,PayDate,MakeDate,sum(Fee) as SumFee from LCInsureAccFeeTrace
where grpcontno != '00000000000000000000'
group by RiskCode,OtherNo,OtherType,MoneyType,FeeCode,
GrpPolNo,ManageCom,PayDate,MakeDate
/
