CREATE VIEW LBPOL_LMRISK AS SELECT LBPol.MainPolNo,LBPol.MakeDate,LBPol.CValiDate,LBPol.ManageCom,LBPol.PrtNo,LBPol.SaleChnl,LBPol.RiskCode,COUNT(DISTINCT LBPol.MainPolNo),COUNT(DISTINCT LBPol.PrtNo),SUM(LBPol.Amnt)  	FROM  	LBPol,LMRisk  	WHERE  	LBPol.RiskCode=LMRisk.RiskCode  	GROUP BY  	LBPol.MainPolNo,LBPol.MakeDate,LBPol.CValiDate,LBPol.ManageCom,LBPol.PrtNo,LBPol.SaleChnl,LBPol.RiskCode
/
