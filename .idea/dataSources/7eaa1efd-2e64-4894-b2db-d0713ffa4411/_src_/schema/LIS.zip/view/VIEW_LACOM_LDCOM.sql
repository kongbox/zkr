CREATE VIEW VIEW_LACOM_LDCOM AS select managecom,trim(b.shortname) shortname,trim(a.name) name,agentcom from lacom a,ldcom b where b.comcode=a.managecom and length(trim(managecom))=4 and length(trim(agentcom))=6 order by agentcom
/
