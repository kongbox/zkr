CREATE VIEW VATDISTILLCLASS0000178 AS select '0000178' as classid,
       lp.edorno as bussno,
       'BQ' as bussnotype,
       (lp.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = b.commonmanagecom) || ',' || lp.ManageCom || ',' || lp.edorno || ',' || b.riskcode ) as KeyUnionValue,
       lp.grpcontno,
       lp.ManageCom,
       lp.edorvalidate,
       lp.confdate as checkdate,
       b.commonprem,
       b.riskcode,
       b.serialno,
       b.commonmanagecom
  from lpgrpedormain lp, LJACommonInsuRisk b
 where 1 = 1
   and lp.grpcontno = b.grpcontno
   and lp.edorno = b.otherno
   and lp.GetMoney < 0
   --排除定期寿险
   AND NOT EXISTS (SELECT 1 FROM LMRiskApp app WHERE app.risktype4 = '3' AND app.risktype2 = 'L' AND app.riskcode = b.riskcode)
  and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000178'
           and i.flag = '1'
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (lp.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = b.commonmanagecom) || ',' || lp.ManageCom || ',' || lp.edorno || ',' || b.riskcode ))
   and exists (select 1
          from grppolljagetendorse a
         where 1 = 1
           and a.EndorsementNo = lp.edorno
           and a.FeeFinaType in ('TB', 'TF')
           and a.getmoney < 0
           )union
select '0000178' as classid,
       lp.edorno as bussno,
       'BQ' as bussnotype,
       (lp.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = b.commonmanagecom) || ',' || lp.ManageCom || ',' || lp.edorno || ',' || b.riskcode ) as KeyUnionValue,
       lp.grpcontno,
       lp.ManageCom,
       lp.edorvalidate,
       lp.confdate as checkdate,
       b.commonprem,
       b.riskcode,
       b.serialno,
       b.commonmanagecom
  from lpgrpedormain lp, LJACommonInsuRisk b
 where 1 = 1
  and lp.grpcontno = b.grpcontno
   and lp.edorno = b.otherno
   and lp.GetMoney < 0
    --排除定期寿险
   AND NOT EXISTS (SELECT 1 FROM LMRiskApp app WHERE app.risktype4 = '3' AND app.risktype2 = 'L' AND app.riskcode = b.riskcode)
  and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000178'
           and i.flag = '1'
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (lp.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = b.commonmanagecom) || ',' || lp.ManageCom || ',' || lp.edorno || ',' || b.riskcode ))
   and exists(
   select 1 from lpgrpedoritem c where 1=1 and c.edorno = lp.edorno and c.edortype = 'WT'
   )
/
