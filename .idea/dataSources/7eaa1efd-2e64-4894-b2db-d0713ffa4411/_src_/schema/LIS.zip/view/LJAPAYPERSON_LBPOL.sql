CREATE VIEW LJAPAYPERSON_LBPOL AS select ljapayperson.polno,         ljapayperson.sumactupaymoney,          lbpol.riskcode,         lmriskapp.riskperiod  from   ljapayperson,lbpol,lmriskapp  where  ljapayperson.paytype='ZC'   AND ljapayperson.POLNO=LBPOL.POLNO  AND LBPOL.riskcode=lmriskapp.riskcode
/
