CREATE VIEW VATDISTILLCLASS0000077 AS select '0000077' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType || ',' ||
       a.FeeCode || ',' || to_char(a.PayDate, 'YYYY-MM-DD')) as KeyUnionValue,
       a.Managecom,
       a.MakeDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.sumfee,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.FeeCode,
       a.PayDate,
       a.MakeDate,
       (select p.grpcontno from LCGrpPol p where p.grppolno = a.GrpPolNo) as bussno,
       'TB' as bussnotype
  from grppollcinsureaccfeetrace a
 where a.othertype = '1'
   and a.sumfee > 0
   and exists (select 1
          from lmriskfee l
         where l.feeitemtype = '01'
           and l.feecode = a.FeeCode
           and l.feetakeplace in ('02', '10'))
   and exists (select 1
          from lmriskapp r
         where r.riskcode = a.RiskCode
           and r.risktype6 = '4')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000077'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType || ',' ||
               a.FeeCode || ',' || to_char(a.PayDate, 'YYYY-MM-DD')))
/
