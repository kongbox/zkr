CREATE VIEW SMINSTALLED_PRODUCT_V AS select
  i.NamedObject_ID_sequenceID_ installation_id,
  p.NamedObject_ID_sequenceID_ product_id
from SMinstallation_s i, SMproduct_s p, SMMOwnerLinks m
where
  m.MOwnerID = i.NamedObject_ID_sequenceID_ and
  m.MOwneeID = p.NamedObject_ID_sequenceID_ and
  m.Association_ID_ = 18
/
