CREATE VIEW LCPOL_LJAPAYPERSON AS select ljapayperson.polno,         ljapayperson.sumactupaymoney,          lcpol.riskcode,         lmriskapp.riskperiod  from   ljapayperson,lcpol,lmriskapp  where  ljapayperson.paytype='ZC'   AND ljapayperson.POLNO=LCPOL.POLNO  AND LCPOL.riskcode=lmriskapp.riskcode
/
