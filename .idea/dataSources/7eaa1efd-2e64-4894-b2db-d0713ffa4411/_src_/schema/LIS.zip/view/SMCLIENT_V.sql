CREATE VIEW SMCLIENT_V AS select
  c.NamedObject_ID_sequenceID_ id,
  c.SOClient_name_ clientname,
  c.SOClient_os_ os,
  c.SOClient_osver_ os_version,
  h.NamedObject_ID_sequenceID_ host_id
from SMSharedOracleClient_s c, SMHost_s h, SMOwnerLinks o
where
  o.OwnerID = h.NamedObject_ID_sequenceID_ and
  o.OwneeID = c.NamedObject_ID_sequenceID_ and
  o.Association_ID_ = 31
/
