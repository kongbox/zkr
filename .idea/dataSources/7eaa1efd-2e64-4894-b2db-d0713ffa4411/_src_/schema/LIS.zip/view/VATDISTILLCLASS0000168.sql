CREATE VIEW VATDISTILLCLASS0000168 AS select '0000168' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType) as KeyUnionValue,
       a.Managecom,
       a.MakeDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.SumMoney as SumActuPayMoney,
       a.SumPriceDiff,
       a.PayNo,
       a.MoneyType,
       a.OtherType,
       a.PayDate,
       a.MakeDate,
       a.ValueDate,
       a.GrpPolNo,
       (select count(1) from ljapaygrp l where l.grppolno = a.GrpPolNo and l.payno = a.PayNo) datacount,
       (select p.grpcontno from lcgrppol p where p.grppolno = a.GrpPolNo) as bussno,
       'TB' as bussnotype
  from grppollcinsureacctrace a
 where a.othertype = '2'
   and a.moneytype = 'BF'
   and a.summoney <> 0
   and exists (select 'x'
          from ljapaygrp
         where payno = a.otherno
           and paycount > 1)
   and exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 = '2')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000168'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType))
/
