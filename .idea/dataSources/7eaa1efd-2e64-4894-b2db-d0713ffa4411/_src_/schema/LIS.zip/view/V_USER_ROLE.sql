CREATE VIEW V_USER_ROLE AS select t_user.userid userid,t_user.username username,t_user.password password,t_user.departmentid departmentid,
       t_user.description description ,t_role.roleid roleid,
       t_role.rolename rolename
from t_user,t_role,t_userrole
where t_user.userid=t_userrole.userid and t_userrole.roleid=t_role.roleid
/
