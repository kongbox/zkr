CREATE VIEW SMCLIENT_ONLY_FOLDER_V AS select
  NamedObject_ID_sequenceID_ id,
  Folder_folderName_ name,
  Folder_description_ description
from SMFolder_s
where Folder_userData1_ = 53
/
