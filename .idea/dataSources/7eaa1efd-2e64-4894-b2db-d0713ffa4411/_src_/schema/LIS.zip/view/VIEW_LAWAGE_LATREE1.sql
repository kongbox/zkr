CREATE VIEW VIEW_LAWAGE_LATREE1 AS select a.agentgrade,
       c.payyear,
       a.IndexCalNo,
       c.WageNo,
       a.f01,
       a.f02,
       a.f04,
       a.f21,
       a.f05,
       a.f03,
       a.f08,
       a.f07,
       a.f09,
       a.f10,
       a.f11,
       a.f12,
       a.f15,
       a.f18,
       a.f13,
       a.f16,
       a.f19,
       a.f06,
       a.f14,
       a.f17,
       a.f30
  from LAwage a, latree b, LACommision c
 where a.AgentCode = b.agentcode
   and a.AgentCode = c.agentcode
/
