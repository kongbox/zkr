CREATE VIEW LACOMMISION_LAAGENT AS select a.name,a.agentcode,b.agentgrade,c.Fyc,c.TransMoney,c.Payintv,e.Riskperiod,d.SignDate,d.makedate,a.branchcode  from LAAgent a,LATree b,LACommision c,lcpol d,LMRiskApp e   where d.polno=c.polno and c.Riskcode=e.Riskcode and a.agentcode=c.agentcode  and c.CommDire='1' and  a.agentcode=b.agentcode
/
