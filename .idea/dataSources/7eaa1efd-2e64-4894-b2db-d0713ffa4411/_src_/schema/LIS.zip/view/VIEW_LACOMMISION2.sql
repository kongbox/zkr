CREATE VIEW VIEW_LACOMMISION2 AS select Fyc,Transmoney,payyear,wageno,agentgroup,managecom from lacommision where BranchType=1
/
