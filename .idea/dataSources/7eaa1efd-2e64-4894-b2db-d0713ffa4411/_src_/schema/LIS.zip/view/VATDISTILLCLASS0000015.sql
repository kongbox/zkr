CREATE VIEW VATDISTILLCLASS0000015 AS select '0000015' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.FeeOperationType || ',' ||
       a.FeeFinaType || ',' || a.PolNo || ',' || a.Otherno || ',' ||
       a.DutyCode || ',' || a.PayPlanCode || ',' || a.SubFeeOperationType) as KeyUnionValue,
       a.managecom,
       a.makedate as checkdate,
       a.EndorsementNo,
       a.riskcode,
       a.getmoney as SumActuPayMoney,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.PolNo,
       a.DutyCode,
       a.PayPlanCode,
       a.SubFeeOperationType,
       a.otherno,
       a.othernotype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype
  from LJAGetEndorse a
 where a.FeeFinaType = 'LX'
   and a.FeeOperationType in ('RE', 'NI', 'AA')
   and exists
 (select 1 from LPGrpEdorMain c where c.edorno = a.endorsementno)
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 = '8')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000015'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue =
               (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.PolNo || ',' ||
               a.Otherno || ',' || a.DutyCode || ',' || a.PayPlanCode || ',' ||
               a.SubFeeOperationType))
/
