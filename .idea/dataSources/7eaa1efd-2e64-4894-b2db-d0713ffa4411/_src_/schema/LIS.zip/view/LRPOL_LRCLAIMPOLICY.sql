CREATE VIEW LRPOL_LRCLAIMPOLICY AS select lrpol.RISKCODE             lrpol_RISKCODE,
       lrpol.POLNO                lrpol_POLNO,
	   lrpol.INSUREDNAME          lrpol_INSUREDNAME,
	   lrpol.YEARS                lrpol_YEARS,
	   lrpol.REINSURECOM          lrpol_REINSURECOM,
	   lrpol.MAKEDATE             lrpol_MAKEDATE,
	   sum(lrpol.AMNT)            sum_lrpol_AMNT,
	   sum(lrpol.CESSIONAMOUNT)   sum_lrpol_CESSIONAMOUNT,
	   sum(lrpol.PREM)            sum_lrpol_PREM,
	   sum(lrpol.CESSPREM)        sum_lrpol_CESSPREM
from lrpol,lrclaimpolicy,llregister
where lrclaimpolicy.POLNO=LRPol.POLNO
  AND lrclaimpolicy.REINSURECOM=LRPol.REINSURECOM
  and lrclaimpolicy.REINSURITEM=LRPol.REINSURITEM
  AND lrclaimpolicy.INSUREDYEAR=LRPol.INSUREDYEAR
  and lrclaimpolicy.RGTNO=llregister.RGTNO
  and lrclaimpolicy.REINSURITEM='L'
group by
           lrpol.REINSURECOM ,
	       lrpol.MAKEDATE,
           lrpol.RISKCODE,
           lrpol.POLNO,
		   lrpol.INSUREDNAME,
		   lrpol.YEARS,
           lrpol.AMNT,
		   lrpol.CESSIONAMOUNT,
		   lrpol.PREM,
		   lrpol.CESSPREM
/
