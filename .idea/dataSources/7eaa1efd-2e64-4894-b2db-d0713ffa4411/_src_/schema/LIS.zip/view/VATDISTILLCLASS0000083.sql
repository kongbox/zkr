CREATE VIEW VATDISTILLCLASS0000083 AS select '0000083' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo || ',' ||
       a.SubFeeOperationType) as KeyUnionValue,
       a.ManageCom,
       a.MakeDate as checkdate,
       a.EndorsementNo,
       c.riskcode,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       c.grpcontno,
       a.EnterAccDate,
       a.GetConfirmDate,
       a.MakeDate,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype
  from grppolljagetendorse2 a,LCGrpPol c
 where a.GrpPolNo = c.GrpPolNo
   and a.FeeOperationType = 'XT'
   and a.FeeFinaType = 'TB'
   and a.SubFeeOperationType = 'SY'
   and a.getmoney > 0
   and exists (select 1
          from LMRiskApp b
         where b.riskcode = c.riskcode
           and b.riskperiod = 'L'
           and b.risktype3 = '4')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000083'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue =
               (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' ||
               a.GrpPolNo || ',' || a.SubFeeOperationType))
/
