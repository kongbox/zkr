CREATE VIEW VIEW_LACOMMISION AS SELECT AgentCode,PayYear,GetPolDate,BranchType,SUM(DirectWage)  	FROM  	LACommision  	GROUP BY  	AgentCode,PayYear,GetPolDate,BranchType
/
