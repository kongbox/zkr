CREATE VIEW VIEW_LAAGENT_LATREEL AS select EmployDate,InDueFormDate,agentgrade from LAAgent a,latree b where a.agentcode=b.agentcode and agentstate in ('01','02') and a.agentgroup in (select agentGroup from LABranchGroup where BranchType='1')
/
