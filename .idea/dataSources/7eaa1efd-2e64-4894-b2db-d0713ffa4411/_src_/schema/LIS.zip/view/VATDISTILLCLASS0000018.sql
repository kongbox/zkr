CREATE VIEW VATDISTILLCLASS0000018 AS select '0000018' as classid,
       (a.GrpPolNo || ',' || a.PayCount || ',' || a.PayNo || ',' ||
       a.PayType) as KeyUnionValue,
       a.managecom,
       a.ConfDate as checkdate,
       a.endorsementno,
       a.riskcode,
       a.sumactupaymoney,
       a.grppolno,
       a.paycount,
       a.payno,
       a.paytype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype
  from LJAPayGrp a
 where a.paycount > 1
   and a.paytype in ('ZC', 'ZS')
   and not exists
 (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and (risktype3 in ('3', '4', '8', '2') or
               (risktype in ('A', 'H') and riskperiod = 'M')))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000018'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.GrpPolNo || ',' || a.PayCount || ',' ||
               a.PayNo || ',' || a.PayType))
/
