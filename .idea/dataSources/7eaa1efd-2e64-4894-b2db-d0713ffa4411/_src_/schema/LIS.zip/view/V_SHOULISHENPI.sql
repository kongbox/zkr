CREATE VIEW V_SHOULISHENPI AS select
 entityid,
 sp1spbs,
 sp1spyj,
 sp1spr,
 sp1spsj
from demo
/
