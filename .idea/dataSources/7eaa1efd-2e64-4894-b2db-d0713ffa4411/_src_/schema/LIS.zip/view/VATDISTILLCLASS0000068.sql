CREATE VIEW VATDISTILLCLASS0000068 AS select '0000068' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType) as KeyUnionValue,
       a.Managecom,
       a.ValueDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.SumMoney,
       a.SumPriceDiff  as SumActuPayMoney,
       a.PayNo,
       a.PayDate,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.MakeDate,
       a.ValueDate,
       (select p.grpcontno from lcgrppol p where p.grppolno = a.GrpPolNo) as bussno,
       'TB' bussnotype
  from grppollcinsureacctrace a
 where a.othertype = '2'
   and a.moneytype = 'BF'
   and a.SumPriceDiff > 0
   and exists (select 'x'
          from ljapaygrp
         where payno = a.otherno
           and paycount = 1)
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000068'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType))
/
