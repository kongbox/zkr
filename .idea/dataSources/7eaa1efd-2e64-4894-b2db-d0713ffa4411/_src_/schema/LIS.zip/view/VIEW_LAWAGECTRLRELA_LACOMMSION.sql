CREATE VIEW VIEW_LAWAGECTRLRELA_LACOMMSION AS select distinct(a.polno),Destfactor,Originfactor,a.riskcode,a.branchattr,a.caldate from lacommision a,Lmriskapp b,LAWageCtrlRela c where b.Subriskflag='M' and a.Riskcode=b.Riskcode and a.Riskcode=c.Riskcode and a.branchtype='1'
/
