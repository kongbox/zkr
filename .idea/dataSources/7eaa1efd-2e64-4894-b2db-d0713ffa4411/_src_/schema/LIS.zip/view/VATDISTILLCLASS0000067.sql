CREATE VIEW VATDISTILLCLASS0000067 AS select '0000067' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType || ',' ||
       a.FeeCode || ',' || to_char(a.PayDate, 'YYYY-MM-DD')) as KeyUnionValue,
       a.Managecom,
       a.MakeDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.sumfee,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.FeeCode,
       a.PayDate,
       a.MakeDate,
       (select p.grpcontno from LCGrpPol p where p.grppolno = a.GrpPolNo) as bussno,
       'TB' as bussnotype
  from grppollcinsureaccfeetrace a
 where a.othertype = '2'
   and a.sumfee > 0
   and exists (select 1
          from lmriskfee l
         where l.feecode = a.FeeCode
           and l.feeitemtype = '01'
           and l.feetakeplace = '01')
   and exists (select 'x'
          from ljapaygrp
         where payno = a.otherno
           and paycount = 1)
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('8', '2'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000067'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType || ',' ||
               a.FeeCode || ',' || to_char(a.PayDate, 'YYYY-MM-DD')))
/
