CREATE VIEW VIEW_LAWAGEF03 AS select f03,IndexCalNo,managecom,agentgroup from lawage where f03=1000 and BranchType=1
/
