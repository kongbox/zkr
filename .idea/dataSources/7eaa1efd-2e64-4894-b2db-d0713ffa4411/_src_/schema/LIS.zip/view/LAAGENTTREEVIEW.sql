CREATE VIEW LAAGENTTREEVIEW AS select laagent.Agentcode,laagent.name,latree.managecom,laagent.branchtype,laagent.agentgroup,laagent.branchcode,laagent.InDueFormDate,laagent.employdate,laagent.agentstate,latree.introagency, latree.edumanager,latree.agentgrade,latree.startdate       from laagent,latree     where laagent.agentcode=latree.agentcode
/
