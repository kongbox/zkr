CREATE VIEW VIEW_AGENT_POL_STAT AS ( select count(*) agent_count, employdate,agentcode,branchtype    from laagent     where agentcode in (select agentcode from lcpol)    group by employdate,agentcode,branchtype)
/
