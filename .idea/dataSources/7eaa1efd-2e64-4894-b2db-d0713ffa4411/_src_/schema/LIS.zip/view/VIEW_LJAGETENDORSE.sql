CREATE VIEW VIEW_LJAGETENDORSE AS SELECT ActuGetNo,FeeFinaType,GetConfirmDate,ManageCom,RiskCode,COUNT(DISTINCT ActuGetNo),SUM(GetMoney)  	FROM  	LJAGetEndorse  	GROUP BY  	ActuGetNo,FeeFinaType,GetConfirmDate,ManageCom,RiskCode
/
