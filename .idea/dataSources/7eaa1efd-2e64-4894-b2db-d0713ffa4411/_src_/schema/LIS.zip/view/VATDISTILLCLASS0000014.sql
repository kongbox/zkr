CREATE VIEW VATDISTILLCLASS0000014 AS select '0000014' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.FeeOperationType || ',' ||
       a.FeeFinaType || ',' || a.PolNo || ',' || a.Otherno || ',' ||
       a.DutyCode || ',' || a.PayPlanCode || ',' || a.SubFeeOperationType) as KeyUnionValue,
       a.managecom,
       a.makedate as checkdate,
       a.EndorsementNo,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype,
       a.riskcode,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.PolNo,
       a.DutyCode,
       a.PayPlanCode,
       a.SubFeeOperationType,
       a.grpcontno,
       a.getmoney as SumActuPayMoney,
       a.otherno,
       a.othernotype,
       a.getnoticeno
  from LJAGetEndorse a
 where a.FeeFinaType = 'BF'
   and a.FeeOperationType = 'RE'
   and exists (select 1 from LCGrpPol b where b.grppolno = a.grppolno)
   and exists
 (select 1 from LPGrpEdorMain c where c.edorno = a.endorsementno)
   and not exists
 (select 1
          from LjaTaxDetailLog i
         where i.classid = '0000014'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue =
               (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.PolNo || ',' ||
               a.Otherno || ',' || a.DutyCode || ',' || a.PayPlanCode || ',' ||
               a.SubFeeOperationType))
/
