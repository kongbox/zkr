CREATE VIEW LLSHOWINFO AS select
 la.clmno,
b.riskcode,
c.agentcom,
 la.rgtno,
       la.mngcom amngcom,
       b.mngcom bmngcom,
       la.caseno,
     (  la.clmno || la.customerno) subcase,
       la.customerno,
       (select name
          from lcinsured
         where  insuredno = la.customerno
           and contno = la.contno) name,
       (select nvl(sum(standpay), 0)
          from llclaimdetail
         where clmno = la.caseno
           and polno = b.polno
           and caserelano = b.caserelano
           and getdutykind = b.getdutykind
           and givetype = '0') standpay,
       la.endcasedate,
       b.appntname,
       b.grpcontno,
       (select riskname from lmrisk where riskcode = b.riskcode) riskname,
       (select diagnose || icdname
          from llaccidentbill
         where 1 = 1
           and subrptno = la.clmno || la.customerno
           and rownum = '1') diagnosename,
       (select nvl(sum(realpay), 0)
          from llclaimdetail
         where clmno = la.caseno
           and polno = b.polno
           and caserelano = b.caserelano
           and getdutykind = b.getdutykind
           and givetype = '0')realpay,
       case
         when exists (select 'X'
                 from LLClaimUWMain
                where clmno = la.clmno
                  and insuredno = la.customerno
                  and auditconclusion = '1') then
          '拒付'
         else
          decode(la.ClmState, '80', '拒付', '70', '拒付', '给付')
       END ClmStatedesc,
       (SELECT codename
          FROM ldcode
         where codetype = 'llrgtnature'
           AND code = (SELECT e.RgtNature
                         FROM llcase e
                        where e.caseno = la.clmno
                          and e.customerno = la.customerno)) RgtNature,
       (SELECT ld.codename
          FROM LLClaimUWMain aa, ldcode ld
         where aa.clmno = la.clmno
           and aa.insuredno = la.customerno
           AND ld.codetype = 'llclaimconclusion'
           AND ld.code = aa.AuditConclusion) AuditConclusion,
       (select DECODE((select count(1)
                        from LLClaimUWAppeal ll
                       where ll.clmno = la.clmno
                         and ll.insuredno = la.customerno),
                      '0',
                      '无',
                      '有')
          from dual) AppealCon,
       CASE
         WHEN (select count(1)
                  from lloperaterecord d
                  where d.caseno=la.clmno
                  AND d.customerno=la.customerno
                  AND d.stateid IN ('190','200','210','220')  )>0 THEN
                  '有'
           ELSE
           CASE
         WHEN (SELECT count(1)
                 FROM LLClaimUWMain s
                where s.clmno = la.clmno
                  AND s.insuredno = la.customerno
                  AND ( s.specialremark is not null OR s.examconclusion ='1' OR s.auditconclusion='5') ) > 0 THEN
          '有'
         ELSE
          CASE
         WHEN (SELECT count(1)
                 FROM lbmission sn
                where sn.missionprop1 = la.clmno || la.customerno
                  AND sn.activityid = '0000005696') > 0 THEN
          '有'
         ELSE
          '无'
       END END END  uwmain
       from llclaim la
  join llclaimpolicy b on la.clmno = b.clmno
                      and la.customerno = b.insuredno
                      and la.contno = b.contno
  join lcgrpcont c on b.grpcontno = c.grpcontno
 where 1 = 1
   and la.clmstate in ('60', '70', '80')
   order by  (  la.clmno || la.customerno),la.endcasedate
/
