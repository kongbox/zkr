CREATE VIEW SHAREINQMONEYVIEW AS select tt.grpcontno,
       tt.managecom,
       tt.clmno,
       tt.inqno,
       tt.batno,
       tt.riskcode,
       tt.makedate,
       tt.enteraccdate,
       tt.inqmoney,
       tt.riskrealpay,
       tt.sumrealpay,
       tt.risksumprem,
       tt.sumprem,
       case tt.sumrealpay
         when 0 then
          round(tt.inqmoney * tt.risksumprem / tt.sumprem, 2)
         else
          round(tt.inqmoney * tt.riskrealpay / tt.sumrealpay, 2)
       end sharemoney
  from (select '1' busitype,
               ljc.grpcontno, --团体保单号
               ljc.managecom, --管理机构
               la.clmno, --赔案号
               la.inqno, --调查号
               la.batno, --调查批次
               ljc.riskcode, --赔付险种
               ljc.makedate,
               to_char(ljc.enteraccdate, 'yyyy-mm-dd') enteraccdate,
               nvl((select sum(lq.feesum)
                     from Llinqfee lq
                    where la.clmno = lq.clmno
                      and la.inqno = lq.inqno),
                   0) inqmoney, --调查总费用
               nvl(sum(ljc.pay), 0) riskrealpay, --险种实际赔付金额
               nvl((select sum(l.pay)
                     from LJAGetClaim l
                    where la.clmno = l.otherno
                      and l.othernotype = '5'),
                   0) sumrealpay, --实际赔付总额
               nvl((select sum(p.sumprem)
                     from lcgrppol p
                    where p.grpcontno = ljc.grpcontno
                      and p.riskcode = ljc.riskcode),
                   0) risksumprem, --险种累计保费
               nvl((select sum(p.sumprem)
                     from lcgrppol p
                    where p.grpcontno = ljc.grpcontno),
                   0) sumprem --保单累计总保费
          from LLInqApply la, LJAGetClaim ljc
         where 1 = 1
           and la.clmno = ljc.otherno
           and ljc.othernotype = '5'
           and exists (select 1
                  from llinqconclusion lli
                 where lli.clmno = la.clmno
                   and lli.batno = la.batno
                   and lli.finiflag = '1' --调查完成标志
                   and lli.inqconclusion = '1') --1-通过   2-不通过
         group by ljc.grpcontno,
                  ljc.managecom,
                  la.clmno,
                  la.inqno,
                  la.batno,
                  ljc.riskcode,
                  ljc.makedate,
                  ljc.enteraccdate
        union
        select '2' busitype,
               c.grpcontno,
               c.managecom,
               a.clmno,
               a.inqno,
               a.batno,
               c.riskcode,
               b.endcasedate,
               '' enteraccdate,
               nvl((select sum(lq.feesum)
                     from Llinqfee lq
                    where a.clmno = lq.clmno
                      and a.inqno = lq.inqno),
                   0) inqmoney, --调查总费用
               0 riskrealpay,
               0 sumrealpay,
               nvl((select sum(p.sumprem)
                     from lcgrppol p
                    where p.grpcontno = c.grpcontno
                      and p.riskcode = c.riskcode),
                   0) risksumprem, --险种累计保费
               nvl((select sum(p.sumprem)
                     from lcgrppol p
                    where p.grpcontno = c.grpcontno),
                   0) sumprem --保单累计总保费
          from llinqapply a, LLRegister b, lcgrppol c
         where a.clmno = b.rgtno
           and b.grpcontno = c.grpcontno
           and exists (select 1
                  from llinqconclusion lli
                 where lli.clmno = a.clmno
                   and lli.batno = a.batno
                   and lli.finiflag = '1' --调查完成标志
                   and lli.inqconclusion = '1') --1-通过   2-不通过
           and exists (select 1
                  from llclaim d
                 where d.clmno = a.clmno
                   and d.clmstate in ('60', '70', '80'))
           and nvl((select sum(l.pay)
                     from LJAGetClaim l
                    where a.clmno = l.otherno
                      and l.othernotype = '5'),
                   0) = 0
         group by c.grpcontno,
                  c.managecom,
                  a.clmno,
                  a.inqno,
                  a.batno,
                  c.riskcode,
                  b.endcasedate
       union
       select '3' busitype,
       ljc.grpcontno, --团体保单号
       ljc.managecom, --管理机构
       lb.reportflag, --赔案号
       la.inqno, --调查号
       la.batno, --调查批次
       ljc.riskcode, --赔付险种
       ljc.makedate,
       to_char(ljc.enteraccdate, 'yyyy-mm-dd') enteraccdate,
       nvl((select sum(lq.feesum)
             from Llinqfee lq
            where la.clmno = lq.clmno
              and la.inqno = lq.inqno),
           0) inqmoney, --调查总费用
       nvl(sum(ljc.pay), 0) riskrealpay, --险种实际赔付金额
       nvl((select sum(l.pay)
             from LJAGetClaim l
            where lb.reportflag = l.otherno
              and l.othernotype = '5'),
           0) sumrealpay, --实际赔付总额
       nvl((select sum(p.sumprem)
             from lcgrppol p
            where p.grpcontno = ljc.grpcontno
              and p.riskcode = ljc.riskcode),
           0) risksumprem, --险种累计保费
       nvl((select sum(p.sumprem)
             from lcgrppol p
            where p.grpcontno = ljc.grpcontno),
           0) sumprem --保单累计总保费
  from LLInqApply la, LJAGetClaim ljc, llgrpreportsub lb
 where 1 = 1
   and la.clmno = lb.serialno
   and la.customerno = lb.customerno
   and lb.reportflag = ljc.otherno
   and ljc.othernotype = '5'
   and la.beforeflag = '1'--前置调查
   and exists (select 1
          from llinqconclusion lli
         where lli.clmno = la.clmno
           and lli.batno = la.batno
           and lli.finiflag = '1' --调查完成标志
           and lli.inqconclusion = '1' --1-通过   2-不通过
           and lli.beforeflag = '1')
 group by ljc.grpcontno,
          ljc.managecom,
          la.clmno,
          lb.reportflag,
          la.inqno,
          la.batno,
          ljc.riskcode,
          ljc.makedate,
          ljc.enteraccdate
       union
       select '4' busitype,
       c.grpcontno,
       c.managecom,
       ld.reportflag,
       a.inqno,
       a.batno,
       c.riskcode,
       b.endcasedate,
       '' enteraccdate,
       nvl((select sum(lq.feesum)
             from Llinqfee lq
            where a.clmno = lq.clmno
              and a.inqno = lq.inqno),
           0) inqmoney, --调查总费用
       0 riskrealpay,
       0 sumrealpay,
       nvl((select sum(p.sumprem)
             from lcgrppol p
            where p.grpcontno = c.grpcontno
              and p.riskcode = c.riskcode),
           0) risksumprem, --险种累计保费
       nvl((select sum(p.sumprem)
             from lcgrppol p
            where p.grpcontno = c.grpcontno),
           0) sumprem --保单累计总保费
  from llinqapply a, LLRegister b, lcgrppol c, llgrpreportsub ld
 where a.clmno = ld.serialno
   and a.customerno = ld.customerno
   and b.rgtno = ld.reportflag
   and b.grpcontno = c.grpcontno
   and exists (select 1
          from llinqconclusion lli
         where lli.clmno = a.clmno
           and lli.batno = a.batno
           and lli.finiflag = '1' --调查完成标志
           and lli.inqconclusion = '1' --1-通过   2-不通过
           and lli.beforeflag = '1')
   and exists (select 1
          from llclaim d
         where d.clmno = b.rgtno
           and d.clmstate in ('60', '70', '80'))
   and nvl((select sum(l.pay)
             from LJAGetClaim l
            where b.rgtno = l.otherno
              and l.othernotype = '5'),
           0) = 0
   and a.beforeflag = '1' --前置调查
 group by c.grpcontno,
          c.managecom,
          a.clmno,
          ld.reportflag,
          a.inqno,
          a.batno,
          c.riskcode,
          b.endcasedate ) tt
 where 1 = 1
   and tt.inqmoney > 0
   and decode(tt.busitype, '1', tt.riskrealpay, 1) > 0
   and decode(tt.busitype, '1', tt.sumrealpay, 1) > 0
   and decode(tt.sumrealpay, 0, tt.sumprem, tt.sumrealpay) > 0
/
