CREATE VIEW DISTILLCLASS0000201VIEW AS select '0000201' classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) KeyUnionValue,
       a.MakeDate,
       a.ManageCom
  from grppolljagetendorse a
 where a.FeeOperationType not in ('ZT',
                                  '01',
                                  'CT',
                                  '08',
                                  'PT',
                                  '02',
                                  'LT',
                                  'RT',
                                  'FT',
                                  'WT',
                                  'RD',
                                  'CR',
                                  'XT',
                                  'MT')
   and a.FeeFinaType in ('TB', 'TF')
   and a.getmoney < 0
   AND EXISTS (SELECT 1
          FROM LMRiskApp app, lcgrppol l
         WHERE app.risktype4 = '3'
           AND app.risktype2 = 'L'
           and l.grppolno = a.GrpPolNo
           AND app.riskcode = l.riskcode)
   /*and not exists
 (select 1
          from LIDistillInfo li
         where li.classid IN ('0000201', '0000093')
           and li.KeyUnionValue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))*/
   and exists (select 'X'
          from Lpgrpedormain d
         where d.edoracceptno = a.endorsementno
           and d.balaflag = '0')
union
select '0000201' classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) KeyUnionValue,
       a.MakeDate,
       a.ManageCom
  from grppolljagetendorse a
 where 1 = 1
   and exists (select 1
          from lcgrppol c, LMRiskApp b
         where a.GrpPolNo = c.GrpPolNo
           and c.riskcode = b.riskcode
           and b.RiskPeriod != 'L'
           AND b.risktype4 = '3'
           AND b.risktype2 = 'L')
   and a.FeeOperationType in
       ('ZT', '01', 'CT', '08', 'PT', '02', 'RT', 'FT', 'XT')
   /*and not exists
 (select 1
          from LIDistillInfo li
         where li.classid IN ('0000201', '0000093')
           and li.KeyUnionValue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))*/
   and exists (select 'X'
          from Lpgrpedormain d
         where d.edoracceptno = a.endorsementno
           and d.balaflag = '0')
/
