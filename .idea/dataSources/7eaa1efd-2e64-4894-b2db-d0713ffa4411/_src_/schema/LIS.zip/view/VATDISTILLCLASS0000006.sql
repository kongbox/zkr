CREATE VIEW VATDISTILLCLASS0000006 AS select '0000006' as classid,
       (a.Grppolno || ',' || a.PayCount || ',' || a.PayNo || ',' ||
       a.PayType) as KeyUnionValue,
       a.managecom,
       greatest(a.ConfDate, b.cvalidate) as checkdate,
       a.endorsementno,
       a.riskcode,
       a.sumactupaymoney,
       a.grppolno,
       a.paycount,
       a.payno,
       a.paytype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype,
       b.tempfeeno,
       a.getnoticeno,
       b.paymode
  from ljapaygrp a, lcgrpcont b
 where a.grpcontno = b.grpcontno
   and nvl(b.standbyflag3, '0') <> '1'
   and a.paycount = 1
   and a.PayType in ('ZC', 'ZS')
   and not exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4', '8', '2'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000006'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.Grppolno || ',' || a.PayCount || ',' ||
               a.PayNo || ',' || a.PayType))
union
select '0000006' as classid,
       (a.Grppolno || ',' || a.PayCount || ',' || a.PayNo || ',' ||
       a.PayType) as KeyUnionValue,
       a.managecom,
       greatest(a.ConfDate, b.cvalidate) as checkdate,
       a.endorsementno,
       a.riskcode,
       a.sumactupaymoney,
       a.grppolno,
       a.paycount,
       a.payno,
       a.paytype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype,
       b.tempfeeno,
       a.getnoticeno,
       b.paymode
  from ljapaygrp a, lcgrpcont b
 where a.grpcontno = b.grpcontno
   and nvl(b.standbyflag3, '0') <> '1'
   and a.paycount = 1
   and a.PayType in ('ZC', 'ZS')
   and b.salechnl = '4'
   and b.agenttype = '08'
   and exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and exists (select 'x'
          from ljtempfee
         where otherno = a.grpcontno
           and riskcode = a.riskcode
           and nvl(paymode, 99) <> '8')
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4', '8', '2'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000006'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.Grppolno || ',' || a.PayCount || ',' ||
               a.PayNo || ',' || a.PayType))
union
select '0000006' as classid,
       (a.Grppolno || ',' || a.PayCount || ',' || a.PayNo || ',' ||
       a.PayType) as KeyUnionValue,
       a.managecom,
       greatest(a.ConfDate, b.cvalidate) as checkdate,
       a.endorsementno,
       a.riskcode,
       a.sumactupaymoney,
       a.grppolno,
       a.paycount,
       a.payno,
       a.paytype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype,
       b.tempfeeno,
       a.getnoticeno,
       b.paymode
  from ljapaygrp a, lcgrpcont b
 where a.grpcontno = b.grpcontno
   and nvl(b.standbyflag3, '0') <> '1'
   and a.paycount = 1
   and a.PayType = 'ZS'
   and b.salechnl != '4'
   and b.agenttype != '08'
   and exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and exists (select 'x'
          from ljtempfee
         where otherno = a.grpcontno
           and riskcode = a.riskcode
           and nvl(paymode, 99) <> '8')
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4', '8', '2'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000006'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.Grppolno || ',' || a.PayCount || ',' ||
               a.PayNo || ',' || a.PayType))
union
select '0000006' as classid,
       (b.polno || ',' || b.PayCount || ',' || a.PayNo || ',' || b.PayType) as KeyUnionValue,
       a.Managecom,
       greatest(a.ConfDate, d.cvalidate) as checkdate,
       a.otherno,
       b.RISKCODE,
       sum(b.SUMACTUPAYMONEY),
       b.polno,
       b.PayCount,
       a.PAYNO,
       b.PayType,
       a.INCOMENO,
       a.INCOMENO as bussno,
       'TB' as bussnotype,
       '',
       a.getnoticeno,
       d.paymode
  from ljapay a, ljapayperson b, lccollectioncontstate c, lccollection d
 where a.payno = b.payno
   and a.INCOMENO = b.contno
   and c.contno = b.contno
   and c.acceptno = d.acceptno
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000006'
           and i.flag = '1'
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (b.polno || ',' || b.PayCount || ',' ||
               a.PayNo || ',' || b.PayType))
 group by b.polno,
          b.PayCount,
          a.PAYNO,
          b.PayType,
          a.Managecom,
          a.ConfDate,
          d.cvalidate,
          a.otherno,
          b.RISKCODE,
          a.INCOMENO,
          a.getnoticeno,
          d.paymode
/
