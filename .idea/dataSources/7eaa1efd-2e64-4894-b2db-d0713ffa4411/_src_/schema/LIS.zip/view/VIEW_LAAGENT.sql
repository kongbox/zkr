CREATE VIEW VIEW_LAAGENT AS SELECT ManageCom,EmployDate,BranchType,AgentState,InDueFormDate,AgentCode,COUNT(*)  	FROM  	LAAgent  	GROUP BY  	ManageCom,EmployDate,BranchType,AgentState,InDueFormDate,AgentCode
/
