CREATE VIEW VATDISTILLCLASS0000123 AS select '0000123' as classid,
       (a.EndorsementNo || ',' || a.grpcontno || ',' || a.managecom || ',' ||
       b.riskcode) as KeyUnionValue,
       a.managecom,
       a.makedate as checkdate,
       a.EndorsementNo,
       b.riskcode,
       a.getmoney as SumActuPayMoney,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.PolNo,
       a.OtherNo,
       a.DutyCode,
       a.PayPlanCode,
       a.SubFeeOperationType,
       b.GrpPolNo,
       a.grpcontno,
       a.endorsementno as bussno,
       'BQ' as bussnotype
  from LJAGetEndorse a, LCGrpPol b
 where a.FeeOperationType = 'WT'
   and a.getmoney < 0
   and a.GrpContNo = b.GrpContNo
   and b.payintv in ('1', '3', '6')
   and exists (select 'x'
          from lmriskapp
         where riskcode = b.riskcode
           and risktype in ('A', 'H')
           and riskperiod = 'M')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000123'
           and i.flag = 1
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (a.EndorsementNo || ',' || a.grpcontno || ',' ||
               a.managecom || ',' || b.riskcode))
/
