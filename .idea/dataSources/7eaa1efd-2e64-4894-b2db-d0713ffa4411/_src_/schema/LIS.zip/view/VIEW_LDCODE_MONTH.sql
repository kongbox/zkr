CREATE VIEW VIEW_LDCODE_MONTH AS select codename name,decode(code,01,1,02,2,03,3,04,4,05,5,06,6,07,7,08,8,09,9,code) code from ldcode where codetype='Month' order by code
/
