CREATE VIEW SMP_JOB_TASK_INSTANCE AS select id, owner, task_level, task_sequence, clsid, display_name, length from SMP_JOB_TASK_INSTANCE_
   where user = owner WITH CHECK OPTION
/
