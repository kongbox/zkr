CREATE VIEW VIEW_LAWAGE_LATREE2 AS select a.f03, a.agentgrade, a.IndexCalNo, a.managecom
  from lawage a, latree b
 where a.AgentCode = b.agentcode
   and b.BranchType = 1
/
