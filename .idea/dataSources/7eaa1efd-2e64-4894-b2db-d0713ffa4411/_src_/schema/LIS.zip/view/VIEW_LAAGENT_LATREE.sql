CREATE VIEW VIEW_LAAGENT_LATREE AS select EmployDate,InDueFormDate,agentgrade,a.managecom,OutWorkDate,a.agentgroup,AgentState,StartDate,a.agentcode,a.branchcode
from LAAgent a,latree b where a.agentcode=b.agentcode
and a.BranchType='1'
/
