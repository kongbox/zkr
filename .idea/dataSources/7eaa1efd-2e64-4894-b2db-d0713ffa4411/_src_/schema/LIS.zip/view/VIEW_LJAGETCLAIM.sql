CREATE VIEW VIEW_LJAGETCLAIM AS SELECT ActuGetNo,OtherNoType,GetDutyCode,ConfDate,ManageCom,SaleChnl,RiskCode,SUM(Pay),COUNT(DISTINCT ActuGetNo)  	FROM  	LJAGetClaim  	GROUP BY  	ActuGetNo,OtherNoType,GetDutyCode,ConfDate,ManageCom,SaleChnl,RiskCode
/
