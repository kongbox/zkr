CREATE VIEW VATDISTILLCLASS0000071 AS select '0000071' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo || ',' ||
       a.SubFeeOperationType) as KeyUnionValue,
       a.ManageCom,
       a.MakeDate as checkdate,
       a.EndorsementNo,
       c.riskcode,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       c.grpcontno,
       a.EnterAccDate,
       a.GetConfirmDate,
       a.SubFeeOperationType,
       a.MakeDate,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype
  from grppolljagetendorse2 a, LCGrpPol c
 where a.GrpPolNo = c.GrpPolNo
   and a.FeeOperationType in ('ZT', 'CT', 'RT', 'RD', 'CR')
   and a.FeeFinaType in ('TB', 'TF')
   and a.SubFeeOperationType = 'P013'
   and a.getmoney <> 0
   and exists (select 1
          from LMRiskApp b
         where c.riskcode = b.riskcode
           and b.RiskType3 in ('3', '4'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000071'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue =
               (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' ||
               a.GrpPolNo || ',' || a.SubFeeOperationType))
/
