CREATE VIEW VIEW_LEIXING AS select clmdecision    from llclaimunderwrite_lmriskapp
/
