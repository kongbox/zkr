CREATE VIEW VATDISTILLCLASS0000173 AS select '0000173' classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.FeeOperationType || ',' ||
       a.FeeFinaType || ',' || b.GrpPolNo) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.endorsementno,
       b.riskcode,
       (select nvl(sum(f.SumMoney), 0)
          from grppollcinsureacctrace f
         where f.OtherType = '2'
           and f.MoneyType = 'BF'
           and f.SumMoney <> 0
           and f.GrpPolNo = b.grppolno
           and exists (select 'x'
                  from ljapaygrp j
                 where j.payno = f.otherno
                   and j.paycount = 1)
           and exists (select 'x'
                  from lmriskapp l
                 where l.riskcode = f.riskcode
                   and l.risktype3 = '2')) SumActuPayMoney,
       a.getmoney,
       a.actugetno,
       a.feefinatype,
       a.feeoperationtype,
       a.subfeeoperationtype,
       a.grpcontno,
       a.OtherNo,
       b.GrpPolNo,
       a.polno,
       a.payplancode,
       a.dutycode,
       a.endorsementno as bussno,
       'BQ' as bussnotype
  from LJAGetEndorse a, LCGrpPol b
 where a.FeeOperationType = 'WT'
   and exists (select 1
          from lmriskapp
         where 1 = 1
           and riskcode = b.riskcode
           and risktype3 = '2')
   and a.feefinatype = 'TB'
   and a.getmoney < 0
   and a.GrpContNo = b.GrpContNo
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000173'
           and i.flag = '1'
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' ||
               b.GrpPolNo))
/
