CREATE VIEW VIEW_LCPOL AS SELECT MainPolNo,CValiDate,ManageCom,PrtNo,SaleChnl,RiskCode,COUNT(DISTINCT MainPolNo),COUNT(DISTINCT PrtNo),SUM(Amnt)  	FROM  	LCPol  	GROUP BY  	MainPolNo,CValiDate,ManageCom,PrtNo,SaleChnl,RiskCode
/
