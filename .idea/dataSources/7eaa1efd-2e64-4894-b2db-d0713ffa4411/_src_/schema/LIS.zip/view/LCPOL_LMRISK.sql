CREATE VIEW LCPOL_LMRISK AS SELECT LCPol.MainPolNo,LCPol.CValiDate,LCPol.ManageCom,LCPol.PrtNo,LCPol.SaleChnl,LCPol.RiskCode,COUNT(DISTINCT LCPol.MainPolNo),COUNT(DISTINCT LCPol.PrtNo),SUM(LCPol.Amnt)  	FROM  	LCPol,LMRisk  	WHERE  	LCPol.RiskCode=LMRisk.RiskCode  	GROUP BY  	LCPol.MainPolNo,LCPol.CValiDate,LCPol.ManageCom,LCPol.PrtNo,LCPol.SaleChnl,LCPol.RiskCode
/
