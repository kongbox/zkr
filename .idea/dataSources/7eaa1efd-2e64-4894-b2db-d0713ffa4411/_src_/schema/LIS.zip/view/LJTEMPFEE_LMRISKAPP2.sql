CREATE VIEW LJTEMPFEE_LMRISKAPP2 AS select lcpol.polno,lcpol.prem,lcpol.MakeDate,lcpol.Agentcode,lcpol.Payintv,LMRiskApp.Riskperiod,lcpol.Riskcode,lcpol.managecom
 from LMRiskApp,lcpol
 where lcpol.Riskcode=LMRiskApp.Riskcode
 AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PolNo AND EnterAccDate IS NOT NULL)
 OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PrtNo AND EnterAccDate IS NOT NULL )
 OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.ProposalNo AND EnterAccDate IS NOT NULL))
 union  select lbpol.polno,lbpol.prem,lbpol.MakeDate,lbpol.Agentcode,lbpol.Payintv,LMRiskApp.Riskperiod,lbpol.Riskcode,lbpol.managecom
 from LMRiskApp,lbpol
 where lbpol.Riskcode=LMRiskApp.Riskcode
 AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = lbpol.polno AND EnterAccDate IS NOT NULL)
 OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.PrtNo AND EnterAccDate IS NOT NULL)
 OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.ProposalNo AND EnterAccDate IS NOT NULL))
/
