CREATE VIEW LJTEMPFEE_LMRISKAPP3 AS select LJTempFee.Paymoney,LJTempFee.MakeDate,LJTempFee.Agentgroup,LJTempFee.Payintv,LMRiskApp.Riskperiod from LJTempFee,LMRiskApp where LJTempFee.Riskcode=LMRiskApp.Riskcode and (LJTempFee.Tempfeetype='1' or LJTempFee.Tempfeetype='5' or LJTempFee.Tempfeetype='6')
/
