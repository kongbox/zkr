CREATE VIEW VATDISTILLCLASS0000140 AS select '0000140' classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.FeeOperationType || ',' ||
       a.FeeFinaType) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.endorsementno,
       nvl(riskcode,'000000') riskcode,
       a.getmoney as SumActuPayMoney,
       a.actugetno,
       a.feefinatype,
       a.feeoperationtype,
       a.grpcontno,
       a.OtherNo,
       a.othernotype,
       a.polno,
       a.subfeeoperationtype,
       a.payplancode,
       a.dutycode,
       (select l.payno from ljapay l where l.getnoticeno = a.getnoticeno) payno,
       a.endorsementno as bussno,
       'BQ' as bussnotype
  from LJAGetEndorse a
 where a.FeeOperationType = 'WT'
   and a.feefinatype = 'GB'
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000140'
           and i.flag = '1'
           and nvl(i.riskcode,'000000') = nvl(a.riskcode,'000000')
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType))
/
