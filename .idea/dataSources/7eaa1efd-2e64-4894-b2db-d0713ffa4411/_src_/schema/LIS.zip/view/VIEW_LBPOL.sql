CREATE VIEW VIEW_LBPOL AS SELECT MainPolNo,MakeDate,CValiDate,ManageCom,PrtNo,SaleChnl,RiskCode,COUNT(DISTINCT MainPolNo),COUNT(DISTINCT PrtNo),SUM(Amnt)  	FROM  	LBPol  	GROUP BY  	MainPolNo,MakeDate,CValiDate,ManageCom,PrtNo,SaleChnl,RiskCode
/
