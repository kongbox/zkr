CREATE VIEW VATDISTILLCLASS0000013 AS select '0000013' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) as KeyUnionValue,
       a.ManageCom,
       greatest(a.makedate, a.edorvalidate) as checkdate,
       a.EndorsementNo,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype,
       c.riskcode,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.MakeDate,
       a.edorvalidate,
       a.EnterAccDate,
       a.GetConfirmDate,
       c.grpcontno
  from grppolljagetendorse a, LCGrpPol c
 where a.FeeFinaType in ('BF', 'GL')
   and a.FeeOperationType <> 'RE'
   and exists (select 1
          from LMRiskApp b
         where b.riskcode = c.riskcode
           and b.risktype3 not in ('3', '4', '8', '2'))
   and a.grppolno = c.grppolno
   and a.getmoney > 0
   and not exists (select 'X'
          from Lpgrpedormain d
         where d.edoracceptno = a.endorsementno
           and d.balaflag = '0')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000013'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))
/
