CREATE VIEW LCPOL_LMRISKAPP2 AS select a.Prem,a.MakeDate,a.Agentgroup,a.Payintv,b.Riskperiod from lcpol a,LMRiskApp b where a.Riskcode=b.Riskcode and a.appflag='1'
/
