CREATE VIEW BATCHINGPRINTVIEW AS select "GRPCONTNO", "1"
  FROM (SELECT GrpContNo, 1
          FROM LCGrpCont A
         WHERE AppFlag = '1'
           and nvl(A.standbyflag1, '0') = '0'
           AND getprinttype(A.grpcontno) = '03'
           and (trunc(sysdate) - A.signdate) between 0 and 1
           and not exists (select 1
                  from print p
                 where p.otherno = A.grpcontno
                   and p.prttype = '7')
        union
        SELECT GrpContNo, 1
          FROM LCGrpCont A
         WHERE AppFlag = '1'
           and nvl(A.standbyflag1, '0') = '0'
           AND getprinttype(A.grpcontno) = '03'
           and exists (select 1
                  from print
                 where print.otherno = A.grpcontno
                   and print.prttype = '7')) s
 WHERE NOT EXISTS (SELECT 1
          FROM batchingprintlog ba
         WHERE s.grpcontno = ba.grpcontno
           AND ba.processtype = '1'
           AND ba.secondprint IS NULL
           AND nvl(ba.successflag, '1') = '1')
   AND NOT EXISTS (SELECT 1
          FROM HandPrintCheck h
         WHERE h.grpcontno = s.grpcontno
           AND h.printlink = '1'
           AND h.successflag IS NULL)
union
--送达书
SELECT "GRPCONTNO", "2"
  FROM (SELECT GrpContNo, 2
          FROM LCGrpCont A
         WHERE AppFlag = '1'
           AND nvl(PrintCount, 0) < 1
           AND getprinttype(a.grpcontno) = '03'
           and (trunc(sysdate) - A.signdate) between 0 and 1
           and not exists (select 1
                  from print p
                 where p.otherno = A.grpcontno || '_4'
                   and p.prttype = '5')
        union
        SELECT GrpContNo, 2
          FROM LCGrpCont A
         WHERE AppFlag = '1'
           AND nvl(PrintCount, '0') = '0'
           AND getprinttype(a.grpcontno) = '03'
           and exists (select 1
                  from print
                 where print.otherno = A.grpcontno || '_4'
                   and print.prttype = '5')) s
 WHERE NOT EXISTS (SELECT 1
          FROM batchingprintlog ba
         WHERE s.grpcontno = ba.grpcontno
           AND ba.processtype = '2'
           AND ba.secondprint IS NULL
           AND nvl(ba.successflag, '1') = '1')
   AND NOT EXISTS (SELECT 1
          FROM HandPrintCheck h
         WHERE h.grpcontno = s.grpcontno
           AND h.printlink = '2'
           AND h.successflag IS NULL)
union
--个人凭证
SELECT "GRPCONTNO", "3"
  FROM (select GrpContNo, 3
          from LCGrpCont a
         where AppFlag = '1'
           and pervouflag = '1'
           and exists
         (select 1
                  from lccont b
                 where grpcontno = a.grpcontno
                   and b.conttype != '1'
                   and b.appflag = '1'
                   and b.poltype = '0'
                   AND nvl(b.printcount, '0') = 0
                   AND getprinttype(b.grpcontno) = '03'
                   and exists
                 (select 1
                          from lcgrpcont
                         where grpcontno = b.grpcontno
                           and (trunc(sysdate) - lcgrpcont.signdate) between 0 and 1)
                   and not exists
                 (select 1
                          from lpedoritem
                         where lpedoritem.grpcontno = b.grpcontno
                           and lpedoritem.edortype = 'NI'
                           and lpedoritem.contno = b.contno)
                   and not exists
                 (select 1
                          from print
                         where print.prttype = '37'
                           and print.otherno = b.contno)
                union
                select 1
                  from lccont b
                 where grpcontno = a.grpcontno
                   and b.conttype != '1'
                   and b.appflag = '1'
                   and b.poltype = '0'
                   AND nvl(b.printcount, '0') = 0
                   AND getprinttype(b.grpcontno) = '03'
                   and exists (select 1
                          from print
                         where print.prttype = '37'
                           and print.otherno = b.contno)
                   and not exists
                 (select 1
                          from lpedoritem
                         where lpedoritem.grpcontno = b.grpcontno
                           and lpedoritem.edortype = 'NI'
                           and lpedoritem.contno = b.contno))) s
 where NOT EXISTS (SELECT 1
          FROM HandPrintCheck h
         WHERE h.grpcontno = s.grpcontno
           AND h.printlink = '3'
           AND h.successflag IS NULL)
   AND NOT EXISTS (SELECT 1
          FROM batchingprintlog ba
         WHERE s.grpcontno = ba.grpcontno
           AND ba.processtype = '3'
           AND ba.secondprint IS NULL
           AND nvl(ba.successflag, '1') = '1')
/
