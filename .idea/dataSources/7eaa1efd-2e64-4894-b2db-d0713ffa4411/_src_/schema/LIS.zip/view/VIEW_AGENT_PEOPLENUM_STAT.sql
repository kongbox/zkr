CREATE VIEW VIEW_AGENT_PEOPLENUM_STAT AS ( select count(*) agent_count,agentstate,employdate,QuafNo,branchtype     from laagent     group by agentstate,employdate,QuafNo,branchtype)
/
