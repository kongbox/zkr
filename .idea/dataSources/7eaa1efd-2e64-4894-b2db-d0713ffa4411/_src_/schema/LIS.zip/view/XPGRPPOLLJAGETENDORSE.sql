CREATE VIEW XPGRPPOLLJAGETENDORSE AS select a.ActuGetNo as ActuGetNo,
       a.EndorsementNo as EndorsementNo,
       a.ManageCom as ManageCom,
       a.FeeOperationType as FeeOperationType,
       a.FeeFinaType as FeeFinaType,
       a.polno as PolNo,
       a.EnterAccDate as EnterAccDate,
       a.GetConfirmDate as GetConfirmDate,
       a.MakeDate as MakeDate,
       sum(a.GetMoney) as GetMoney,
       b.edorvalidate as edorvalidate
  from LJAGetEndorse a, lpedormain b
 where  b.edorno = a.Endorsementno
  and a.contno=b.contno
   and a.polno is not null
   and a.polno != '000000' and exists(select 1 from lccollectioncontstate t where t.contno = a.contno)
 group by a.ActuGetNo,
          a.EndorsementNo,
          a.ManageCom,
          a.FeeOperationType,
          a.FeeFinaType,
          a.PolNo,
          a.EnterAccDate,
          a.GetConfirmDate,
          a.MakeDate,
          b.edorvalidate
/
