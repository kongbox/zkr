CREATE VIEW SMCLIENT_INSTALLATION_V AS select
  i.NamedObject_ID_sequenceID_ id,
  i.Installation_oracleHome_ oracle_home,
  i.Installation_language_ language,
  i.Installation_OS_ os,
  i.Installation_OSVersion_ os_version,
  c.NamedObject_ID_sequenceID_ client_id
from SMinstallation_s i, SMsharedoracleclient_s c, SMOwnerLinks o
where
  o.OwnerID = c.NamedObject_ID_sequenceID_ and
  o.OwneeID = i.NamedObject_ID_sequenceID_ and
  o.Association_ID_ = 30
/
