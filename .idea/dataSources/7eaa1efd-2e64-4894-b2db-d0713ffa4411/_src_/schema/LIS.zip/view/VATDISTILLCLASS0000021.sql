CREATE VIEW VATDISTILLCLASS0000021 AS select '0000021' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.FeeOperationType || ',' ||
       a.FeeFinaType || ',' || b.GrpPolNo) as KeyUnionValue,
       a.managecom,
       a.makedate as checkdate,
       a.EndorsementNo,
       b.riskcode,
       (select nvl(sum(sumactupaymoney),0)
          from ljapaygrp
         where grppolno = b.grppolno
           and paycount = 1
           and paytype = 'ZC') as SumActuPayMoney,
       a.getmoney,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       a.PolNo,
       a.DutyCode,
       a.PayPlanCode,
       a.SubFeeOperationType,
       a.otherno,
       a.othernotype,
       b.GrpPolNo,
       a.grpcontno,
       a.getnoticeno,
       a.endorsementno as bussno,
       'BQ' as bussnotype
  from LJAGetEndorse a, LCGrpPol b
 where a.FeeOperationType = 'WT'
   and not exists (select 1
          from lmriskapp
         where 1 = 1
           and riskcode = b.riskcode
           and risktype3 = '2')
   and a.feefinatype = 'TB'
   and a.getmoney < 0
   and a.GrpContNo = b.GrpContNo
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000021'
           and i.flag = '1'
           and i.riskcode = b.riskcode
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.FeeOperationType || ',' || a.FeeFinaType || ',' ||
               b.GrpPolNo))
/
