CREATE VIEW LJAPAYPERSON_LMRISK AS SELECT LJAPayPerson.PayIntv,LJAPayPerson.ConfDate,LJAPayPerson.ManageCom,LJAPayPerson.RiskCode,SUM(LJAPayPerson.SumActuPayMoney)     	FROM   	LJAPayPerson,LMRisk  	WHERE   	LJAPayPerson.RiskCode=LMRisk.RiskCode  	GROUP BY  	LJAPayPerson.PayIntv,LJAPayPerson.ConfDate,LJAPayPerson.ManageCom,LJAPayPerson.RiskCode
/
