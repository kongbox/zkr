CREATE VIEW VATDISTILLCLASS0000093 AS select '0000093' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.EndorsementNo,
       c.riskcode,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       c.grpcontno,
       a.MakeDate,
       a.GetConfirmDate,
       a.EnterAccDate,
       a.edorvalidate,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype
  from grppolljagetendorse a, LCGrpPol c
 where a.GrpPolNo = c.GrpPolNo
   and a.FeeOperationType not in
       ('ZT', '01', 'CT', '08', 'PT', '02', 'LT', 'RT', 'FT', 'WT', 'RD', 'CR', 'XT', 'MT')
   and a.FeeFinaType in ('TB', 'TF')
   and a.getmoney < 0
    --排除定期寿险
   AND NOT EXISTS (SELECT 1 FROM LMRiskApp app WHERE app.risktype4 = '3' AND app.risktype2 = 'L' AND app.riskcode = c.riskcode)
   and exists (select 'X'
          from Lpgrpedormain d
         where d.edoracceptno = a.endorsementno
           and d.balaflag = '0')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000093'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))
union
select '0000093' as classid,
       (a.ActuGetNo || ',' || a.EndorsementNo || ',' || a.ManageCom || ',' ||
       a.FeeOperationType || ',' || a.FeeFinaType || ',' || a.GrpPolNo) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.EndorsementNo,
       c.riskcode,
       a.GetMoney as SumActuPayMoney,
       a.GrpPolNo,
       a.ActuGetNo,
       a.FeeOperationType,
       a.FeeFinaType,
       c.grpcontno,
       a.MakeDate,
       a.GetConfirmDate,
       a.EnterAccDate,
       a.edorvalidate,
       a.EndorsementNo as bussno,
       'BQ' as bussnotype
  from grppolljagetendorse a, LCGrpPol c
 where a.GrpPolNo = c.GrpPolNo
   and a.FeeOperationType in
       ('ZT', '01', 'CT', '08', 'PT', '02', 'RT', 'FT', 'XT')
   and exists (select 1
          from LMRiskApp b
         where c.riskcode = b.riskcode
           and b.RiskPeriod != 'L')
      --排除定期寿险
   AND NOT EXISTS (SELECT 1 FROM LMRiskApp app WHERE app.risktype4 = '3' AND app.risktype2 = 'L' AND app.riskcode = c.riskcode)
   and exists (select 'X'
          from Lpgrpedormain d
         where d.edoracceptno = a.endorsementno
           and d.balaflag = '0')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000093'
           and i.flag = '1'
           and i.riskcode = c.riskcode
           and i.keyunionvalue = (a.ActuGetNo || ',' || a.EndorsementNo || ',' ||
               a.ManageCom || ',' || a.FeeOperationType || ',' ||
               a.FeeFinaType || ',' || a.GrpPolNo))
/
