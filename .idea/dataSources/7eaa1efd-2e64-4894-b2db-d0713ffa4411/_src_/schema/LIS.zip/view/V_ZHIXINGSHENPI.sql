CREATE VIEW V_ZHIXINGSHENPI AS select
  entityid,
  sp2spbs,
  sp2spyj,
  sp2spr,
  sp2spsj
from demo
/
