CREATE VIEW SMCLIENT_FOLDER_MAP_V AS select
     f.id folder_id,
     h.id client_id
from SMclient_only_folder_v f,
     SMBreakableLinks b,
     SMclient_v h
where
     f.id = b.lhsid
and  h.id = b.rhsid
/
