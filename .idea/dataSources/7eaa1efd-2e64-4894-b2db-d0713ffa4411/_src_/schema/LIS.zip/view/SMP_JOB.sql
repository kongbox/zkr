CREATE VIEW SMP_JOB AS select id, owner, name, type, service_id, schedule, machine_name, readonly,
  job_description, fixedit, library, JOB_TMPSCRIPTFILE from SMP_JOB_
  where user = owner WITH CHECK OPTION
/
