CREATE VIEW LRCLAIMPOLICY_LRRISK AS select
      lrclaimpolicy.REINSURECOM    lrclaimpolicy_REINSURECOM,
      lrrisk.risksort              lrclaimpolicy_risksort,
      lrclaimpolicy.ENDCASEDATE    lrclaimpolicy_CessStart,
	  lrclaimpolicy.rgtno          lrclaimpolicy_rgtno,
      count(lrclaimpolicy.rgtno)   count_lrclaimpolicy_rgtno,
      sum(lrclaimpolicy.realpay)   sum_lrclaimpolicy_realpay,
      sum(lrclaimpolicy.returnpay) sum_lrclaimpolicy_returnpay
from  lrrisk,lrclaimpolicy
where lrrisk.riskcode=lrclaimpolicy.riskcode
  and lrrisk.REINSURECOM=lrclaimpolicy.REINSURECOM
  and lrrisk.ReinsurItem=lrclaimpolicy.ReinsurItem
  and lrclaimpolicy.ReinsurItem='L'
group by
      lrclaimpolicy.REINSURECOM ,
	  lrclaimpolicy.ENDCASEDATE,
	  lrrisk.risksort,
	  lrclaimpolicy.rgtno,
      lrclaimpolicy.realpay,
      lrclaimpolicy.returnpay
/
