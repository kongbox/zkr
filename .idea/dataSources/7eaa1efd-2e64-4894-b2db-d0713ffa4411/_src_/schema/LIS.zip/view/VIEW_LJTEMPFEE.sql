CREATE VIEW VIEW_LJTEMPFEE AS SELECT AgentCode,PayIntv,TempFeeType,ConfMakeDate,ManageCom,SUM(PayMoney),COUNT(DISTINCT OtherNo)  	FROM  	LJTempfee  	GROUP BY  	AgentCode,PayIntv,TempFeeType,ConfMakeDate,ManageCom
/
