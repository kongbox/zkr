CREATE VIEW VATDISTILLCLASS0000139 AS select '0000139' classid,
       (a.grpcontno || ',' || a.endorsementno || ',' || a.ManageCom || ',' ||
       to_char(a.makedate, 'YYYY-MM-DD') || ',' || a.ActuGetNo) as KeyUnionValue,
       a.ManageCom,
       a.makedate as checkdate,
       a.endorsementno,
       a.riskcode,
       a.getmoney as SumActuPayMoney,
       a.actugetno,
       a.feefinatype,
       a.feeoperationtype,
       a.grpcontno,
       a.OtherNo,
       a.othernotype,
       a.polno,
       a.subfeeoperationtype,
       a.payplancode,
       a.dutycode,
       (select l.payno from ljapay l where l.getnoticeno = a.getnoticeno) payno,
       a.endorsementno as bussno,
       'BQ' as bussnotype
  from ljagetendorse a
 where 1 = 1
   and a.feeoperationtype = 'LR'
   and exists (select 'X'
          from lpgrpedormain
         where 1 = 1
           and edorno = a.endorsementno
           and balaflag = '0')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000139'
           and i.flag = '1'
           and nvl(i.riskcode,'000000') = nvl(a.riskcode,'000000')
           and i.keyunionvalue =
               (a.grpcontno || ',' || a.endorsementno || ',' || a.ManageCom || ',' ||
               to_char(a.makedate, 'YYYY-MM-DD') || ',' || a.ActuGetNo))
/
