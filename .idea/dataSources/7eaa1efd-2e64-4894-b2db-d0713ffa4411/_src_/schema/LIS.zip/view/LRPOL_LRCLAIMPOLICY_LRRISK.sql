CREATE VIEW LRPOL_LRCLAIMPOLICY_LRRISK AS select
      lrpol.REINSURECOM            lrpol_REINSURECOM,
      lrrisk.risksort              lrpol_risksort,
	  lrpol.polno                  lrpol_polno,
      lrclaimpolicy.rgtno          lrclaimpolicy_rgtno,
      lrpol.MAKEDATE               lrpol_MAKEDATE,
	  count(lrpol.polno)           count_lrpol_polno,
      count(lrclaimpolicy.rgtno)   count_lrclaimpolicy_rgtno,
      sum(lrpol.amnt)              sum_lrpol_amnt,
      sum(lrpol.prem)              sum_lrpol_prem,
      sum(lrpol.cessionamount)     sum_lrpol_cessionamount,
	  sum(lrpol.cessprem)          sum_lrpol_cessprem,
      sum(lrpol.cesscomm)          sum_lrpol_cesscomm,
      sum(lrclaimpolicy.realpay)   sum_lrclaimpolicy_realpay,
      sum(lrclaimpolicy.returnpay) sum_lrclaimpolicy_returnpay
from lrrisk,lrpol,lrclaimpolicy
where
      lrrisk.riskcode=lrpol.riskcode
	  and lrrisk.REINSURECOM=lrpol.REINSURECOM
	  and lrrisk.ReinsurItem=lrpol.ReinsurItem
	  and lrpol.POLNO=lrclaimpolicy.polno
	  and lrpol.REINSURECOM=lrclaimpolicy.REINSURECOM
	  and lrpol.ReinsurItem=lrclaimpolicy.ReinsurItem
	  and lrpol.ReinsurItem='L'
group by
         lrpol.REINSURECOM ,
		 lrpol.MAKEDATE,
		 lrrisk.risksort,
		 lrpol.polno,
         lrpol.amnt,
         lrpol.prem,
         lrpol.cessionamount,
         lrpol.cessprem,
         lrpol.cesscomm,
		 lrclaimpolicy.rgtno,
         lrclaimpolicy.realpay,
         lrclaimpolicy.returnpay
/
