CREATE VIEW LJAPAYPERSON_LMRISKAPP2 AS select a.SumActuPayMoney,a.MakeDate,a.Agentgroup,a.Payintv,b.Riskperiod,a.AGENTCODE,paycount
from LMRiskApp b,LJAPayPerson a where a.Riskcode=b.Riskcode and a.paytype='ZC'
/
