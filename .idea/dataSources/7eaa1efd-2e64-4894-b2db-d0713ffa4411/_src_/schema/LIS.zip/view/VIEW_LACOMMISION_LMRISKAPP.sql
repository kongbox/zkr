CREATE VIEW VIEW_LACOMMISION_LMRISKAPP AS select distinct a.riskcode,riskname,branchattr from lacommision a,lmriskapp b where a.riskcode=b.riskcode
/
