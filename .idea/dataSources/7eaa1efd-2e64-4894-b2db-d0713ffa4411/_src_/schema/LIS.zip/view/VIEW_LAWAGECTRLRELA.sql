CREATE VIEW VIEW_LAWAGECTRLRELA AS select distinct(a.polno),Destfactor,Originfactor,a.riskcode,a.agentgroup,a.makedate from ljapayperson a,Lmriskapp b,LAWageCtrlRela c where b.Subriskflag='M' and a.Riskcode=b.Riskcode and a.Riskcode=c.Riskcode
/
