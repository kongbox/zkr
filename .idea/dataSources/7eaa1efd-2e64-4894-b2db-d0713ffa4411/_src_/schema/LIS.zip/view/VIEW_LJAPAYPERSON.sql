CREATE VIEW VIEW_LJAPAYPERSON AS SELECT PayIntv,ConfDate,ManageCom,SUM(SumActuPayMoney)  	FROM   	LJAPayPerson  	GROUP BY  	PayIntv,ConfDate,ManageCom
/
