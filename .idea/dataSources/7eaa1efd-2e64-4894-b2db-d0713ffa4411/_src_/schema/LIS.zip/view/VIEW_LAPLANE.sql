CREATE VIEW VIEW_LAPLANE AS SELECT PlanValue,PlanType,PlanObject,PlanPeriodUnit,PlanPeriod  	FROM  	LAPlan  	GROUP BY  	PlanValue,PlanType,PlanObject,PlanPeriodUnit,PlanPeriod
/
