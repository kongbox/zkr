CREATE VIEW V_SHOULICHENGPI AS select
 entityid,
 slcpyj,
 slcpr,
  slcpsj
from demo
/
