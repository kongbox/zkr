CREATE VIEW VIEW_LAWAGE AS select managecom,agentgroup,IndexCalNo,f01,f02,f04,f21,f05,f03,f08,f07,f09,f10,f12,f15,f18,f13,f16,f19,f06,f14,f17,f30 from LAwage where BranchType=1
/
