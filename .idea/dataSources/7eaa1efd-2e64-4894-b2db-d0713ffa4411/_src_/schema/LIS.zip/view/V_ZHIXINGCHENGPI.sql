CREATE VIEW V_ZHIXINGCHENGPI AS select
  entityid,
  zxcpyj,
  zxcpr,
  zxcpsj
from demo
/
