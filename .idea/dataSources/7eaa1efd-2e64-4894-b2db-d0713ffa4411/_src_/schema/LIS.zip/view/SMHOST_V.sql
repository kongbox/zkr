CREATE VIEW SMHOST_V AS select
  namedobject_id_sequenceid_ id,
  host_hostname_ hostname,
  host_rpcaddress_ rpcaddress,
  Host_FTPAddress_ FTPAddress,
  Host_OS_ os,
  Host_OSVersion_ os_version
from SMhost_s
/
