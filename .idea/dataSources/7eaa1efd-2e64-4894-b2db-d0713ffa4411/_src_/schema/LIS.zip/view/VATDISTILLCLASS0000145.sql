CREATE VIEW VATDISTILLCLASS0000145 AS select '0000145' as classid,
       (t.GrpPolno || ',' || t.OtherNo || ',' || t.OtherType || ',' ||
       to_char(t.makeDate, 'YYYY-MM-DD')) KeyUnionValue,
       t.ManageCom,
       t.MakeDate as checkdate,
       t.riskcode,
       t.otherno,
       t.othertype,
       t.sumfee,
       t.GrpPolno,
       t.MakeDate,
       (select p.grpcontno from LCGrpPol p where p.grppolno = t.GrpPolNo) as bussno,
       'TB' as bussnotype
  from (select a.riskcode,
               a.otherno,
               a.OtherType,
               a.grppolno,
               a.managecom,
               sum(sumfee) sumfee,
               a.makedate
          from grppollcinsureaccfeetrace a
         where a.sumfee > 0
           and exists (select 1
                  from lmriskfee l
                 where l.feeitemtype = '01'
                   and l.feetakeplace = '01'
                   and l.feecode = a.FeeCode)
           and exists (select 1
                  from lmriskapp r
                 where r.riskcode = a.RiskCode
                   and r.risktype6 = '8')
         group by a.grppolno,
                  a.riskcode,
                  a.otherno,
                  a.OtherType,
                  a.managecom,
                  a.makedate) t
 where not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000145'
           and i.flag = '1'
           and i.riskcode = t.RiskCode
           and i.keyunionvalue =
               (t.GrpPolno || ',' || t.OtherNo || ',' || t.OtherType || ',' ||
               to_char(t.makeDate, 'YYYY-MM-DD')))
/
