CREATE VIEW LLCLAIMPAYTIMEOUTVIEW_1 AS select w."RGTNO",
       w."MNGCOM",
       w."SUBRGTNO",
       w."CUSTOMERNAME",
       w."ENDCASEDATE",
       w."REALPAY"
  from (select distinct a.rgtno,
                        a.mngcom,
                        (a.rgtno || a.customerno) subrgtno,
                        (select name
                           from lcinsured
                          where insuredno = a.customerno
                            and contno = a.contno) customername,
                        a.endcasedate,
                        (select nvl(sum(d.realpay), 0)
                           from llclaimdetail d
                          where d.clmno = a.caseno
                            and d.contno = b.contno
                            and d.givetype = '0') realpay
          from llclaim a, llclaimpolicy b
         where a.clmno = b.clmno
           and a.customerno = b.insuredno
           and a.contno = b.contno
           and a.clmstate = '60' --已结案状态
           and a.endcasedate is not null
              --排除拒付情况
           and not exists (select 1
                  from LLClaimUWMain m
                 where m.clmno = a.clmno
                   and m.insuredno = a.customerno
                   and m.auditconclusion = '1')
              --理赔给付将已到账的排除
           and not exists (select 1
                  from ljagetclaim c
                 where c.otherno = a.clmno
                   and c.othernotype = '5'
                   and c.contno = a.contno
                   and c.confdate is not null)
              --付费查询将已支付的数据排除
           and not exists (select 1
                  from LJAGet g, LJFIGet f
                 where g.actugetno = f.actugetno
                   and g.otherno = a.clmno
                   and g.confdate is not null)) w
 where w.realpay > 0
 order by w.endcasedate desc, w.mngcom, w.subrgtno
/
