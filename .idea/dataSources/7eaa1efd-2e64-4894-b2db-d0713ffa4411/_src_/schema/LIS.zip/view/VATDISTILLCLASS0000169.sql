CREATE VIEW VATDISTILLCLASS0000169 AS select '0000169' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType) as KeyUnionValue,
       a.Managecom,
       a.MakeDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.SumMoney as SumActuPayMoney,
       a.SumPriceDiff,
       a.PayNo,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.PayDate,
       a.MakeDate,
       a.ValueDate,
       (select count(1) from grppolljagetendorse g where g.EndorsementNo = a.OtherNo and g.GrpPolNo = a.GrpPolNo) datacount,
       a.OtherNo as bussno,
       'BQ' as bussnotype
  from grppollcinsureacctrace a
 where a.othertype = '4'
   and a.moneytype = 'BF'
   and a.summoney <> 0
   and exists (select 'x'
          from ljapaygrp
         where endorsementno = a.otherno
           and paytype = 'PG')
   and exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 = '2')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000169'
           and i.flag = '1'
           and i.riskcode = a.RiskCode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType))
/
