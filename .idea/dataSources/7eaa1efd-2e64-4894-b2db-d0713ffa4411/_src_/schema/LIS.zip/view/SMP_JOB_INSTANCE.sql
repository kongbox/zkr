CREATE VIEW SMP_JOB_INSTANCE AS select id, owner, agent_job_id, node, destination, destination_type, status,
	next_execution, parameters, group_name, state, EXECUTION
    from SMP_JOB_INSTANCE_ where owner = user WITH CHECK OPTION
/
