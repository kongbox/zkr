CREATE VIEW GRPPOLLCINSUREACCTRACE AS select RiskCode,OtherNo,OtherType,MoneyType,PayNo,
GrpPolNo,ManageCom,PayDate,MakeDate,ValueDate,sum(Money) as SumMoney,sum(PriceDiff) as SumPriceDiff from LCInsureAccTrace
where grpcontno != '00000000000000000000'  and moneytype<>'LX'
group by RiskCode,OtherNo,OtherType,MoneyType,PayNo,
GrpPolNo,ManageCom,PayDate,MakeDate,ValueDate
UNION
select RiskCode,OtherNo,OtherType,MoneyType,OtherNo,
GrpPolNo,ManageCom,PayDate,MakeDate,ValueDate,sum(Money) as SumMoney,sum(PriceDiff) as SumPriceDiff from LCInsureAccTrace
where grpcontno != '00000000000000000000'  and moneytype='LX'     ----?????payno????polno??????????????????????
group by RiskCode,OtherNo,OtherType,MoneyType,OtherNo,
GrpPolNo,ManageCom,PayDate,MakeDate,ValueDate
/
