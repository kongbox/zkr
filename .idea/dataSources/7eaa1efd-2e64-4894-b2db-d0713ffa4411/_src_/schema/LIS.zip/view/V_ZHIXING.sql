CREATE VIEW V_ZHIXING AS select
 entityid,
 money,
 field4,
 field5
from demo
/
