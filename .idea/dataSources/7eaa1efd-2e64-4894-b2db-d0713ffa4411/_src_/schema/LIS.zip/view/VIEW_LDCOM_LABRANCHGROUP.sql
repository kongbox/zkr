CREATE VIEW VIEW_LDCOM_LABRANCHGROUP AS select comcode code,name from LDCom
union   select branchattr code,name from labranchgroup where branchlevel='02'
and endflag<>'Y' and (state<>'1' or state is null)
/
