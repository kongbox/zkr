CREATE VIEW VATDISTILLCLASS0000175 AS select '0000175' as classid,
       (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.managecom || ',' || a.grppolno) as KeyUnionValue,
         a.managecom,
         a.grpcontno,
         a.grpcontno as bussno,
         a.grppolno,
         c.riskcode,
         greatest(a.ConfDate, b.cvalidate) as checkdate,
         c.CommonPrem as sumactupaymoney,
         a.paycount,
         a.payno,
         a.paytype,
         'TB' as bussnotype,
         c.serialno,
         c.commonmanagecom
  from ljapaygrp a, lcgrpcont b, LJACommonInsuRisk c
 where a.grpcontno = b.grpcontno
   and a.paycount = 1
   and a.PayType = 'ZC'
   and b.grpcontno = c.grpcontno
   and b.grpcontno = c.otherno
   AND a.riskcode = c.riskcode
   and c.othernotype = '21'
   and nvl(b.standbyflag3,'0') <> '1'
   and not exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4', '8', '2'))
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000175'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.managecom || ',' || a.grppolno))
union
select '0000175' as classid,
       (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.managecom || ',' || a.grppolno) as KeyUnionValue,
        a.managecom,
         a.grpcontno,
         a.grpcontno as bussno,
         a.grppolno,
         c.riskcode,
         greatest(a.ConfDate, b.cvalidate) as checkdate,
         c.CommonPrem as sumactupaymoney,
         a.paycount,
         a.payno,
         a.paytype,
         'TB' as bussnotype,
         c.serialno,
         c.commonmanagecom
  from ljapaygrp a, lcgrpcont b, LJACommonInsuRisk c
 where a.grpcontno = b.grpcontno
   and a.paycount = 1
   and a.PayType = 'ZC'
   and b.grpcontno = c.grpcontno
   and b.grpcontno = c.otherno
   AND a.riskcode = c.riskcode
   and c.othernotype = '21'
   and nvl(b.standbyflag3,'0') <> '1'
  and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000175'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.grpcontno || ',' ||(select codealias from ldcode t where t.codetype = 'commonmanage' and t.code = c.commonmanagecom) || ',' || a.managecom || ',' || a.grppolno))
   and b.salechnl = '4'
   and b.agenttype = '08'
   and exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and exists (select 'x'
          from ljtempfee
         where otherno = a.grpcontno
           and riskcode = a.riskcode
           and (paymode <> '8' or paymode is null))
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4', '8', '2'))
/
