CREATE VIEW C AS select grpcontno, agentcode from lacommisiondetail  where agentcode = '2'
/
