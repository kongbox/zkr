CREATE VIEW VATDISTILLCLASS0000088 AS select '0000088' as classid,
       (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType) as KeyUnionValue,
       a.Managecom,
       a.ValueDate as checkdate,
       a.OtherNo,
       a.RiskCode,
       a.SumMoney,
       a.SumPriceDiff as SumActuPayMoney,
       a.PayNo,
       a.MoneyType,
       a.OtherType,
       a.GrpPolNo,
       a.ValueDate,
       a.MakeDate,
       a.PayDate,
       a.OtherNo as bussno,
       'BQ' as bussnotype
  from grppollcinsureacctrace a
 where a.othertype = '4'
   and a.moneytype = 'BF'
   and a.summoney > 0
   and exists (select 'x'
          from lpedoritem
         where edorno = a.otherno
           and edortype in ('NI', 'NR'))
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 = '8')
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000088'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue =
               (a.GrpPolno || ',' || a.OtherNo || ',' || a.OtherType))
/
