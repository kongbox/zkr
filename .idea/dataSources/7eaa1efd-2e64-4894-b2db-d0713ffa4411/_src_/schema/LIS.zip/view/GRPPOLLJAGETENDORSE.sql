CREATE VIEW GRPPOLLJAGETENDORSE AS select a.ActuGetNo as ActuGetNo,
       a.EndorsementNo as EndorsementNo,
       a.ManageCom as ManageCom,
       a.FeeOperationType as FeeOperationType,
       a.FeeFinaType as FeeFinaType,
       a.GrpPolNo as GrpPolNo,
       a.EnterAccDate as EnterAccDate,
       a.GetConfirmDate as GetConfirmDate,
       a.MakeDate as MakeDate,
       sum(a.GetMoney) as GetMoney,
       b.edorvalidate as edorvalidate
  from LJAGetEndorse a, lpgrpedormain b
 where a.grpcontno != '00000000000000000000'
   and b.edorno = a.Endorsementno
   and a.grpcontno = b.grpcontno
   and a.polno is not null
   and a.polno != '000000'
 group by a.ActuGetNo,
          a.EndorsementNo,
          a.ManageCom,
          a.FeeOperationType,
          a.FeeFinaType,
          a.GrpPolNo,
          a.EnterAccDate,
          a.GetConfirmDate,
          a.MakeDate,
          b.edorvalidate
/
