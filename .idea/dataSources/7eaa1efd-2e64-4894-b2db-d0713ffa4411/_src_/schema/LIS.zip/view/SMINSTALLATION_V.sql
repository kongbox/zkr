CREATE VIEW SMINSTALLATION_V AS select
  i.NamedObject_ID_sequenceID_ id,
  i.Installation_oracleHome_ oracle_home,
  i.Installation_language_ language,
  i.Installation_OS_ os,
  i.Installation_OSVersion_ os_version,
  h.NamedObject_ID_sequenceID_ host_id
from SMinstallation_s i, SMhost_s h, SMOwnerLinks o
where
  o.OwnerID = h.NamedObject_ID_sequenceID_ and
  o.OwneeID = i.NamedObject_ID_sequenceID_ and
  o.Association_ID_ = 19
/
