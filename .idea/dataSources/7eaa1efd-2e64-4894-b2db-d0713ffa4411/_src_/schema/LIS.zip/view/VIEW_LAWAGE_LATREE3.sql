CREATE VIEW VIEW_LAWAGE_LATREE3 AS select a.f11, a.agentgrade, a.IndexCalNo, a.managecom, a.agentgroup
  from lawage a, latree b
 where a.AgentCode = b.agentcode
   and b.BranchType = 1
/
