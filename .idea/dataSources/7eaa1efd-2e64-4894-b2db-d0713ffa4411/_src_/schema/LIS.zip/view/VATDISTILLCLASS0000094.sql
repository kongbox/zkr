CREATE VIEW VATDISTILLCLASS0000094 AS select '0000094' as classid,
       (a.Grppolno || ',' || a.PayCount || ',' || a.PayNo || ',' ||
       a.PayType) as KeyUnionValue,
       a.managecom,
       greatest(a.ConfDate, b.cvalidate) as checkdate,
       a.endorsementno,
       a.riskcode,
       a.sumactupaymoney,
       a.grppolno,
       a.paycount,
       a.payno,
       a.paytype,
       a.grpcontno,
       a.grpcontno as bussno,
       'TB' as bussnotype
  from ljapaygrp a, lcgrpcont b
 where a.paycount = 1
   and a.PayType in ('ZC','ZS')
   and a.grpcontno = b.grpcontno
   and not exists (select 'x'
          from ljtempfeeclass
         where otherno = a.grpcontno
           and paymode = '8')
   and not exists (select 'x'
          from lmriskapp
         where riskcode = a.riskcode
           and risktype3 in ('3', '4'))
   and exists (select 'x'
          from lcgrpcont
         where standbyflag3 = '1'
           and grpcontno = a.grpcontno)
   and not exists
 (select 1
          from ljataxdetaillog i
         where i.classid = '0000094'
           and i.flag = '1'
           and i.riskcode = a.riskcode
           and i.keyunionvalue = (a.Grppolno || ',' || a.PayCount || ',' ||
               a.PayNo || ',' || a.PayType))
/
