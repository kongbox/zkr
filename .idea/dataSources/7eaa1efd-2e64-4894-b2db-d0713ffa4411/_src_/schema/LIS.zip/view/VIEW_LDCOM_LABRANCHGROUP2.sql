CREATE VIEW VIEW_LDCOM_LABRANCHGROUP2 AS select comcode code,shortname name from LDCom
union select branchattr code,name from labranchgroup where branchlevel='03'
and (state<>'1' or state is null)
/
