CREATE VIEW VIEW_POLLATREE AS select distinct agentgrade, agentgrade name
  from view_laagent_latree
 where agentgrade = 'A02'
    or agentgrade = 'A03'
    or agentgrade = 'A04'
    or agentgrade = 'A05'
    or agentgrade = 'A06'
    or agentgrade = 'A07'
    or agentgrade = 'A08'
    or agentgrade = 'A09'
    or agentgrade = 'A01'
/
