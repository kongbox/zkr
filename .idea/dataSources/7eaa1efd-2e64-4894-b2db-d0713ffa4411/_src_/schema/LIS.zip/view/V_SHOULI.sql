CREATE VIEW V_SHOULI AS select
 entityid,
 field1,
 field2,
 field3,
 slr,
 slsj
from demo
/
