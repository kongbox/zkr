CREATE function GetSexByIDNo(IDNo in varchar2)
return varchar2
as
  Sex varchar2(1);
  SexNo int;
  IDNolen varchar2(20);
begin
  select length(IDNo) into IDNolen from dual;
  if IDNolen = '15' then
    SexNo := cast(substr(IDNo,15,1) as int);
    if mod(SexNo,2) = 1 then
      Sex := '0';
    elsif mod(SexNo,2) = 0 then
      Sex := '1';
      end if;
  elsif IDNolen ='18' then
    SexNo := cast(substr(IDNo,17,1) as int);
    if mod(SexNo,2) = 1 then
      Sex :='0';
    elsif mod(SexNo,2) = 0 then
      Sex :='1';
    end if;
  end if;
  return Sex;
end;
/
