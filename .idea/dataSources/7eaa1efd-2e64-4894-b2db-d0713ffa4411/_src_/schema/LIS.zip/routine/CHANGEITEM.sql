CREATE FUNCTION     "CHANGEITEM" ( tPolNo in varchar2,tEdorNo in varchar2,tEdorType in varchar2) return NUMBER is
    t_NewInsuredName LPPol.InsuredName%TYPE ;
    t_NewInsuredSex LPPol.InsuredSex%TYPE ;
    t_NewInsuredAppAge LPPol.InsuredAppAge%TYPE ;
    t_NewInsuredBirthDay LPPol.InsuredBirthDay%TYPE ;
    t_OldInsuredName LPPol.InsuredName%TYPE ;
    t_OldInsuredSex LPPol.InsuredSex%TYPE ;
    t_OldInsuredAppAge LPPol.InsuredAppAge%TYPE ;
    t_OldInsuredBirthDay LPPol.InsuredBirthDay%TYPE ;
    t_Count  NUMBER ;
begin
  t_Count := 0;

--??????? ??????
select trim(InsuredName),trim(InsuredSex),trim(InsuredAppAge),trim(InsuredBirthDay)
    into
       t_NewInsuredName ,t_NewInsuredSex,t_NewInsuredAppAge,t_NewInsuredBirthDay
from LPPol
where polno = tPolNo and edorno = tEdorNo and edortype = tEdorType  ;
--??????????????
select trim(InsuredName),trim(InsuredSex),trim(InsuredAppAge),trim(InsuredBirthDay)
    into
       t_OldInsuredName ,t_OldInsuredSex,t_OldInsuredAppAge,t_OldInsuredBirthDay
from LCPol
where polno = tPolNo  ;
--????????
if t_NewInsuredName <> t_OldInsuredName then
   t_Count := t_Count+1;
end if ;
if t_NewInsuredSex <>  t_OldInsuredSex then
     t_Count := t_Count+1;
end if ;
if t_NewInsuredAppAge <>  t_OldInsuredAppAge then
    t_Count := t_Count+1;
end if ;
if t_NewInsuredBirthDay <>  t_OldInsuredBirthDay then
    t_Count := t_Count+1;
end if ;
return(t_Count);
END;

/
