CREATE FUNCTION "CALACCVALUE" (tGrpContNo in varchar2 ,tPolNo in varchar2, tPayPlanCode in varchar2,tPriceDate in Date) return Number is

   tAccountValue number:=0 ;
   tSellPrice number(12,8):=0;
   tBuyPrice number(12,8):=0;
   tRiskCode LCPol.RiskCode%Type;
   tUnitCount Lcinsureaccclass.Unitcount%Type;
   tActuPriceDate date; --?????
   tInsuAccNo lcinsureaccclass.insuaccno%Type;
begin

  if (tGrpContNo is null or tGrpContNo ='' or tGrpContNo = 'null') and (tPolNo is null or tPolNo ='' or tPolNo = 'null') then

   return 0;

   end if;

  if tgrpcontno is null or tgrpcontno ='' or tgrpcontno = 'null'  then

  select riskcode into triskcode from lcpol where polno=tpolno ;

  end if;

  if tPolNo is null or tPolNo ='' or tPolNo ='null'  then

  select riskcode into triskcode from lcpol where grpcontno=tgrpcontno and rownum=1;

  end if;

  Declare

  cursor c_insuaccNo is

    select insuaccno from lmriskaccpay where riskcode=tRiskCode and payplancode=tPayPlanCode order by insuaccno;

    begin

      open c_insuaccNo;

        loop

          fetch c_insuaccNo into tInsuAccNo;

          exit when c_insuaccNo%notfound;

          tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);

          tSellPrice :=getprice(tRiskCode,tInsuAccNo ,tActuPriceDate,'1');

           if tSellPrice is null then

            tSellPrice :=0;

           end if;

          if tGrpContNo is null or tGrpContNo ='' or tGrpContNo ='null' then --??????????,??????????????

            select riskcode into tRiskCode from lcpol where polno=tPolNo;

            select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where PolNo=tPolNo and PayPlanCode = tPayPlanCode and InsuAccNo=tInsuAccNo;



          else if tPolNo is null or tPolNo ='' or tPolNo='null' then --????,??????????,??????????????

             select riskcode into tRiskCode from lcpol where GrpContNo=tGrpContNo and rownum=1;

              tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);

              tSellPrice :=getprice(tRiskCode,tInsuAccNo ,tActuPriceDate,'1');

              if tSellPrice is null then

               tSellPrice :=0;

              end if;

             select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where GrpContNo=tGrpContNo and PayPlanCode = tPayPlanCode and InsuAccNo=tInsuAccNo and exists (select 'X' from lcpol where polno=lcinsureacctrace.polno and polstate='1');



         end if;

  end if;

       tAccountValue:=tAccountValue+tUnitCount;
        end loop;

      close c_insuaccNo;

  end;

  return(tAccountValue);

END;

/
