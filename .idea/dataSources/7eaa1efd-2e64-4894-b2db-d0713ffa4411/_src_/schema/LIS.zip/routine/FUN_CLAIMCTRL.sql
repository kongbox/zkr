CREATE FUNCTION     "FUN_CLAIMCTRL" (je_gf in number, contno in varchar2,dutycode in varchar2, conttype in varchar2,contplancode in varchar2) return number is
--???????????????????????????????
  Result number;
  tUplimit       lldutyctrllevel.uplimit%type;
  tDownlimit     lldutyctrllevel.downlimit%type;
  tRate          lldutyctrllevel.rate%type;
  tContNo        lldutyctrllevel.contno%type;
  tContType      lldutyctrllevel.conttype%type;
  tDutyCode      lldutyctrllevel.dutycode%type;
  tContPlanCode  lldutyctrllevel.contplancode%type;
  tminUplimit    lldutyctrllevel.uplimit%type;
  tminDownlimit  lldutyctrllevel.downlimit%type;
  tminRate       lldutyctrllevel.rate%type;
  cUplimit       lldutyctrllevel.uplimit%type;
  cDownlimit     lldutyctrllevel.downlimit%type;
  cRate          lldutyctrllevel.rate%type;

  begin
  Result:=0;
  tUpLimit:=0;
  tDownLimit:=0;
  tRate:=0;
  tContNo:=contno;
  tContType:=conttype;
  tDutyCode:=dutycode;
  tContPlanCode:=contplancode;
  tminUpLimit:=0;
  tminDownLimit:=0;
  tminRate:=0;
  cUpLimit:=0;
  cDownLimit:=0;
  cRate:=0;

  select min(UpLimit) into tminUpLimit from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
  select min(DownLimit) into tminDownLimit from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
  select min(Rate) into tminRate from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
  --?????????
  if Je_gf<=tminDownLimit then
     result:=Je_gf;
  else
     declare
        cursor c_rearrate is
        select UpLimit,DownLimit,Rate from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
        begin
           open c_rearrate;
           --????
           loop
              fetch c_rearrate into tUpLimit,tDownlimit,tRate;
              if c_rearrate%notfound then
                 exit;
              else
                 if je_gf>=tDownlimit and je_gf<=tUpLimit then
                    cUpLimit:=tUpLimit;
                    cDownLimit:=tDownlimit;
                    cRate:=tRate;
                    --??????????
                 end if;
              end if;
           end loop;
           close c_rearrate;
           --????
       end;
       if cUpLimit=0 and cDownLimit=0 and cRate=0 then
           declare
              cursor c_rearrate is
              select UpLimit,DownLimit,Rate from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
              begin
                 open c_rearrate;
                 loop
                     fetch c_rearrate into tUpLimit,tDownlimit,tRate;
                     if c_rearrate%notfound then
                         exit;
                     else
                         Result:=Result+(tUplimit-tDownlimit)*tRate;
                     end if;
                 end loop;
                 close c_rearrate;
              end;
       else
          declare
          cursor c_rearrate is
          select UpLimit,DownLimit,Rate from LLDutyCtrlLevel where ContNo=tContNo and ContType=tContType and DutyCode=tDutyCode and ContPlanCode=tContPlanCode;
          begin
             open c_rearrate;
                 loop
                     fetch c_rearrate into tUpLimit,tDownlimit,tRate;
                     if c_rearrate%notfound then
                        exit;
                     else
                        if tUpLimit<cUpLimit and tDownLimit<cDownLimit then
                            result:=result+(tUpLimit-tDownLimit)*tRate;
                        end if;
                     end if;
                 end loop;
             close c_rearrate;
         end;
 --??????????
         result:=result+(je_gf-cDownLimit)*cRate;
     end if;
  end if;
  return(Result);
end fun_claimctrl;

/
