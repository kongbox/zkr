CREATE FUNCTION     "ASSISSTANTRWD" (tagentcode in varchar2,twageno in varchar2,tareatype in varchar2, twagecode in varchar2,
                                         tbranchtype lawageradix.branchtype%type,tbranchtype2 in varchar2,
                                         tagentgrade in nvarchar2,tAgentState in varchar2) return number is

  cDepFYCSum               number(20,6):=0;
  cdrawrate                number(20,6):=0;
  cAssisstantRwd           number(20,6):=0;

 ---???????????
 begin
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;
   ---?????????
  select drawrate  into cdrawrate from lawageradix  --liujw: ?????????????
  where agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode and branchtype=tbranchtype
  and branchtype2=tbranchtype2;

  select  nvl(sum(a.DepFYCSum),0) into cDepFYCSum from laindexinfo a
  where a.indexcalno=twageno and a.indextype='00'  and branchtype='1' and branchtype2='01'
  and exists (select agentcode from larearrelation
              where rearagentcode=tagentcode and rearlevel='02' and rearflag='1' and agentcode=a.agentcode);
   cAssisstantRwd:=cDepFYCSum*cdrawrate;

-- declare
-- cursor c_AssisstantRwd is
--  select agentcode from larearrelation
--  where rearagentcode=tagentcode and rearlevel='02' and rearflag='1' and RearedGens='1'; --liujw: ????????????????????
  -- begin
  --  open c_AssisstantRwd;
  --    loop
  --     fetch c_AssisstantRwd into cagentcode;
  ---??????????????
 -- select nvl(sum(DepFYCSum),0) into cDepFYCSum from laindexinfo   --liujw: ?????exists?sql????????????????
 -- where indexcalno=twageno and indextype='00' and agentcode=cagentcode;
 -- SingleRwd:=cDepFYCSum*cdrawrate;
 -- cAssisstantRwd:=cAssisstantRwd+SingleRwd;
 --  end loop;
 --  close c_AssisstantRwd;
 -- end ;
  return (cAssisstantRwd);
end AssisstantRwd;

/
