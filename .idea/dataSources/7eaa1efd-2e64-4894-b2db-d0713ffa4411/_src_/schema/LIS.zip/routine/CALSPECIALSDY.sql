CREATE FUNCTION     "CALSPECIALSDY" (tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,tAgentGroup in varchar2,TempBegin in date, TempEnd in date) return number is
  FYC1   number := 0;
  FYC2   number := 0;
  tDrawRate number := 0;

  Result number := 0;
  ----??????????----
begin
  FYC1 := calspecial(tAgentCode,tAgentGroup,TempBegin,TempEnd,0,tAreaType);

  select nvl(sum(directwage),0) into FYC2 from lacommision
  where CommDire='1'
  and payyear <1
  and caldate>=TempBegin
        and caldate<=TempEnd
        and trim(agentcode) = trim(tAgentCode);

  select nvl(drawrate,0) into tDrawRate from lawageradix
  where trim(AreaType)=trim(tAreaType) and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;

  Result := ( FYC1 + FYC2 ) * tDrawRate;
  return(Result);
end CALSPECIALSDY;

/
