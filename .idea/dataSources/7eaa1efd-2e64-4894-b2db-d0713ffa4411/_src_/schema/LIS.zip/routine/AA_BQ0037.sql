CREATE FUNCTION     "AA_BQ0037" (tedorno in varchar2, tpolno in varchar2, tinsuredno in varchar2) return number is
  Result number;
  toldamnt number;
  tincramnt number;
  tamnt number;
  toldamnt182 number;
  tincramnt182 number;
  tamnt182 number;
begin
  Result:=0;
  select nvl((select sum(amnt) from lcpol where insuredno=tinsuredno and riskcode in (select riskcode from lmrisksort where risksorttype='6' and risksortvalue='0') and polstate='1'),0) into toldamnt from dual;
  select nvl((select chgamnt from lpedoritem where edorno =tedorno and polno=tpolno and edortype='AA' and (select riskcode from lppol where polno=tpolno and edorno=tedorno and edortype='AA') in (select riskcode from lmrisksort where risksorttype='6' and risksortvalue='0')),0) into tincramnt from dual;
  tamnt:=toldamnt+tincramnt;
  if tamnt>=500000 then
     Result:=1;
  end if;
  select nvl((select sum(amnt) from lcpol where insuredno=tinsuredno and riskcode='182' and polstate='1'),0) into toldamnt182 from dual;
  select nvl((select chgamnt from lpedoritem where edorno =tedorno and polno=tpolno and edortype='AA' and (select riskcode from lppol where polno=tpolno and edorno=tedorno and edortype='AA')='182'),0) into tincramnt182 from dual;
  tamnt182:=toldamnt182+tincramnt182;
  if tamnt182>=100000 then
     Result:=1;
  end if;
  return(Result);
end AA_BQ0037;

/
