CREATE FUNCTION     "ADVANCEREARGRPLABOR" (
       tagentcode in VARCHAR2,
       tbranchcode in VARCHAR2,
       tbranchseries in VARCHAR2,
       tempbegin in date,
       tempend in date) return integer is
-------------------??????????????---------------------------

  ACOUNT number(10,2):=0;
  rcount number(10,2):=0;
  rearcount  integer;
  countsum   number(10,2):=0;
  agentcount number(10,2):=0;
  monthnum integer;
  series     varchar(26);

begin
 --?????????
  monthnum:=getmonths(tempbegin,tempend);
  series:=substr(tbranchseries,1,25)||'%';
---??????????
 declare
 cursor c_count is
 select sum(nvl(CalCount,0)) from lacommision a
 where a.tmakedate>=tempbegin and a.tmakedate<=tempend
 and a.branchcode=tbranchcode and a.commdire='1' and a.p6=0
 group by a.agentcode;
 begin
  open c_count;
     loop
       fetch c_count into acount;
       exit when c_count%notfound;

        if acount is null then
           acount:=0;
        end if;
          if acount/monthnum>=1 then
             agentcount:=agentcount+1;
          end if;

     end loop;
   close c_count;
   end;


  --?????????????
  declare
    cursor c_rearcount is
     select sum(nvl(CalCount,0)) from lacommision a,larearrelation b
     where a.tmakedate>=tempbegin and a.tmakedate<=tempend
     and a.branchcode =b.agentgroup
     and b.rearlevel='01' and b.rearagentcode=tagentcode
     and b.rearflag='1' and b.state='0'
     --and (b.rearedgens=1 or b.rearedgens=2)
     and a.branchseries like series
     group by a.agentcode;
 begin
    open c_rearcount;
      loop
         fetch c_rearcount into rcount;
         exit when c_rearcount%notfound;
         if rcount is null then
            rcount:=0;
         end if;
            if rcount/monthnum>=1 then
               rearcount:=rearcount+1;
            end if;
      end loop;
      close c_rearcount;
 end;

  countsum:=agentcount+rearcount;
  return (countsum);
end AdvanceRearGrpLabor;

/
