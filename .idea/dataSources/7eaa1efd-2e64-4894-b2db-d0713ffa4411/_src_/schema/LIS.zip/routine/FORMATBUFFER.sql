CREATE FUNCTION     "FORMATBUFFER" (dEvlDateEnd in DATE,vManComCode in VARCHAR2) return VARCHAR2 is
     Result int;
     pragma autonomous_transaction;
BEGIN
 DECLARE
 v_row_liactuarybuffer liactuarybuffer%rowtype;
 v_row_lcinsured lcinsured%rowtype;
 v_int_temp integer;

 cursor v_cur_liactuarybuffer
 is select * from liactuarybuffer;

begin
     /*???LIActuaryBuffer??????*/
     execute immediate 'TRUNCATE TABLE LIActuaryBuffer';

     /*?????????????(LCCont,LCPol??????)?????Acturay?*/
     INSERT INTO LIActuaryBuffer
                        (ContNo,            /*01????*/
                         GrpContNo,         /*02??????*/
                         ContType,          /*03????*/
                         PeopleNo,          /*04????*/
                         RiskCode,          /*05????*/
                         PolNo,             /*06????*/
                         MainPolNo,         /*07????*/
                         SignDate,          /*08????*/
                         ManageCom,         /*09????*/
                         /*State,             10????*/
                         InterestDifFlag,   /*11????*/
                         InsuYear,          /*12????*/
                         InsuYearFlag,      /*13??????*/
                         CValiDate,         /*14??????*/
                         PayMode,           /*15????*/
                         PayYears,          /*16????*/
                         PayEndYearFlag,    /*17????????*/
                         Prem,              /*18??*/
                         Mult,              /*19??*/
                         Amnt,              /*20????*/
                         GetYear,           /*21????*/
                         GetYearFlag,       /*22??????*/
                         InsuredNo1        /*23???1???*/

                         )
         SELECT DISTINCT b.ContNo,          /*01????*/
                         b.GrpContNo,       /*02??????*/
                         b.ContType,        /*03????*/
                         NVL(substr(trim(b.InsuredNo),1,20),''), /*04????*/
                         b.RiskCode,        /*05????*/
                         b.PolNo,           /*06????*/
                         b.MainPolNo,       /*07????*/
                         b.SignDate,        /*08????*/
                         b.ManageCom,       /*09????*/
                         /*b.polState,        10????*/
                         b.InterestDifFlag, /*11????*/
                         b.InsuYear,        /*12????*/
                         b.InsuYearFlag,    /*13??????*/
                         b.CValiDate,       /*14??????*/
                         b.PayIntv,         /*15????*/
                         b.PayYears,        /*16????*/
                         b.PayEndYearFlag,  /*17????????*/
                         b.Prem,            /*18??*/
                         b.Mult,            /*19??*/
                         b.Amnt,            /*20????*/
                         b.GetYear,         /*21????*/
                         b.GetYearFlag,     /*22??????*/
                         b.InsuredNo       /*23???1???*/

     FROM lcinsured c,LCPol b
     WHERE c.ContNo=b.ContNo
       and c.insuredno=b.insuredno
       and c.sequenceno='1'
       --and b.SignDate>='2004-05-05'
       and ((trim(dEvlDateEnd) is null) or (b.SignDate<=dEvlDateEnd))
       and ((trim(vManComCode) is null) or (b.ManageCom like vManComCode || '%'))
     ORDER BY b.GrpContNo,b.ContNo,b.InsuredNo,b.RiskCode;

     delete from liactuarybuffer where length(trim(riskcode))=3;
     /*???????????*/
     SELECT count(*) into Result
     FROM LIActuaryBuffer;


     /*??????*/
        /*??????*/
         /*??*/
     UPDATE LIActuaryBuffer LIAB
     SET GetTimes=(select count(polno) from LJAGetDraw where LIAB.ContType='1' and LIAB.ContNo=ContNo and LIAB.PolNo=PolNo);
         /*??*/
     UPDATE LIActuaryBuffer LIAB
     SET GetTimes=(select count(polno) from LJAGetDraw where LIAB.ContType='2' and LIAB.GrpContNo=GrpContNo and LIAB.PolNo=PolNo);

         /*??????*/
     UPDATE LIActuaryBuffer LIAB
     SET ForeInterest=(select DestRate from LMRisk where trim(LIAB.RiskCode)=trim(RiskCode));

        /*????????*/
     UPDATE LIActuaryBuffer LIAB
     SET TotalBonus=(select sum(BonusAmnt) from LOEngBonusPol where LIAB.PolNo=PolNo );
        /*???????*/
        /*??*/
     UPDATE LIActuaryBuffer LIAB
     SET PayTimes=(select max(paycount) from LJAPayPerson where LIAB.ContType='1' and trim(LIAB.ContNo)=trim(ContNo) and trim(LIAB.polno)=trim(polno))
     WHERE LIAB.ContType='1';
        /*??*/
     UPDATE LIActuaryBuffer LIAB
     SET PayTimes=(select max(paycount) from LJAPayGrp where LIAB.ContType='2' and trim(LIAB.ContNo)=trim(ContNo) and trim(LIAB.polno)=trim(polno))
     WHERE LIAB.ContType='2';

       /*???????????*/
     UPDATE LIActuaryBuffer LIAB
     SET HealthPrem=(select sum(prem) from LCPrem where LIAB.PolNo=PolNo and PayPlanType='1'),
         OccPrem=(select sum(prem) from LCPrem where LIAB.PolNo=PolNo and PayPlanType='2');
     /*??????*/ /*?????????????DutyCode??????????GetDutyCode?????*/
     UPDATE LIActuaryBuffer LIAB
     SET GetMode=(select GetMode from LCGet where rownum=1 and LIAB.PolNo=PolNo);
     /*?????? */
     UPDATE LIActuaryBuffer LIAB
     SET GetCriterion=(select StandMoney from LCGet where rownum=1 and LIAB.PolNo=PolNo);


  --????
   open v_cur_liactuarybuffer;
   loop
        fetch v_cur_liactuarybuffer into v_row_liactuarybuffer;
        exit when v_cur_liactuarybuffer%NOTFOUND;

        --??????????
        select * into v_row_lcinsured
        from lcinsured
        where contno = v_row_liactuarybuffer.contno
        and SequenceNo='1'
        and rownum=1;

            v_row_liactuarybuffer.InsuredName1 := v_row_lcinsured.Name;
            v_row_liactuarybuffer.InsuredSex1 := v_row_lcinsured.sex;
            v_row_liactuarybuffer.InsuredBirthday1 := v_row_lcinsured.Birthday;
            v_row_liactuarybuffer.InsuredIDNo1 := v_row_lcinsured.IDNo;
            v_row_liactuarybuffer.InsuerdOccType1 := v_row_lcinsured.OccupationCode;


        select count(1) into v_int_temp
        from lcinsured
        where contno = v_row_liactuarybuffer.contno
        and SequenceNo='2';

        if v_int_temp <> 0 then
          select * into v_row_lcinsured
          from lcinsured
          where contno = v_row_liactuarybuffer.contno
          and SequenceNo='2'
          and rownum=1;

            v_row_liactuarybuffer.InsuredName2 := v_row_lcinsured.Name;
            v_row_liactuarybuffer.InsuredNo2 := v_row_lcinsured.insuredno;
            v_row_liactuarybuffer.InsuredSex2 := v_row_lcinsured.sex;
            v_row_liactuarybuffer.InsuredBirthday2 := v_row_lcinsured.Birthday;
            v_row_liactuarybuffer.InsuredIDNo2 := v_row_lcinsured.IDNo;
            v_row_liactuarybuffer.InsuerdOccType2 := v_row_lcinsured.OccupationCode;

        end if;

        update liactuarybuffer set row = v_row_liactuarybuffer
        where contno = v_row_liactuarybuffer.contno
        and riskcode=v_row_liactuarybuffer.riskcode
        and GrpContNo=v_row_liactuarybuffer.GrpContNo
        and PeopleNo=v_row_liactuarybuffer.PeopleNo;

   end loop;
   close v_cur_liactuarybuffer;
 end;


   /*??*/
     commit;
  return(Result);
exception
   when others then
   --?????????
   dbms_output.put_line('????:formatBuffer??????' || ' ???????: ' || sqlerrm);
   return('E???????: ' || sqlerrm);
end formatBuffer;

/
