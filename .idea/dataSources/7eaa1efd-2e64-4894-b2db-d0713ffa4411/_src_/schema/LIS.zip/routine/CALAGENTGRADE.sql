CREATE FUNCTION     "CALAGENTGRADE" (
       tBranchAttr labranchgroup.branchattr%TYPE,--????
       tCalDate date,   --????
       tAgentGrade latree.agentgrade%TYPE --????
       ) return number as   --????
v_Num number;


begin
select count(distinct agentcode) into v_Num from (
  select agentcode from LAtree a where agentgrade=tAgentGrade and startdate<=tCalDate
  and exists (select 'X' from labranchgroup b,laagent c where branchcode=b.agentgroup
  and c.branchtype='1' and (state<>'1' or state is null) and branchattr like tBranchAttr||'%'
  and c.agentcode=a.agentcode and c.EmployDate<=tCalDate and (OutWorkDate>tCalDate or OutWorkDate is null))
  union
  select agentcode from latreeb a where agentgrade=tAgentGrade and startdate<=tCalDate
  and removetype <> '05' and
  makedate >=(select makedate from lawage d where agentcode=a.agentcode and indexcalno=substr(tCalDate,0,4)||substr(tCalDate,6,2))
  and not exists (select 'Y' from latree c where a.agentcode=c.agentcode and c.startdate<=tCalDate)
  and exists (select 'X' from labranchgroup b,laagent c where branchcode=b.agentgroup
  and c.branchtype='1' and (state<>'1' or state is null) and branchattr like tBranchAttr||'%'
  and c.agentcode=a.agentcode and c.EmployDate<=tCalDate and c.agentstate<'03')
  )
  ;

return v_Num;
End CalAgentgrade;

/
