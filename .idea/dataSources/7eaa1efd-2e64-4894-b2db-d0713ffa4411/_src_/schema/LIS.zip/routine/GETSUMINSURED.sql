CREATE FUNCTION     "GETSUMINSURED" (tGrpContNo in varchar2)
return number is
Result number;
tSumAmnt number;--??????
begin
tSumAmnt := 0;
SELECT NVL(SUM(NVL(amnt,0)),0) into tSumAmnt FROM lcpol a WHERE NOT EXISTS (SELECT 'X' FROM lpedoritem WHERE edortype IN ('NI','NC') AND grpcontno=a.grpcontno AND contno=a.contno) AND a.grpcontno=tGrpContNo;
Result := tSumAmnt;
return(Result);
end getSUMINSURED;

/
