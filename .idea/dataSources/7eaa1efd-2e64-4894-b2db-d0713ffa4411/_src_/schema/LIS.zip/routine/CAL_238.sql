CREATE FUNCTION     "CAL_238" (Je_gf number) return number is
  Result number;
begin
  if Je_gf<=5000 then Result:=0.7 ;
  end if;
  if Je_gf>5000 and Je_gf<=10000 then Result:=0.75;
  end if;
  if Je_gf>10000 and Je_gf<=20000 then Result:=0.8;
  end if;
  if Je_gf>20000 and Je_gf<=40000 then Result:=0.9 ;
  end if;
  if Je_gf>40000 then Result:=0.95;
  end if;
  return(Result);
end cal_238;

/
