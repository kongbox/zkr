CREATE FUNCTION     "FNC_274" (Je_gf in number) return number
is
tR varchar2(20);
begin

  tR := '1';
  	if Je_gf >= '0' and Je_gf<= '1000' then
			tR := 0;
		end if;
		if Je_gf >= '1001' and Je_gf<= '5000' then
			tR := Je_gf*0.6;
		end if;
		if Je_gf >= '5001' and Je_gf<= '20000' then
			tR := Je_gf*0.7;
		end if;
		if Je_gf >= '2001' and Je_gf<= '40000' then
			tR := Je_gf*0.8;
		end if;
		if Je_gf >= '40001'  then
			tR := Je_gf*0.9;
		end if;
	return(tR);
end;

/
