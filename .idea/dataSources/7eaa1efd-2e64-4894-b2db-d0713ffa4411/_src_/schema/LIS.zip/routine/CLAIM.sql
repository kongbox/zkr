CREATE FUNCTION     "CLAIM" (PolNo1 in char) return integer is
  Result integer;
begin
  select count(*) into Result from llclaim where ClmNo in (select ClmNo from llclaimdetail where PolNo=PolNo1 and givetype='0' and CasePolType='01') and givetype='0';
  return(Result);
end Claim;

/
