CREATE FUNCTION     "GETAGENTGRADESERIES" (strAgentgrade In Latree.Agentgrade%Type) Return Lawelfareradix.Objecttype%Type Is
--??????????????????????????????????????????
--?????strAgentgrade ????
--????  ??????
    Result Lawelfareradix.ObjectCode%Type;
Begin
	--??
	If (strAgentgrade >= 'A101' And strAgentgrade <= 'A103') Then
		Result := '10';
	Elsif (strAgentgrade >= 'A104' And strAgentgrade <= 'A106') Then
		Result := '11';
	Elsif (strAgentgrade >= 'A201' And strAgentgrade <= 'A203') Then
		Result := '12';
	Elsif (strAgentgrade >= 'A301' And strAgentgrade <= 'A304') Then
		Result := '13';
	Elsif (strAgentgrade >= 'A311' And strAgentgrade <= 'A313') Then
		Result := '14';
  --??
  Elsif (strAgentgrade = 'B101') Then
    Result := '21';
	Elsif (strAgentgrade >= 'B111' And strAgentgrade <= 'B113') Then
		Result := '22';
 	Elsif (strAgentgrade >= 'B121' And strAgentgrade <= 'B123') Then
		Result := '23';
	Elsif (strAgentgrade >= 'B131' And strAgentgrade <= 'B133') Then
		Result := '24';
	Elsif (strAgentgrade >= 'B201' And strAgentgrade <= 'B203') Then
		Result := '25';
	Elsif (strAgentgrade >= 'B301' And strAgentgrade <= 'B303') Then
		Result := '26';
  --??
	Elsif (strAgentgrade >= 'C101' And strAgentgrade <= 'C102') Then
		Result := '31';
	Elsif (strAgentgrade >= 'C111' And strAgentgrade <= 'C113') Then
		Result := '32';
	Elsif (strAgentgrade >= 'C121' And strAgentgrade <= 'C123') Then
		Result := '33';
	Elsif (strAgentgrade >= 'C131' And strAgentgrade <= 'C133') Then
		Result := '34';
	Elsif (strAgentgrade >= 'C201' And strAgentgrade <= 'C203') Then
		Result := '35';
  --???
	Elsif (strAgentgrade >= 'G101' And strAgentgrade <= 'G143') Then
		Result := '41';
	Elsif (strAgentgrade >= 'G201' And strAgentgrade <= 'G213') Then
		Result := '42';
	Elsif (strAgentgrade >= 'C301' And strAgentgrade <= 'C303') Then
		Result := '43';
	End If;
	Return(Result);
End Getagentgradeseries;

/
