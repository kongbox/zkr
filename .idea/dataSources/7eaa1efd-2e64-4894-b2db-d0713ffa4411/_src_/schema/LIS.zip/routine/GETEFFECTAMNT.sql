CREATE FUNCTION     "GETEFFECTAMNT" (tGrpContNo in varchar2)
return number is
Result number;--getRiskEffectAmnt
tSumRiskAmnt number;--??????
tRiskAmnt number;--????
CURSOR tPolArr IS
              SELECT polno Polno FROM lcpol WHERE appflag='1' AND polstate='1' AND grpcontno=tGrpContNo;
begin
              tSumRiskAmnt := 0;
              tRiskAmnt := 0;
              FOR tPol IN tPolArr LOOP
                SELECT nvl(getRiskEffectAmnt(tPol.Polno),0) into tRiskAmnt FROM dual;
                tSumRiskAmnt := tSumRiskAmnt + tRiskAmnt;
              END LOOP;
  Result := tSumRiskAmnt;
  return(Result);
end getEffectAmnt;

/
