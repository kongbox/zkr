CREATE FUNCTION     "CALTLRATE" (
       tBranchType lawageradix1.branchtype%Type,
       tAgentGroup laagent.agentgroup%type,
       tWageNo lacommision.wageno%Type,
       tAgentCode laagent.agentcode%Type
  --???
) return number Is
  Result number:=0;

  num1 Number;
  num2 Number;

  wagemonth Number;
  tStartDate           date;
  tAStartDate          date;
  tEndDate            date;

begin

      wagemonth:=substr(tWageNo,5,2);
      if(wagemonth=6 or wagemonth=12 ) then

           select AStartDate into tAStartDate from labranchgroup where AgentGroup=tAgentGroup and BranchManager=tAgentCode;

           select StartDate,EndDate into tStartDate ,tEndDate from lastatsegment where stattype='3' and yearmonth=tWageNo;
           if((tAStartDate is not null) and (tAStartDate<tStartDate)) then

               --startdate:=to_char(add_months(to_date(tWageNo,'yyyymm'),-5),'yyyymm');

                   ---???????
                   select nvl(count(*),0) into num1 from laagent where  agentgroup= tAgentGroup and outworkdate>tStartDate
                   and outworkdate<tEndDate and (agentstate='03' or agentstate='04' or agentstate='05') and branchtype=tBranchType;
                   select nvl((select beginnumber  from LAAgentPower  where agentgroup= tAgentGroup and year=substr(to_char(tStartDate,'YYYYMMDD'),1,4) and month=substr(to_char(tStartDate,'YYYYMMDD'),5,2)),0) into num2 from dual;

                   ---?????????
                   if(num2=0) then
                   Result:=0;
                   else
                   Result:=num1/num2;
                   end if;
            end if;
        end if;
  Return(Result);
 end CALTLRATE;

/
