CREATE FUNCTION     "COMOLDWELFARE" (cAgentgrade in varchar2, cWageno in varchar2,
                                         cAgentcode in varchar2,
                                         cManagecom in varchar2) return number is
--?????????
  Result number(12,6) := 0;
  tDrawBase1 number(12,6) := 0;--????1
  tDrawBase2 number(12,6) := 0;--????2
  tToFormalRwd number(12,6) := 0;--??????
  tPosSdy    number(12,6) := 0;--?????
  tTeamDirManaSdy   number(12,6) := 0;--?????
  checknum integer:=0;--?????LAWelfareRadix?,??????????,1:??,??????????;??:?
begin
select count(*) into checknum from  LAWelfareRadix
where ManageCom=cManageCom and ObjectType='1' and ObjectCode=cAgentcode and AClass='06' and State='1';
if checknum<>1 then
   return(Result);
end if;
--????
  select nvl(DrawBase1,0),nvl(DrawBase2,0) into tDrawBase1,tDrawBase2 from LAWelfareRadix
  where ManageCom=cManagecom and ObjectType='1' and ObjectCode=cAgentcode and AClass='06' and State='1';
--??????
  select nvl(ToFormalRwd,0),nvl(PosSdy,0),nvl(TeamDirManaSdy,0) into tToFormalRwd,tPosSdy,tTeamDirManaSdy from LAINDEXINFO
  where IndexCalNo=cWageno and IndexType='01' and AgentCode=cAgentcode  and branchtype='1' and branchtype2='01';

--??????
if cAgentgrade like 'A1%' then
  Result:=tToFormalRwd*tDrawBase1;
  return(Result);
end if;
--??????
if cAgentgrade like 'A2%' then
  Result:=tPosSdy*tDrawBase1;
  return(Result);
end if;
--???????
if cAgentgrade like 'A3%' then
  Result:=tPosSdy*tDrawBase1+tTeamDirManaSdy*tDrawBase2;
  return(Result);
end if;

end COMOLDWELFARE;

/
