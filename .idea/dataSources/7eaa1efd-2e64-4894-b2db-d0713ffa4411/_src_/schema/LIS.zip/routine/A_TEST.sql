CREATE FUNCTION     "A_TEST" return varchar2 is
  tValue varchar2(8);
begin
  select (select agentcode from laagent where agentcode = 'liujw') into tValue
  from dual;
  return(tValue);
end A_test;

/
