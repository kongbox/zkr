CREATE function     getPrintType(f_grpcontno varchar2)
  return varchar2 is
  /**
  * create by duhaisong on 2016-10-26 10:55:55
  * 用于获取保单的出单方式
  */
  v_grpcont_lcjriskcode_count number; --保单建工险险种数量
  v_grpcont_lcnriskcode_flag  number; --非建工历史保单判断
  v_printType                 varchar2(10); --01 前台  02 电子  03-后台
  v_count                     number;
  v_background_count          number; --后台打印数量
begin
  --获取保单险种数量
  select count(1)
    into v_grpcont_lcjriskcode_count
    from lcgrppol l
   where l.grpcontno = f_grpcontno
     and exists (select 1
            from lcgrpcont c
           where l.grpcontno = c.grpcontno
             and c.appflag = '1')
     and exists (select 1
            from lmrisk lm
           where lm.riskcode = l.riskcode
             and lm.edorflag = '0');

  --该保单下不包含建工险险种，直接属于非建工险保单判断是哪种打印方式
  if v_grpcont_lcjriskcode_count = 0 then
    select count(1)
      into v_grpcont_lcnriskcode_flag
      from lcnjgpolprint lcn
     where lcn.grpcontno = f_grpcontno
       and exists (select 1
              from lcgrpcont c
             where lcn.grpcontno = c.grpcontno
               and c.appflag = '1');

    --非建工险历史保单，去建工险配置表中查询，此时只可能有电子保单，不可能有其他情况
    --不需要使用逐级查询，确定打印方式
    if v_grpcont_lcnriskcode_flag = 0 then
      select count(1)
        into v_count
        from lcgrppol     l,
             lcjgpolprint lcj
       where l.grpcontno = f_grpcontno
         and lcj.riskcode = l.riskcode
         and lcj.available = 'Y'
         and l.managecom like lcj.managecom || '%';

      --非建工险历史保单，在建工险配置表中查询到符合条件的数据
      if v_count > 0 then
        v_printType := '02';
      end if;
    else
      begin
        select decode(printtype,
                      0,
                      '03',
                      1,
                      '02')
          into v_printType
          from lcnjgpolprint lcn
         where lcn.grpcontno = f_grpcontno
           and exists (select 1
                  from lcgrpcont c
                 where lcn.grpcontno = c.grpcontno
                   and c.appflag = '1');
      exception
        when others then
          v_printType := '03';
      end;
    end if;
    --包含建工险险种，在建工险配置表中判断出单方式，需要进行逐级检查
  else

    --判断中支机构是否存在配置信息
    select count(1)
      into v_count
      from lcjgpolprint l,
           lcgrppol     lc
     where l.riskcode = lc.riskcode
       and lc.grpcontno = f_grpcontno
       and l.available = 'Y'
       and lc.managecom = l.managecom;

    --中支机构包含对应建工险情况
    if v_count > 0 then
      --获取配置为后台打印的数据量
      select count(1)
        into v_background_count
        from lcjgpolprint l,
             lcgrppol     lc
       where l.riskcode = lc.riskcode
         and lc.grpcontno = f_grpcontno
         and l.available = 'Y'
         and l.prop3 = '03'
         and lc.managecom = l.managecom;

      if v_background_count > 0 then
        v_printType := '03';
      else
        v_printType := '01';
      end if;

      --中支机构没有进行建工险配置，检查分支机构，不会查到总公司
    else
      select count(1)
        into v_background_count
        from lcjgpolprint l,
             lcgrppol     lc
       where l.riskcode = lc.riskcode
         and lc.grpcontno = f_grpcontno
         and l.available = 'Y'
         and l.prop3 = '03'
         and substr(lc.managecom,
                    1,
                    3) = l.managecom;

      if v_background_count > 0 then
        v_printType := '03';
      else
        --建工险后台打印没有配置，检查是否存在前台打印配置信息
        select count(1)
          into v_count
          from lcjgpolprint l,
               lcgrppol     lc
         where l.riskcode = lc.riskcode
           and lc.grpcontno = f_grpcontno
           and l.available = 'Y'
           and l.prop3 = '01'
           and lc.managecom like l.managecom || '%';
        if v_count > 0 then
          v_printType := '01';
          --前台打印配置信息也不存在，情况应该是对应险种未在中支及分支进行任何配置，默认为后台打印
          --生产环境所有数据已经配置，此现象目前应该不会存在
        else
          v_printType := '03';
        end if;
      end if;
    end if;
  end if;

  return(nvl(v_printType,
             '03'));

end getPrintType;

/
