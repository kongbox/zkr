CREATE FUNCTION     "BASEWAGE" (tagentcode in varchar2,tagentgrade in varchar2,
                                    tareatype in varchar2, tbranchtype lawageradix.branchtype%type,
                                    tbranchtype2 in varchar2,twagecode in varchar2,
                                    twageno in varchar2,tConnManagerState in varchar2,tAgentState in varchar2) return number  is
  Result          number(20,6):=0 ;
  cIndPrem        number(20,6):=0 ;  ---?????
  cGrpPrem        number(20,6):=0 ;  ---??????
  cDepPrem        number(20,6):=0 ;  ---??????
  cIndFycSum      number(20,6):=0 ;  ---???????
  cDirTeamFycSum  number(20,6):=0 ;  ---????????
  cDepFycSum      number(20,6):=0 ;  ---????????
  cRate1          number(20,6):=0 ;  ---????????????
  cRate2          number(20,6):=0 ;  ---????????????
  cRate3          number(20,6):=0 ;  ---?????????????
  cworkmonths     integer;           ---????
  cinitgrade      varchar2(4);

--??????
begin
  ---??(agentstate=0)?10??????????(agentstate=-1)????????????tConnManagerState=1
     if tAgentGrade <= 'A106' then
       if tAgentState in ('0','-1') then
         return 0;
       end if;
     elsif tAgentState = '0' then
       return 0;
     end if;

     --?????,--???????,
     --?????????--??????????,
     --?????????--??????????
     --????
     select nvl(T42,0),nvl(IndFycSum,0),nvl(T43,0),nvl(DirTeamFycSum,0),nvl(T44,0),nvl(DepFycSum,0),
            nvl(AddCount,0)
     into cIndPrem, cIndFycSum,cGrpPrem,cDirTeamFycSum,cDepPrem,cDepFycSum,cworkmonths from laindexinfo
     where indexcalno=twageno and indextype='00' and agentcode=tagentcode and branchtype='1' and branchtype2='01';

     ---??????????
     select initgrade into cinitgrade from latree where agentcode=tagentcode;
    --?????????
     if (tagentgrade='A101' or (cinitgrade='A101' and tagentgrade='A103') Or   (cinitgrade='A101' and tagentgrade='A102')) and cworkmonths<=3 then
        select nvl(rewardmoney,0) into Result from lawageradix
        where agentgrade='A101' and areatype=tareatype and branchtype=tbranchtype
              and branchtype2=tbranchtype2 and wagecode=twagecode and cIndPrem>=fycmin
              and cIndPrem<fycmax;
     else
         --????????
          if tagentgrade>='A104' and tagentgrade<='A106' then
             select nvl(drawrate,0) into cRate1 from lawageradix
             where agentgrade=tagentgrade and areatype=tareatype and branchtype=tbranchtype
                   and branchtype2=tbranchtype2 and wagecode=twagecode
                   and cIndPrem>=fycmin and cIndPrem<fycmax;
             Result:= cIndFycSum*cRate1;
             if (cinitgrade='A101' and cworkmonths<=3)
             then
              select nvl(rewardmoney,0) into cRate1 from lawageradix
              where agentgrade='A101' and areatype=tareatype and branchtype=tbranchtype
              and branchtype2=tbranchtype2 and wagecode=twagecode and cIndPrem>=fycmin
              and cIndPrem<fycmax;
              Result:=Result+cRate1;
              end if;

          else
             --????????
            if tagentgrade like 'A2%' then
               select nvl(drawrate,0) into cRate2 from lawageradix
               where agentgrade=tagentgrade and areatype=tareatype and branchtype=tbranchtype
                     and branchtype2=tbranchtype2 and wagecode=twagecode
                     and cGrpPrem>=fycmin and cGrpPrem<fycmax;
               Result:= cDirTeamFycSum*cRate2;
               if tagentgrade='A201' and (tConnManagerState='2' or tConnManagerState='3') then
                  Result:=0.5*Result;
               end if;
                if (cinitgrade='A101' and cworkmonths<=3)
             then
              select nvl(rewardmoney,0) into cRate1 from lawageradix
              where agentgrade='A101' and areatype=tareatype and branchtype=tbranchtype
              and branchtype2=tbranchtype2 and wagecode=twagecode and cIndPrem>=fycmin
              and cIndPrem<fycmax;
              Result:=Result+cRate1;
              end if;
            else
                --?????????
                if tagentgrade like 'A3%' then
                   select nvl(drawrate,0) into cRate3 from lawageradix
                   where agentgrade=tagentgrade and areatype=tareatype and branchtype=tbranchtype
                         and branchtype2=tbranchtype2 and wagecode=twagecode
                         and cDepPrem>=fycmin and cDepPrem<fycmax;
                   Result:= cDepFycSum*cRate3;
                    if tagentgrade='A301' and (tConnManagerState='2' or tConnManagerState='3') then
                       Result:=0.5*Result;
                    end if;
                end if;
            end if;
         end if;
    end if;
  return(Result);
end BaseWage;

/
