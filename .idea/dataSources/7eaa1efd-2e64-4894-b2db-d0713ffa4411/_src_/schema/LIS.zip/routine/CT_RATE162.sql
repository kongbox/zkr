CREATE FUNCTION     "CT_RATE162" (tpaydate in date,tedorvalidate in date,tGrpPolNo in varchar2) return number is
  Result number;
  tpassmonth number;
  tinterval integer;
  tcount integer;
  tAccountPassYears integer;
  tAccountValueRate number;
  tRiskCode varchar2(3);
begin
  Result:=0;
  select riskcode into tRiskCode from lcgrppol where grppolno=tGrpPolNo;
  select months_between(tedorvalidate,tpaydate) into tpassmonth from dual;
  select floor(tpassmonth/12) into tinterval from dual;
  select count(*) into tcount from LCGrpBonusSub where GrpPolNo=tGrpPolNo;
  if tcount=0 then
      if tRiskCode='162' then
          select nvl((select rate from rate_162_cv where tpassmonth>=downlimit and tpassmonth<uplimit),1) into result from dual;
      elsif tRiskCode='113' then
          select nvl((select rate from rate_113_cv where tpassmonth>=downlimit and tpassmonth<uplimit),1) into result from dual;
      end if;
  else
      declare
        cursor c_rearrate is
      select AccountValueRate,AccountPassYears from LCGrpBonusSub where GrpPolNo=tGrpPolNo order by AccountPassYears;
      begin
        open c_rearrate;
        loop
          fetch c_rearrate into tAccountValueRate,tAccountPassYears;
          if c_rearrate%notfound then
             exit;
          else
             if tinterval>=tAccountPassYears then
                Result:=tAccountValueRate;
             else
                return(Result);
             end if;
          end if;
        end loop;
        close c_rearrate;
      end;
  end if;
  return(Result);
end ct_rate162;

/
