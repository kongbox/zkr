CREATE FUNCTION     "CHANGEGETRATE610" (GetRate in number)
return number is v_tR number;
begin

	v_tR :=0.9;
	if GetRate = 0.7 then
		v_tR := 0.7;
	end if;

	return(v_tR);
end;

/
