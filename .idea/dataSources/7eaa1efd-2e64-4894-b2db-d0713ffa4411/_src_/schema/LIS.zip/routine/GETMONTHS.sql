CREATE FUNCTION     "GETMONTHS" ( CalBegin in date,CalEnd in date) return integer is
  MonthNum                integer ;
  days                    varchar2(2);
  monthbegin              date;
  tstartdate              date;
  tEmployLimit            number(20,6):=0;
begin
  ---??????
  days:=to_char(CalBegin,'dd');
  monthbegin:=last_day(CalEnd);
  tstartdate:=last_day(CalBegin);
  select to_number(varvalue) into tEmployLimit from lasysvar where vartype='EmployLimit';
  if days<=tEmployLimit then
    MonthNum:=months_between(monthbegin,tstartdate)+1;
  else
    MonthNum:=months_between(monthbegin,tstartdate);
  end if;
  return(MonthNum);
  end GetMonths;

/
