CREATE FUNCTION     "GETSYSVAR" (tSysVar in varchar2)
 return varchar2 is
  Result varchar2(20);
begin
  Result := '';
  SELECT sysvarvalue into Result FROM ldsysvar WHERE sysvar=tSysVar;
  return(Result);
end getSysVar;

/
