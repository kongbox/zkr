CREATE FUNCTION     "GETPUBDUTYRATE610" (Level in varchar2,BasLevel in varchar2)
return number is v_tR number;
begin

	v_tR :=0;
	if Level = '7' then
		v_tR := 0.045;
	end if;
	if Level = '8' then
	  if SUBSTR(BasLevel,6,1)='4' then
		v_tR := 0.08;
	  end if;
	  if SUBSTR(BasLevel,6,1)='5' then
		v_tR := 0.055;
	  end if;
	  if SUBSTR(BasLevel,6,1)='6' then
		v_tR := 0.035;
	  end if;
	end if;

	return(v_tR);
end;

/
