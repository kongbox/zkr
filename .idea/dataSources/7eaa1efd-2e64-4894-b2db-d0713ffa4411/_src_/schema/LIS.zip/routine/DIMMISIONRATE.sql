CREATE FUNCTION     "DIMMISIONRATE" (twagenoend in varchar2,tbranchcode in varchar2) return number is
-----------------??????----------------------------
  DimmisionRate number(12,6):=0;
  cnum          Integer;
  num           Integer;
begin
  ----?????????
  select count(distinct agentcode) into num from laassessaccessory
  where IndexCalNo=twagenoend and AssessType='00' and agentgroup=tbranchcode;

  ----???????????????
  select count(distinct agentcode) into cnum from laassessaccessory
  where indexcalno=twagenoend and AssessType='00' and agentgroup=tbranchcode
  and agentgrade1='00';

  DimmisionRate:=cnum/num;

  return(DimmisionRate);
end DimmisionRate;

/
