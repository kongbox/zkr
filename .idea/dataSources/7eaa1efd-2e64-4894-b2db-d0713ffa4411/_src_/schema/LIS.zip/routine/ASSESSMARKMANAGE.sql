CREATE FUNCTION     "ASSESSMARKMANAGE" (
       tAgentcode LAIndexInfo.Agentcode%TYPE, --?????
       tIndexCalNo integer   --????
       ) return number as   --??????
v_Mark number;

begin

select ((select nvl(T26,0)*70 from LAIndexInfo where  IndexCalNo=tIndexCalNo and IndexType='04' and AgentCode=tAgentcode)
+ (select nvl(sum(AssessMark),0)*0.1 from LAAssessMark where Assessym=tIndexCalNo and AssessMarkType='02' and AgentCode=tAgentcode)
+ (select nvl(sum(AssessMark),0)*0.2 from LAAssessMark where Assessym=tIndexCalNo and AssessMarkType='01' and AgentCode=tAgentcode)) into v_Mark
from ldsysvar where sysvar = 'onerow';

return v_Mark;

End AssessMarkManage;

/
