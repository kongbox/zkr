CREATE FUNCTION     GETENDRESON (tGrpContNo in varchar2)
return varchar2 is
Result varchar2(20);
tAppFlag varchar2(2);
begin
  Result := '';
  SELECT appflag into tAppFlag FROM lcgrpcont where grpcontno=tGrpContNo;
  IF (tAppFlag = '3') THEN
     Result := '1';--满期终止
     return(Result);
  end if;
  if tAppFlag = '4' THEN
  --判断保单的保全操作方式
    Result := '3';--退保
  ELSE
    Result := '';
  END IF;
  return(Result);
end GETENDRESON;

/
