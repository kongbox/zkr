CREATE FUNCTION     "CALGRPDEVELEMENT" (
       --tAgentGrade lawageradix1.agentgrade%Type,
       tBranchType lawageradix1.branchtype%Type,
       tAgentCode laagent.agentcode%Type,
       tWageNo lacommision.wageno%Type,
       tAgentGroup laagent.agentgroup%Type
  --??????
) return number Is
  Result number:=0;
  wagemonth Number;
  tll Number;
  jjl Number;
  tdepfyc Number;
  tAStartDate date;
  tStartDate date;

begin
  wagemonth:=substr(tWageNo,5,2);
  if(wagemonth=6 or wagemonth=12 ) then

       select StartDate into tStartDate from lastatsegment where stattype='3' and yearmonth=tWageNo;
       select AStartDate into tAStartDate from labranchgroup where AgentGroup=tAgentGroup and BranchManager=tAgentCode;

       if((tAStartDate is not null) and (tAStartDate<tStartDate)) then

          select nvl((select T72 From laindexinfo Where
                      indexcalno=tWageNo And IndexType='01' and
                      agentcode=tAgentCode And branchtype=tBranchType
                      And BranchType2='01' ),0),
                nvl((select T73 From laindexinfo Where
                      indexcalno=tWageNo And IndexType='01' and
                      agentcode=tAgentCode And branchtype=tBranchType
                      And BranchType2='01' ),0)
                Into jjl,tll
                from ldsysvar where sysvar='onerow';

            --??? ???
           if(jjl>0.7 and tll<0.3) then

                Select nvl(sum(fyc),0)*0.01 Into tdepfyc From lacommision
                         Where wageno>=to_char(add_months(to_date(tWageNo,'yyyymm'),-5),'yyyymm')
                         And wageno<=tWageNo And branchtype=tBranchType And commdire='1'
                       /*  And BranchAttr Like /*tBranchAttr*/
                         /*(Select trim(branchattr) From labranchgroup Where agentgroup =tAgentGroup)||'%' */
                        --???????
                         And agentgroup=tAgentGroup
                         And agentcode<>tagentcode;

                Result:=tdepfyc;
           else
                Result:=0;
           end if;
       end if ;
    end if;
  Return(Result);

end CALGRPDEVELEMENT;

/
