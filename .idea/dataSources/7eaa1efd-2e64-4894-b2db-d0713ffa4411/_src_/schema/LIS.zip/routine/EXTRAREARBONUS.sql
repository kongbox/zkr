CREATE FUNCTION     "EXTRAREARBONUS" (tagentcode in varchar2,tagentgrade in varchar2,
                                     tareatype in varchar,twageno in varchar2,
                                     twagecode in varchar2,tbranchtype lawageradix.branchtype%type,
                                     tbranchtype2 in varchar2,tAgentState in varchar2,tconnmanagerstate in varchar2) return number is

  ---???????,???????????

ExtraRearBonus          number(12,6):=0;
cdrawrate               lawageradix.drawrate%type;
cDirTeamFycSum          number(12,6):=0;
SingleBonus             number(12,6):=0;
cenddate                larearrelation.enddate%type;
cagentcode              laindexinfo.agentcode%type;
--extrarate               number(12,6):=0;
cconnsuccdate           date;
cagentgrade             varchar2(4);
cRearedGens             integer;
cstartdate              date;
--tConnSuccDate           date;
temploydate             date;
--tStartDate              date;
--tEndDate                date;
tEmployLimit            varchar2(4);
tDay                    varchar2(2);
Intv1                   integer:=0;
Intv2                   integer:=0;
cconnmanagerstate       varchar2(1);
calstart                varchar2(8);
calend                  varchar2(8);
calend1                 varchar2(8);
startdate1               varchar2(8);
enddate1                 varchar2(8);
rate                    number(12,6):=0;


begin
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;
  Intv1:=MonthNum(tagentcode,twageno,'S');
  declare
  cursor c_extrarear is

  select a.enddate,a.agentcode,a.RearedGens,b.connsuccdate,b.agentgrade,b.connmanagerstate,b.startdate from larearrelation a,latree b
  where a.rearagentcode=tagentcode and a.agentcode=b.agentcode and a.rearedgens<=2 and rearcommflag='1'
        and a.rearlevel='01' and a.state='0' ;

  begin
    open c_extrarear;
      loop
       fetch c_extrarear into cenddate,cagentcode,cRearedGens,cconnsuccDate,cagentgrade,cconnmanagerstate,cstartdate;
       exit when c_extrarear%notfound;
       if cagentcode is null then
       return 0;
       end if;
        Intv2:=MonthNum(cagentcode,twageno,'S');
        if (cconnmanagerstate='0' and tconnmanagerstate='0')
        or (cconnmanagerstate='3' and tconnmanagerstate='3')
        or (cconnmanagerstate='0' and tconnmanagerstate='3')
        or (cconnmanagerstate='3' and tconnmanagerstate='0')
        or (cagentgrade like 'A3%' and cconnmanagerstate='4' and Intv2>=7)
        or (tagentgrade like 'A3%' and tconnmanagerstate='4' and Intv1>=7 and cconnmanagerstate<>'4')
        then
            SingleBonus:=0;
        else

       ---??????????
        select employdate into temploydate from laagent where agentcode=cAgentCode;
        calstart:=to_char(temploydate,'yyyymm');

        tEmployLimit:=getEmployLimit('EmployLimit');
        tDay:=to_char(temploydate,'dd');
        if (tDay>tEmployLimit)
        then

        calend:=to_char(add_months(temploydate,3),'yyyymm');
        calend1:=to_char(add_months(temploydate,6),'yyyymm');
        else

         calend:=to_char(add_months(temploydate,2),'yyyymm');
         calend1:=to_char(add_months(temploydate,5),'yyyymm');
        end if;




        SingleBonus:=0;
        if ((cagentgrade like 'A3%' or cagentgrade like 'A2%') and tagentgrade like 'A3%')
        or (cagentgrade like 'A3%' and tagentgrade like 'A2%'
           and tconnmanagerstate='0'
           and (cconnmanagerstate='2' or cconnmanagerstate='4'))
        then
           if cconnmanagerstate='1' or tconnmanagerstate='1'
           or (cconnmanagerstate='2' and cagentgrade like 'A2%') then
               SingleBonus:=0;
           else
           if ((Intv2>0 and Intv2<=3 and cconnmanagerstate='4' )  or (Intv1>0 and Intv1<=3 and tconnmanagerstate='4' ) )
           then startdate1:=calstart;
                enddate1:=calend;

             elsif ((Intv2>4 and Intv2<=7 and cconnmanagerstate='4' )  or (Intv1>4 and Intv1<=7 and tconnmanagerstate='4' ) )
              then
              startdate1:=calstart;
              enddate1:=calend1;
              rate:=0.5;
              end if;

           end if;
        elsif (cagentgrade like 'A2%' and tagentgrade like 'A2%')
        or (cagentgrade like 'A3%' and tagentgrade like 'A2%' )
        then
           if cconnmanagerstate='1' or (cconnmanagerstate='2' and cagentgrade like 'A2%') or tconnmanagerstate='1' or tconnmanagerstate='2'
           or (cconnmanagerstate='0' and tconnmanagerstate='0')
           then
               SingleBonus:=0;
           elsif (cagentgrade like 'A3%' and cconnmanagerstate='2' and tconnmanagerstate='3' and tagentgrade like 'A2%') then
               startdate1:=calstart;
              enddate1:=calend;
              rate:=0.5;
              elsif (Intv2>0 and Intv2<=3 and cconnmanagerstate='4' )  or (Intv1>0 and Intv1<=3 and tconnmanagerstate='4' )
              then startdate1:=calstart;
                   enddate1:=calend;

           elsif (Intv2>4 and Intv2<=7 and cconnmanagerstate='4' )  or (Intv1>4 and Intv1<=7 and tconnmanagerstate='4' )
           then
              startdate1:=calstart;
              enddate1:=calend1;
              rate:=0.5;
           end if;



        elsif (cagentgrade like 'A1%' and cconnmanagerstate='4') or (tagentgrade like 'A1%' and tconnmanagerstate='4') then
           SingleBonus:=0;
        else
           rate:=1;
           startdate1:=calstart;
           enddate1:=calend1;
        end if;
          if  twageno<>to_char(add_months(cconnsuccDate,1),'yyyymm') then

              SingleBonus:=0;
          else
            ---???????????
            cDirTeamFycSum := 0;
            select sum(nvl(DirTeamFycSum,0)) into cDirTeamFycSum from laindexinfo
            where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
            --and indexcalno>=To_char(startdate,'000000') and indexcalno<=To_char(enddate,'000000');
            and indexcalno>=startdate1 and indexcalno<=enddate1;
            if cDirTeamFycSum<> 0 then
            ---??????????
            select nvl(drawrate,0) into cdrawrate from lawageradix
            where branchtype=tbranchtype and branchtype2=tbranchtype2
            and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
            and reartype=cRearedGens and drawstart=0;
            SingleBonus:=cDirTeamFycSum*cdrawrate*rate;
            else
            SingleBonus:=0;
            end if;
          end if;
         end if;
              ExtraRearBonus:=ExtraRearBonus+SingleBonus;






       /*  ---??????????
        select employdate into temploydate from laagent where agentcode=cAgentCode;
        tEmployLimit:=getEmployLimit('EmployLimit');
        tDay:=to_date(temploydate,'DD');
        if (tDay>tEmployLimit)
        then
        tStartDate:=to_char(add_months(temploydate,1),'yyyymm');
        tEndDate:=to_char(add_months(temploydate,4),'yyyymm');
        else
         tStartDate:=to_char(temploydate,'yyyymm');
         tEndDate:=to_char(add_months(temploydate,3),'yyyymm');
        end if;
        if (cconnmanagerstate='2' and twageno=tEndDate and cagentgrade='A301')
        or (cconnmanagerstate='4' and twageno=to_char(cconnsuccdate,'yyyymm')
        and getmonths(temploydate,cconnsuccdate)<=3)
        then
          ---???????????
            cDirTeamFycSum := 0;
            select sum(nvl(DirTeamFycSum,0)) into cDirTeamFycSum from laindexinfo
            where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
            and indexcalno<=to_char(cconnsuccdate,'yyyymm') ;
            if cDirTeamFycSum<> 0 then
            ---??????????
            select nvl(drawrate,0) into cdrawrate from lawageradix
            where branchtype=tbranchtype and branchtype2=tbranchtype2
            and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
            and reartype=cRearedGens and drawstart=0;
                if tagentgrade like 'A3%' or (tagentgrade like 'A2%'
                and (tconnmanagerstate='0' or tconnmanagerstate='4'))then
                     SingleBonus:=cDirTeamFycSum*cdrawrate;
                elsif cagentgrade>='A106' then
                    SingleBonus:=cDirTeamFycSum*cdrawrate*0.5;
                else
                   SingleBonus:=0;
                end if;
             end if;
        end if;
        if twageno=to_char(cconnsuccdate,'yyyymm') and cagentgrade like 'A2%'then
            SingleBonus:=0;
            Intv:=MonthNum(cagentcode,twageno,'S');
           ---?????????????,??????
            select nvl(startdate,'V'),nvl(ConnSuccDate,'C') into cstartdate,tConnSuccDate
            from latree where agentcode=tagentcode;

          if (tconnmanagerstate='0' and
               (\*1?A???B,A?????B?????B???????????A??B???A??????A1%??*\
                  (Intv>=0 and Intv<=4 and cagentgrade>='A201' and tagentgrade like'A1%'
                   and to_char(cstartdate,'yyyymm')<=to_char(cconnsuccdate,'yyyymm'))
                \*2?A??B,A?????B?????A??B?????A??A1%???B????????*\
                or(Intv>4 and Intv<=7 and cagentgrade>='A201' and tagentgrade like 'A1%'
                   and to_char(cstartdate,'yyyymm')<to_char(cconnsuccdate,'yyyymm'))))
               \*3?C??A,A??B?A B??????B???A??A1%??*\
             or (tconnmanagerstate='4' and Intv>4 and Intv<=7
                 and cagentgrade>='A201' and tagentgrade like 'A1%'
                 and to_char(tConnSuccDate,'yyyymm')<=to_char(cconnsuccdate,'yyyymm'))
          then

              SingleBonus:=0;
          else

           ---???????????
            cDirTeamFycSum := 0;
            select sum(nvl(DirTeamFycSum,0)) into cDirTeamFycSum from laindexinfo
            where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
            and indexcalno<=to_char(cconnsuccdate,'yyyymm') ;
            if cDirTeamFycSum<> 0 then
            ---??????????
            select nvl(drawrate,0) into cdrawrate from lawageradix
            where branchtype=tbranchtype and branchtype2=tbranchtype2
            and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
            and reartype=cRearedGens and drawstart=0;
            SingleBonus:=cDirTeamFycSum*cdrawrate;
            \*---A??B,A?????B?????A?B?????B????????
            if tconnmanagerstate='0' and Intv>4 and Intv<=7 and cagentgrade>='A201'
               and to_char(cstartdate,'yyyymm')=to_char(cconnsuccdate,'yyyymm')
            then
                 SingleBonus:=0.5*SingleBonus;
            end if;*\
            if Intv>=0 and Intv<=4 then
              extrarate:=1;
            elsif Intv>4 and Intv<=7 then
              extrarate:=0.5;
            end if;
            ExtraRearBonus:=ExtraRearBonus+SingleBonus*extrarate;
            end if;
           end if;
          end if;
        */
      end loop;

   close c_extrarear;
  end ;
return(ExtraRearBonus);
 end ExtraRearBonus;

/
