CREATE FUNCTION     "CALPIECECBBRANCH" (
       tStartDate date, --????
       tEndDate date,   --????
       tBranchattr labranchgroup.branchattr%TYPE
       ) return number is
LongRisk number;
ShortRisk number;
ShortRiskSm number;
v_Piece number;

begin
--??????
select nvl(count(distinct(a.polno)),0) into LongRisk from LMRiskApp b,ljapayperson a
where a.Riskcode=b.Riskcode and b.subriskflag='M' and b.Riskperiod='L'
and a.makedate>=tStartDate and a.makedate<=tEndDate
and agentgroup in (select agentgroup from labranchgroup where BranchType='1'
and branchattr like tBranchattr||'%')
;

--??????500???

select nvl(count(distinct(a.polno)),0) into ShortRisk from LMRiskApp b,ljapayperson a
where a.Riskcode=b.Riskcode and a.makedate>=tStartDate and a.makedate<=tEndDate
and agentgroup in (select agentgroup from labranchgroup where BranchType='1'
and branchattr like tBranchattr||'%')
and b.subriskflag='M' and b.Riskperiod<>'L'
and a.SumActuPayMoney>='500'
;

--??????500????
select nvl(sum(a.SumActuPayMoney),0)/500 into ShortRiskSm from LMRiskApp b,ljapayperson a
where a.Riskcode=b.Riskcode and  a.makedate>=tStartDate and a.makedate<=tEndDate
and agentgroup in (select agentgroup from labranchgroup where BranchType='1'
and branchattr like tBranchattr||'%')
and b.subriskflag='M' and b.Riskperiod<>'L' and a.SumActuPayMoney<'500'
;

 v_Piece:=LongRisk+ShortRisk+ShortRiskSm;

return v_Piece;
end CALPIECECBBranch;

/
