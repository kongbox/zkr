CREATE FUNCTION     "GETEFFECTPREM"(tGrpContNo in varchar2)
  return number is
  tPrem  number; --?????
  Result number; --????
begin
  /**       SELECT NVL(SUM(NVL(sumactupaymoney,0)),0) INTO tPrem FROM ljapaygrp WHERE paytype IN ('ZC','PG') AND grpcontno=tGrpContNo;*/
  select (select nvl(sum(sumactupaymoney), 0)
            from ljapaygrp
           where grpcontno = tGrpContNo
             and paytype in ('ZC', 'PG')) +
         (select nvl(sum(getmoney), 0)
            from ljagetendorse
           where grpcontno = tGrpContNo
             and endorsementno not in
                 (select edorno
                    from lpgrpedoritem
                   where grpcontno = tGrpContNo
                     and edortype in ('AG', 'PR', 'LR', 'AT', 'PG')))
    INTO tPrem
    from dual;
  Result := tPrem;
  return(Result);
end getEffectPrem;

/
