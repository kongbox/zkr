CREATE FUNCTION     "CALYEARENDBONUS" (YearMark varchar2,tLevel varchar2,YearBegin in varchar2, YearEnd in varchar2,tAgentCode varchar2,tAgentGrade varchar2,tAreaType varchar2,tWageCode varchar2) return number is
  tGroup         varchar2(255);
  tAttr          varchar2(255);
  tFoundDate     Date;
  tEndDate       date;
  tEmployDate    Date;
  tOff           number := 0;
  tLeft          number := 0;
  tFYC           number := 0;
  tAvgFYC        number := 0;
  tRate          number := 0;
  tMonths        number := 0;
  tIndueFormDate date;
  Result         number := 0;
  tDay           varchar2(10);
  tIntvl         integer;

  CURSOR c_View IS
    select * from LAHols
    where (trim(AClass) = '02' or trim(AClass) = '03' or trim(AClass) = '05')
          and LeaveDate <= to_date(YearEnd,'yyyy-mm-dd')
          and LeaveDate >= to_date(YearBegin,'yyyy-mm-dd')
          and trim(agentcode) = trim(tAgentCode)
          ;
begin
  -- P??????
  -- T: ?????
  -- D?????????

  if YearMark <> '1' then
    return(Result);
  end if;

  if tLevel = 'T' then
    select distinct branchattr,AgentGroup into tAttr,tGroup from LABranchGroup
    where EndFlag<>'Y'
    			and trim(BranchLevel)='01'
          and trim(BranchManager) = trim(tAgentCode);
  end if;

  if tLevel = 'D' then
    select distinct branchattr,AgentGroup into tAttr,tGroup from labranchgroup
    where EndFlag<>'Y'
    			and trim(BranchLevel) = '02'
          and trim(BranchManager) = trim(tAgentCode);
  end if;


  if tLevel = 'P' then  --???????????

    FOR v_View IN c_View LOOP
      tOff := round((v_View.EndDate - v_View.LeaveDate)/30);
      if tOff >= 1 then
        tLeft := tLeft + tOff;
      end if;
    end loop;

    select EmployDate into tEmployDate from laagent
    where trim(agentcode) = tAgentCode;

    if to_char(tEmployDate,'yyyy') = substr(YearBegin,1,4) then
      tMonths := Dateinterval(tEmployDate,YearEnd);
      --????12????????15???????????
      if tMonths = 0 then
        tMonths := 1;
      end if;
    else
      tMonths := 12;
    end if;
    tMonths := tMonths - tLeft;

  else -- ???????????

    select nvl(EndDate,'1900-01-01'),founddate into tEndDate,tFoundDate from labranchgroup
    where trim(agentgroup) = trim(tGroup);

    if to_char(tFoundDate,'yyyy') = substr(YearBegin,1,4) then
      if tEndDate = to_date('1900-01-01','yyyy-mm-dd') then
        tMonths := DateInterval(tFoundDate,YearEnd);
      else
        tMonths := DateInterval(tFoundDate,tEndDate);
      end if;
    else
      if tEndDate = to_date('1900-01-01','yyyy-mm-dd') then
        tMonths := 12;
      else
        tMonths := to_char(tEndDate,'mm');
      end if;
    end if;

  end if;


  --????FYC??(????
  if tLevel = 'P' then
    select nvl(sum(FirstPension),0) into tFYC from laindexinfo
    where trim(indextype)='01' and substr(indexcalno,1,4) = substr(YearBegin,1,4)
          and trim(AgentCode) = trim(tAgentCode)
          ;
  end if;

  if tLevel = 'T' then
    select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
          and substr(wageno,1,4) = substr(YearBegin,1,4)
          and trim(branchattr) like concat(trim(tAttr),'%');
  end if;

  if tLevel = 'D' then
   select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
          and substr(wageno,1,4) = substr(YearBegin,1,4)
          and trim(branchattr) like concat(trim(tAttr),'%');
  end if;


  --??????
  if tMonths = 0 or tFYC = 0 then
    Result := 0;
    return(Result);
  else
    tAvgFYC := tFYC/tMonths;
    select nvl(drawrate,0) into tRate from lawageradix
    where FYCMin <= tAvgFYC
          and (FYCMax > tAvgFYC or FYCMax is null)
          and trim(AreaType) = trim(tAreaType)
          and trim(agentgrade) = trim(tAgentGrade)
          and trim(wagecode) = trim(tWageCode)
          ;
  end if;

  Result := tFYC * tRate;

  if tAgentGrade = 'A01' then
   if tIndueFormDate is null then
      tIntvl := getGradePeriod(tAgentCode,tAgentGrade,tEmployDate,YearEnd);
    else
      tIntvl := getGradePeriod(tAgentCode,tAgentGrade,tEmployDate,tIndueFormDate);
    end if;

    tDay := to_char(tEmployDate,'dd');
    if tDay > trim(getEmployLimit('EmployLimit')) then
      if tIntvl > 8 then
        Result := 0;
      end if;
    else
      if tIntvl > 7 then
        Result:= 0;
      end if;
    end if;
  end if;

  return(Result);
end CALYEARENDBONUS;

/
