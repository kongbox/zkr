CREATE FUNCTION     "AGENTSCHARGEBONUS" (tareatype in varchar2,tindexcalno in varchar2,tstartdate in date,tenddate in date,tbranchcode in varchar2) return number is
  Result number(12,4):=0;
  cPassRate2 number(12,4):=0;--?????
  cPassRate3 number(12,4):=0;--?????
  cPassRate4 number(12,4):=0;--4????
  cPassRateWage2 number(12,4):=0;--???????
  cPassRateWage3 number(12,4):=0;--???????
  cPassRateWage4 number(12,4):=0;--4??????
  cDifficulty number(12,4):=0;--????
  cDifficultyRatio number(12,4):=0;--?????????
  cDueCount2 latollwageradix.receive2%type;--??????
  cDueCount3 latollwageradix.receive2%type;--??????
  cDueCount4 latollwageradix.receive2%type;--4?????
  cJustRatio2 number(12,4):=0;--????
  cJustRatio3 number(12,4):=0;--????
  cJustRatio4 number(12,4):=0;--????
  cAgentcode laagent.agentcode%type;
  DuePay2 number(12,4):=0;
  AcuPay2 number(12,4):=0;
  DuePay3 number(12,4):=0;
  AcuPay3 number(12,4):=0;
  DuePay4 number(12,4):=0;
  AcuPay4 number(12,4):=0;
  cBusi2 number(12,4):=0;
  cBusi3 number(12,4):=0;
  cBusi4 number(12,4):=0;
  cAcuCount2 number(12,4):=0;
  cAcuCount3 number(12,4):=0;
  cAcuCount4 number(12,4):=0;
begin

 declare
 cursor c_agentcode is
   select agentcode from laagentollquaf where agentgroup=tbranchcode and tollflag='2';
   begin
   open c_agentcode;
   loop
     fetch c_agentcode into cAgentcode;
     exit when c_agentcode %notfound;
     --????;
     select nvl(sum(difficulty),1) into cDifficulty from latree where agentcode=cagentcode;


  --???
--??????

  select DuePay(cAgentcode,tstartdate ,tenddate,'2','0') into cDueCount2 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'2','0') into cAcuCount2 from ldsysvar where sysvar='onerow';
  cDueCount2:= cDueCount2+cAcuCount2;
  --?????
  select DuePay(cAgentcode,tstartdate ,tenddate,'2','1') into DuePay2 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'2','1') into AcuPay2 from ldsysvar where sysvar='onerow';

  if DuePay2+AcuPay2=0 then
     cPassRate2:=1;
  else
     cPassRate2:=AcuPay2/(DuePay2+AcuPay2);
  end if;

  select nvl(sum(drawreward),0) into cPassRateWage2 from lawageparam1 where wagecode ='WT0011' and paracode='WP0084'
  and lowlimit<=cPassRate2 and highlimit>cPassRate2 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio2 from lawageparam1 where wagecode ='WT0011' and paracode='WP0086'
  and lowlimit<=cDueCount2 and highlimit>cDueCount2 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode='WT0011' and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;
  cBusi2 := (cPassRateWage2*cJustRatio2)*cDifficultyRatio;



  --???
--??????

  select DuePay(cAgentcode,tstartdate ,tenddate,'3','0') into cDueCount3 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'3','0') into cAcuCount3 from ldsysvar where sysvar='onerow';
  cDueCount3:= cDueCount3+cAcuCount3;
  --?????
  select DuePay(cAgentcode,tstartdate ,tenddate,'3','1') into DuePay3 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'3','1') into AcuPay3 from ldsysvar where sysvar='onerow';

  if DuePay3+AcuPay3=0 then
     cPassRate3:=1;
  else
     cPassRate3:=AcuPay3/(DuePay3+AcuPay3);
   end if;

  select nvl(sum(drawreward),0) into cPassRateWage3 from lawageparam1 where wagecode ='WT0011' and paracode='WP0085'
  and lowlimit<=cPassRate3 and highlimit>cPassRate3 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio3 from lawageparam1 where wagecode ='WT0011' and paracode='WP0087'
  and lowlimit<=cDueCount3 and highlimit>cDueCount3 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode='WT0011' and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;

  cBusi3 := (cPassRateWage3*cJustRatio3)*cDifficultyRatio;


    --???
--??????

  select DuePay(cAgentcode,tstartdate ,tenddate,'4','0') into cDueCount4 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'4','0') into cAcuCount4 from ldsysvar where sysvar='onerow';
  cDueCount4:= cDueCount4+cAcuCount4;
  --?????
  select DuePay(cAgentcode,tstartdate ,tenddate,'4','1') into DuePay4 from ldsysvar where sysvar='onerow';
  select ActuPay(cAgentcode,tstartdate ,tenddate,'4','1') into AcuPay4 from ldsysvar where sysvar='onerow';

  if DuePay4+AcuPay4=0 then
     cPassRate4:=1;
  else
     cPassRate4:=AcuPay4/(DuePay4+AcuPay4);
  end if;

  select nvl(sum(drawreward),0) into cPassRateWage4 from lawageparam1 where wagecode ='WT0011' and paracode='WP0088'
  and lowlimit<=cPassRate4 and highlimit>cPassRate4 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio4 from lawageparam1 where wagecode ='WT0011' and paracode='WP0089'
  and lowlimit<=cDueCount4 and highlimit>cDueCount4 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode='WT0011' and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;

  cBusi4 := (cPassRateWage4*cJustRatio4)*cDifficultyRatio;
  Result := Result +cBusi2+cBusi3+cBusi4;

   end loop;
  close c_agentcode;
  end;
  return(Result);
end AgentsChargeBonus;

/
