CREATE FUNCTION     "CALPIECEGTBRANCH" (
       tStartDate date, --????
       tEndDate date,   --????
       tBranchattr Labranchgroup.Branchattr%TYPE
       ) return number is
LongRisk number;
ShortRiskSm number;
tpaymoney number;
v_Piece number;

CURSOR cTempfeeno is
   select distinct LJTempFee.Tempfeeno from Lmriskapp,LJTempFee
 where (LJTempFee.Tempfeetype='1' or LJTempFee.Tempfeetype='5' or LJTempFee.Tempfeetype='6') and
 LJTempFee.makedate>=tStartDate and LJTempFee.makedate<=tEndDate
 and LJTempFee.Riskcode=LMRiskApp.Riskcode and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod<>'L'
 and LJTempFee.AgentGroup in (select agentgroup from labranchgroup where BranchType='1' and branchattr like tBranchattr||'%');


begin
--??????or --??????500???
 select nvl(count(distinct(LJTempFee.Otherno)),0) into LongRisk
 from Lmriskapp,LJTempFee
 where (LJTempFee.Tempfeetype='1' or LJTempFee.Tempfeetype='5' or LJTempFee.Tempfeetype='6') and
 LJTempFee.makedate>=tStartDate and LJTempFee.makedate<=tEndDate
 and LJTempFee.AgentGroup in (select agentgroup from labranchgroup where BranchType='1' and branchattr like tBranchattr||'%')
 and LJTempFee.Riskcode=LMRiskApp.Riskcode and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod='L'
;



--???????500?or??500????
 ShortRiskSm:=0;

for vTempfeeno in cTempfeeno loop

  select nvl(sum(paymoney),0) into tpaymoney from LJTempFee
  where tempfeeno=vTempfeeno.Tempfeeno;
  if tpaymoney>=500 then
    ShortRiskSm:=ShortRiskSm+1;
   else
    ShortRiskSm:=ShortRiskSm+tpaymoney/500;
   end if;
end loop;

 v_Piece:=LongRisk+ShortRiskSm;

return v_Piece;
end CALPIECEGTBranch;

/
