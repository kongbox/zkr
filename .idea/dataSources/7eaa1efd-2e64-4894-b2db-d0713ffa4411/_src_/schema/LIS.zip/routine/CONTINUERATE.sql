CREATE FUNCTION     "CONTINUERATE" (cCode in varchar2, cStartDate in date, cEndDate in date, cFlag in varchar2, cStatAngle in varchar2) return number is
  -- cStatAngle : ??????-- agent; ???????-- branch; ???????--com
  -- cFlag: ????-- premup?????-- premdown; ????-- pcntup; ????-- pcntdown
  iSum           number(10,6):=0;

begin
  if cStatAngle = 'agent' or cStatAngle = 'AGENT' then
    if cFlag = 'premup' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where agentcode=cCode and commdire='1'
      and p6=0 and  cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14)
      and payyears>1 and payintv<>0 and paycount>=2 and flag='0' and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and transtype <> 'FX';
    elsif cFlag = 'premdown' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where agentcode=cCode and commdire='1'
      and p6=0 and paycount=1 and flag='0' and payyears>1 and payintv<>0
      and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    elsif cFlag = 'pcntup' then
      --????
      select nvl(count(1),0) into iSum from lacommision where agentcode=cCode
      and commdire='1' and p6=0 and cvalidate>=add_months(cStartDate,-14) and transtype <> 'FX'
      and cvalidate<=add_months(cEndDate,-14) and payyears>1 and payintv<>0 and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and paycount>=2 and flag='0' and riskmark = 'Y';
    elsif cFlag = 'pcntdown' then
      --????
      select nvl(count(1),0) into iSum from lacommision where agentcode=cCode and riskmark = 'Y'
      and commdire='1' and p6=0 and paycount=1 and flag='0' and payyears>1
      and payintv<>0 and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    end if;
  elsif cStatAngle = 'branch'  or cStatAngle = 'BRANCH' then
    if cFlag = 'premup' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where branchseries like cCode||'%'
      and commdire='1' and p6=0 and cvalidate>=add_months(cStartDate,-14)
      and cvalidate<=add_months(cEndDate,-14) and payyears>1 and payintv<>0 and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and paycount>=2 and flag='0' and transtype <> 'FX';
    elsif cFlag = 'premdown' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where branchseries like cCode||'%'
      and commdire='1' and p6=0 and paycount=1 and flag='0' and not (payyears=1 and payintv=12)
      and payintv<>0 and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    elsif cFlag = 'pcntup' then
      --????
      select nvl(count(1),0) into iSum from lacommision where branchseries like cCode||'%'
      and commdire='1' and p6=0 and cvalidate>=add_months(cStartDate,-14) and transtype <> 'FX'
      and cvalidate<=add_months(cEndDate,-14) and payyears>1 and payintv<>0 and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and paycount>=2 and flag='0' and riskmark = 'Y';
    elsif cFlag = 'pcntdown' then
      --????
      select nvl(count(1),0) into iSum from lacommision where branchseries like cCode||'%' and p6=0
      and riskmark = 'Y' and commdire='1' and paycount=1 and flag='0' and payyears>1
      and payintv<>0 and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    end if;
  elsif cStatAngle = 'com' or cStatAngle = 'COM' then
    if cFlag = 'premup' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where manageCom like cCode||'%'
      and branchtype = '1' and commdire='1' and p6=0 and cvalidate>=add_months(cStartDate,-14)
      and cvalidate<=add_months(cEndDate,-14) and payyears>1 and payintv<>0 and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and paycount>=2 and flag='0' and transtype <> 'FX';
    elsif cFlag = 'premdown' then
      --????
      select nvl(sum(transmoney),0) into iSum from lacommision where manageCom like cCode||'%'
      and branchtype = '1' and commdire='1' and p6=0 and paycount=1 and flag='0'
      and not (payyears=1 and payintv=12) and payintv<>0
     and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    elsif cFlag = 'pcntup' then
      --????
      select nvl(count(1),0) into iSum from lacommision where manageCom like cCode||'%'
      and branchtype = '1' and commdire='1' and p6=0 and cvalidate>=add_months(cStartDate,-14)
      and transtype <> 'FX'and cvalidate<=add_months(cEndDate,-14) and payyears>1
      and tmakedate>=add_months(cStartdate,-2)
      and tmakedate<=cEnddate
      and payintv<>0 and paycount>=2 and flag='0' and riskmark = 'Y';
    elsif cFlag = 'pcntdown' then
      --????
      select nvl(count(1),0) into iSum from lacommision where manageCom like cCode||'%'
      and branchtype = '1' and riskmark = 'Y' and commdire='1' and p6=0 and paycount=1 and flag='0'
      and not (payyears=1 and payintv=12) and payintv<>0 and cvalidate>=add_months(cStartDate,-14) and cvalidate<=add_months(cEndDate,-14);
    end if;
  end if;
  return(iSum);
end ContinueRate;

/
