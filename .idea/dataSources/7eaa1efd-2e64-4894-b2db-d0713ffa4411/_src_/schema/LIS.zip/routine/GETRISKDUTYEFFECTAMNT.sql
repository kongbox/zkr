CREATE FUNCTION     "GETRISKDUTYEFFECTAMNT"(tPolNo in varchar2,
                                                   tDutyCode in varchar2,
                                                   tGetDutyCode LMDUTYGETCLM.Getdutycode%type,
                                                   tGetDutyKind LMDUTYGETCLM.GetDutyKind%type)
  return number is
  Result    number;
  tRiskCode varchar2(20);
  tAmnt     number;
  gdcCnt    number;
  getMoney  number;
  mCount    number;
  lResult  number;
begin
  tAmnt    := 0;
  gdcCnt   := 0;
  getMoney := 0;
  mCount   := 0;
  SELECT riskcode into tRiskCode FROM lcpol WHERE polno = tPolNo;
  --判断是否为津贴型产品，如果是，amnt的取值是不一样的，如果不是，则取amnt
  select count(*)
    into mCount
    from d_risk
   where dimen6code = '03'
     and classtypecode = '02'
     and riskcode = tRiskCode;
  if mCount > 0 then
    --获取最大给付天数
    select distinct nvl(a.SUMCLMDAYLMT, 0)
      into lResult
      from lmdutygetclm a, lmdutygetrela b, lmriskduty c, lmriskapp d
     where d.riskcode = tRiskCode
       and c.dutycode = tDutyCode
       and a.getdutycode = tGetDutyCode
       and a.getdutykind = tGetDutyKind
       and a.GETDUTYCODE = b.GETDUTYCODE
       and b.DUTYCODE = c.DUTYCODE
       and c.riskcode = d.riskcode
       and d.RISKTYPE1 = '3';
    if lResult > 0 then
      SELECT amnt * lResult
        into tAmnt
        FROM lcduty
       WHERE polno = tPolNo
         AND dutycode = tDutyCode;
    else
      SELECT amnt
        into tAmnt
        FROM lcduty
       WHERE polno = tPolNo
         AND dutycode = tDutyCode;
    end if;
  else
    SELECT amnt
      into tAmnt
      FROM lcduty
     WHERE polno = tPolNo
       AND dutycode = tDutyCode;
  end if;
  if (tRiskCode = 'XXX') THEN
    Result := 0;
  ELSE
    SELECT to_number(COUNT(*))
      into gdcCnt
      FROM lmdutygetrela
     WHERE dutycode = tDutyCode;
    if (gdcCnt = 0) THEN
      gdcCnt := 1;
    END if;
    SELECT nvl(SUM(nvl(summoney, 0)), 0) / gdcCnt
      into getMoney
      FROM lcget
     WHERE polno = tPolNo
       AND dutycode = tDutyCode;
    Result := tAmnt - getMoney;
    if (Result < 0) THEN
      Result := 0;
    END if;
  END if;
  --Result := 3003.3;
  return(Result);
end getRiskDutyEffectAmnt;

/
