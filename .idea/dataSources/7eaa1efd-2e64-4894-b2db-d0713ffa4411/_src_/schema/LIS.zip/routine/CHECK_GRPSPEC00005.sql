CREATE function     check_grpspec00005(grpcontno1 in varchar2,specodeIN in varchar2)
 return number
 is
 result number;
 tempflag1 integer;
 tempflag2 integer;
 tempflag3 integer;
 begin
       select count(*)
         into tempflag1
         from lcgrppol
        where grpcontno = grpcontno1
          and riskcode in
              (select code1 from ldcode1 where codetype='SPEC' and code = specodeIN);

        select count(*)
          into tempflag2
          From lcgrpcont
         where grpcontno = grpcontno1
           and pervouflag = '0';

       select count(*)
         into tempflag3
         from lccgrpspec
        where grpcontno = grpcontno1
          and speccode = specodeIN;

    if(tempflag1>0 and tempflag2>0 and tempflag3>0) then
       result :=1;
    end if;

    if(tempflag1>0 and tempflag2=0) then
       result :=1;
    end if;

    if(tempflag1=0) then
       result :=1;
    end if;

 return(result);
end check_grpspec00005;

/
