CREATE FUNCTION     "ENDOWMENT" (tagentcode in varchar2, tindexcalno in varchar2,flag in varchar2) return number  is
  --flag =1 ???? =0 ????
  Result number(12,4):=0;
  cOwn number(12,4):=0;
  cPersonEndow number(12,4):=0;
  cComEndow number(12,4):=0;
  cSum number(12,4):=0;--?????????
begin
--????????

     select nvl(T73,0),nvl(t32,0),nvl(t33,0) into cOwn,cPersonEndow,cComEndow from laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno
     and indextype='01' and branchtype='4' and branchtype2='01';


  if cOwn=0 then
       select t24-nvl(t17,0)-nvl(t18,0)-nvl(t19,0)-nvl(t20,0)-nvl(DRTeamAvgRate,0)-nvl(DepAvgRate,0)-nvl(T13,0)-nvl(t11,0)-nvl(t12,0)-nvl(t76,0)
       into cSum from laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno;

       if cSum-cPersonendow>=0 then
          if flag=1 then--??
             Result :=cPersonEndow;
          else
             Result :=cComEndow;
          end if;
       end if;
   end if;

  return(Result);
end Endowment;

/
