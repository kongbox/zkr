CREATE function GetBirthdayByIDNo (IDNo  in varchar2)
return date
as
  Birthday date;
  GetDate  varchar2(20);
  IDNolen  varchar2(20);
begin
  select length(IDNo) into IDNolen from dual;
  if IDNolen = '15' then
    GetDate := '19'||substr(IDNo,7,2)||'-'||substr(IDNo,9,2)||'-'||substr(IDNo,11,2);
  elsif IDNolen = '18' then
    GetDate := substr(IDNo,7,4)||'-'||substr(IDNo,11,2)||'-'||substr(IDNo,13,2);
  end if;
   select to_date(GetDate,'yyyy-MM-dd') into Birthday from dual;
  return Birthday;
end;
/
