CREATE function fnc_21801_prem(tAmnt  in NUMBER,tSSFlag IN varchar2) return number is
  tPrem number;
  str_sql         varchar2(1000); --绑定变量查询
begin
   tPrem := 0;

   if tAmnt <= 50000 then
    begin
       str_sql := 'select prem from RT_61201801 e where e.amnt =:v_amnt and e.ssflag =:v_ssflag';
      execute immediate str_sql
      into tPrem
      using tAmnt,tSSFlag;
    end;
  end if;
   if tAmnt > 50000 then
    begin
        str_sql := 'select prem from RT_61201801 e where e.amnt =50000  and e.ssflag =:v_ssflag';
      execute immediate str_sql
      into tPrem
      using tSSFlag;
    end;
   end if;
   if tSSFlag = '1' AND tAmnt > 50000 then
        tPrem := tPrem+ ((tAmnt-50000)/5000)*1;
   end if;
   if tSSFlag = '2' AND tAmnt > 50000 then
        tPrem := tPrem+ ((tAmnt-50000)/5000)*1.2;
   end if;

   return (tPrem);
end fnc_21801_prem;

/
