CREATE FUNCTION     "CALSPECIAL" (tAgentCode in varchar2,tAgentGroup in varchar2,TempBegin in date,TempEnd in date,FYC1 number,tAreaType in varchar2) return number is
  Result number := 0;
  tFYC   number := 0;

  cursor c_View is
    select * from laagenttreeview
    where trim(agentgroup) = trim(tAgentGroup) and trim(introagency) = trim(tAgentCode)
          ;

begin
  --Result := Result + FYC1;
  for v_View in c_View Loop

      select nvl(sum(fyc),0) into tFYC from lacommision
      where CommDire='1'
        and caldate>=TempBegin
        and caldate<=TempEnd
        and payyear <1
        and trim(agentcode) = trim(v_View.AgentCode);

    Result := Result + tFYC + calspecial(v_View.agentcode,tAgentGroup,TempBegin,TempEnd,FYC1,tAreaType);
  end Loop;

  return(Result);
end CALSPECIAL;

/
