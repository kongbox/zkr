CREATE FUNCTION     "CALDIRGROUPFYC" (tAgentCode in varchar2,tAgentGrade in varchar2,tAgentGroup in varchar2,tAttr in varchar2,TempBegin date,TempEnd date,tAreaType in varchar2) return number is
  tBranchAttr  varchar2(20);
  Result number := 0;


begin
  if tAgentGrade < 'A08' then
    select nvl(sum(fyc),0) into Result from lacommision
    where CommDire = '1'
      and caldate>=TempBegin
      and caldate<=TempEnd
      and payyear < 1
      and trim(branchattr) like concat(trim(tAttr),'%');
  else
    select trim(branchattr) into tBranchAttr from labranchgroup
    where EndFlag<>'Y'
    			and trim(branchlevel) = '02'
          and trim(branchattr) like concat(trim(tAttr),'%')
          and trim(upbranchattr) = '1'
          and trim(branchmanager) = trim(tAgentCode);

    select nvl(sum(fyc),0) into Result from lacommision
    where CommDire = '1'
      and caldate>=TempBegin
      and caldate<=TempEnd
      and payyear < 1
      and trim(branchattr) like concat(trim(tBranchAttr),'%');
  end if;


  return(Result);
end CALDIRGROUPFYC;

/
