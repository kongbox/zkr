CREATE FUNCTION     "CON_PAYINTV_PAYENDYEAR" (PayIntv number, payendyear number) return number is
  Result number;
begin
  if (payintv = 0) then
    result := 1000;
  else
    result := payendyear;
  end if;
  return(Result);
end CON_PAYINTV_PAYENDYEAR;

/
