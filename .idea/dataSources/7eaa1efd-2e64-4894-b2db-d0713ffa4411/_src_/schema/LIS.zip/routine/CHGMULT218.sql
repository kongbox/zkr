CREATE FUNCTION     "CHGMULT218" ( Mult number,Appage number ) return number
is
tR number;
begin
    if Appage>17 then
	  if Mult > 3 then
		tR := 3;
	  else
		tR := Mult;
	  end if;
	else
		tR := 1;
	end if;
	return(tR);
end;

/
