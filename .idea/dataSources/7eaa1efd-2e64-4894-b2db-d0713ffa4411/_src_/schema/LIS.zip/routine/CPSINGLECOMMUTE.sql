CREATE FUNCTION     "CPSINGLECOMMUTE" (vP_Table_Par in VARCHAR2,vC_Table_Par in VARCHAR2,vEdorNo_Par in VARCHAR2,vEdorType_Par in VARCHAR2) return varchar2 is
  pragma autonomous_transaction;
  --?????????C??P???????
  --???Nicholas
  v_num number;
  T_MK_Name VARCHAR2(2000);
  T_MK_Condition VARCHAR2(2000);
  T_AC_Name VARCHAR2(2000);
  T_AC_String VARCHAR2(2000);
  --????
  vP_Table VARCHAR2(2000);
  vC_Table VARCHAR2(2000);
  vEdorNo VARCHAR2(2000);
  vEdorType VARCHAR2(2000);
  --?????????
  vP_C_Num number;
  vC_P_Num number;
--gunn varchar2(2000);

  --???????????????????
  CURSOR T_MAINKEY (t_name VARCHAR2) IS
  SELECT distinct COLUMN_NAME
  FROM user_cons_columns
  WHERE table_name = t_name and CONSTRAINT_NAME like 'PK_%';

  --????????????
  CURSOR T_AC_BQ (t_n VARCHAR2) IS
  SELECT column_name
  FROM user_tab_columns
  WHERE table_name=t_n;
begin
  --/********************************************?????******************************************************\
  vP_C_Num := 0;
  vC_P_Num := 0;
  vP_Table := upper(trim(vP_Table_Par));
  vC_Table := upper(trim(vC_Table_Par));
  vEdorNo := trim(vEdorNo_Par);
  vEdorType := trim(vEdorType_Par);

  --??P?????????
  execute immediate 'select count(*) from ' || vP_Table || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''' into v_num;
--gunn := 'A';
  if v_num>0 then
    --????????????
    SELECT count(*) into v_num FROM user_tables WHERE table_name='T_TEMP_BQ';
    if v_num>0 then
      execute immediate 'DELETE FROM T_TEMP_BQ';
      execute immediate 'DROP table T_TEMP_BQ';
    end if;
    --????????????
--gunn := 'B';
    execute immediate 'CREATE GLOBAL TEMPORARY TABLE T_TEMP_BQ as select * from ' || vP_Table || ' where rownum=1';
    execute immediate 'INSERT INTO T_TEMP_BQ select * from ' || vP_Table || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
    --???????????????P??C???????
    vP_C_Num := SQL%ROWCOUNT;
--gunn := 'C';
    --??P???
    execute immediate 'DELETE FROM ' || vP_Table || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
    --?????????????
    T_MK_Condition := null;
    OPEN T_MAINKEY(vC_Table);
    LOOP
      FETCH T_MAINKEY INTO T_MK_Name;
      EXIT WHEN T_MAINKEY%NOTFOUND;
        T_MK_Condition := T_MK_Condition || ' and C.' || T_MK_Name || '=X.' || T_MK_Name;
    END LOOP;
    CLOSE T_MAINKEY;
    --?C???????P?
--gunn := 'D';
    execute immediate 'INSERT INTO ' || vP_Table ||
                      ' SELECT ''' || vEdorNo || ''',''' || vEdorType || ''',C.*' ||
                      ' FROM ' || vC_Table || ' C,T_TEMP_BQ X' ||
                      ' WHERE 1=1' || T_MK_Condition;
    --???C??P???????
    vC_P_Num := SQL%ROWCOUNT;
--gunn := 'E';
    --??C?????
    execute immediate 'DELETE FROM ' || vC_Table || ' C' ||
                      ' WHERE exists(select ''Z'' from T_TEMP_BQ X where 1=1' || T_MK_Condition || ')';
    --??C?????
    T_AC_String := null;
    OPEN T_AC_BQ(vC_Table);
    LOOP
      FETCH T_AC_BQ INTO T_AC_Name;
      EXIT WHEN T_AC_BQ%NOTFOUND;
        if T_AC_String is null then
          T_AC_String := T_AC_Name;
        else
          T_AC_String := T_AC_String || ',' || T_AC_Name;
        end if;
    END LOOP;
    CLOSE T_AC_BQ;
--gunn := 'F';
    --????????C?
    execute immediate 'INSERT INTO ' || vC_Table || '(' || T_AC_String || ') SELECT '
                      || T_AC_String || ' FROM T_TEMP_BQ';
    --????????????????
    commit;
    --?????
    execute immediate 'DROP table T_TEMP_BQ';
  end if;
  --\************************************************************************************************************/
  return('S' || to_char(vP_C_Num) || '|' || to_char(vC_P_Num));
exception
  when others then
  --????????
  rollback;
  --????
  --??????
  if T_MAINKEY%isopen=true then
     close T_MAINKEY;
  end if;
  if T_AC_BQ%isopen=true then
     close T_AC_BQ;
  end if;
  --?????????
  SELECT count(*) into v_num FROM user_tables WHERE table_name='T_TEMP_BQ';
  if v_num>0 then
    execute immediate 'DELETE FROM T_TEMP_BQ';
    execute immediate 'DROP table T_TEMP_BQ';
  end if;
  --?????????
  dbms_output.put_line('????:CPSINGLECOMMUTE??????' || ' ???????: ' || sqlerrm);
  --??????????E+????
  return('E' || sqlerrm);
  --return(gunn || ' asdf ' || sqlerrm);
end CPSINGLECOMMUTE;

/
