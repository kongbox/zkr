CREATE FUNCTION     "CALINITRWD" (tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,TempEnd in date) return integer is
  tID           Date;
  tED           Date;
  tBottom3      varchar2(12);  --????????
  tBottom6      varchar2(12);  --????????
  tCount        number(12,2);
  tLoopCount    integer;
  tLimit        integer;  --????
  tFlagIn       varchar2(10);
  tMainPolFlag  varchar2(2);
  tBegin        varchar2(6);

  tAdd          integer;
  tEDay         varchar2(2);
  tAgentState   varchar2(2);

  Result        number(12,2);
---?????
begin
  -- ???????????????????
  select indueformdate,employdate,agentstate into tID,tED,tAgentState from laagent
  where trim(agentcode) = trim(tAgentCode);

  if tAgentState >= '02' then
    return(0);
  end if;

  if tID is null then
    return(0);
  end if;

  --?????A02??????
  if tID = tED then
    return(0);
  end if;

  -- ??????????

  tEDay := to_char(tED,'dd');
  if tEDay > getEmployLimit('EmployLimit') then
    if to_char(tED,'mm') >= to_char(tID,'mm')-1 then
      tFlagIn := 'Y';
    else
      tFlagIn := 'N';
    end if;

    if tFlagIn = 'N' then
      tBottom3 := to_char(add_months(tED,4),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,7),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    else
      tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    end if;
  else
    tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
    tBottom3 := concat(substr(tBottom3,1,8),'01');

    tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
    tBottom6 := concat(substr(tBottom6,1,8),'01');

    tFlagIn := 'Y';
  end if;

  if tID <= to_date(tBottom3,'yyyy-mm-dd') then
    tLimit := 2;    --??????
  else
    if tID > to_date(tBottom3,'yyyy-mm-dd') and tID <= to_date(tBottom6,'yyyy-mm-dd') then
      tLimit := 5;  --??????
    else
      return(0);    --???????
    end if;
  end if;

  --??????
  if tLimit = 2 then
    if to_char(TempEnd,'mm') <> substr(tBottom3,6,2) then
      return(0);
    end if;

    if tID = to_date(tBottom3,'yyyy-mm-dd') then
      tMainPolFlag := 'T';
      tLoopCount := 0;
    else
      tLoopCount := Months_between(to_date(tBottom3,'yyyy-mm-dd'),tID);
    end if;
  else
    if to_char(TempEnd,'mm') <> substr(tBottom6,6,2) then
      return(0);
    end if;

    if tID = to_date(tBottom6,'yyyy-mm-dd') then
      tMainPolFlag := 'T';
      tLoopCount := 0;
    else
      tLoopCount := Months_between(to_date(tBottom6,'yyyy-mm-dd'),tID);
    end if;
  end if;

 ---??????????????
  tAdd:= 0;
  for v_Counter in 1..tLoopCount Loop
    tBegin := to_char(add_months(tID,tAdd),'YYYYMM');

    select nvl(sum(calcount),0) into tCount from LACommision
    where trim(commdire) = '1' and trim(wageno) = trim(tBegin)
      and  trim(AgentCode) = trim(tAgentCode)
      ;

    if tCount = 0 then
      tMainPolFlag := 'F';
    else
      tMainPolFlag := 'T';
    end if;

    tAdd := tAdd + 1;
    exit when tMainPolFlag = 'F';
  end Loop;


  if tMainPolFlag = 'T' then
    if judgeifdegrade(tAgentCode) <> 1 then
      select nvl(RewardMoney,0) into Result from LAWageRadix
      where DrawStart < tLimit and DrawEnd >= tLimit
      and trim(AgentGrade) = trim(tAgentGrade)
      and trim(AreaType) = trim(tAreaType)
      and  trim(WageCode) = trim(tWageCode)
      ;
    else
      return 0;
    end if;
  else
    return(0);
  end if;

  return(Result);
end CALINITRWD;

/
