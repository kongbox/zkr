CREATE FUNCTION     "CALGRPCURRMONEY1" (
  tAgentCode laagent.agentcode%type,
  tIndexCalNo in varchar2
  --tAgentGrade latree.agentgrade%type
)
  return number is
  Result number;

  --tBmon  number;
  --tT29 number;
begin
  --select rewardmoney into tBmon from lawageradix1 where agentgrade=tAgentGrade and wagecode='bmon' and branchtype2='03';
  --select T29 Into tT29 from laindexinfo where agentcode=tAgentcode and indextype='01' and indexcalno=tIndexCalNo;
  --If(tT29<tBmon) then
  select nvl(InitPension,0)  --????
  +nvl(FirstPension,0)       --????
  +nvl(T29,0)                --???
  +nvl(PosSdy,0)             --??
  into Result from laindexinfo
  where agentcode = tAgentCode
  and indextype='01'
  and indexcalno=tIndexCalNo;
  --else
  --select nvl(InitPension,0)+nvl(FirstPension,0)+tBmon into Result from laindexinfo
  --where agentcode = tAgentCode and indextype='01' and indexcalno=tIndexCalNo;
  --end If;
  return(Result);
end calgrpcurrmoney1;

/
