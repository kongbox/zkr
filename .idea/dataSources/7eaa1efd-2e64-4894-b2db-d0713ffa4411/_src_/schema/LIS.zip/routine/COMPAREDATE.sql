CREATE FUNCTION     "COMPAREDATE" ( data1 date,time1 varchar2,data2 date,time2 varchar2 )
return number
is
tR number;
begin

    if data1>data2 then
		tR := 1;
		return(tR);
	 end if;

    if data1<data2 then
	   tR := -1;
	   return(tR);
	 end if;

    if time1>time2 then
	    tR := 1;
		 return(tR);
	 end if;

    if time1<time2 then
	    tR :=-1;
		 return(tR);
	 end if;

    if time1=time2 then
	    tR :=0;
		 return(tR);
	 end if;

    return(-1);

end COMPAREDATE;

/
