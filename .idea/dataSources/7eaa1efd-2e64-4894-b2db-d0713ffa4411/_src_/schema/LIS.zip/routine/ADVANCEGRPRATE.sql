CREATE FUNCTION     "ADVANCEGRPRATE" (tbranchcode in varchar2, tempbegin in date,tempend in date) return number  is
------------------------------??????????------------------------------------------
  GrpRate                   number(12,6):=0;
  PremUp                    number(12,6):=0;
  PremDown                  number(12,6):=0;
  countup                   number(12,6):=0;
  countdown                 number(12,6):=0;
  rate1                     number(12,6):=0;
  rate2                     number(12,6):=0;
begin
  ---??????(????)
  select nvl(sum(transmoney),0) into PremUp from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and transtype<>'FX';
---??????(????)
  select nvl(sum(transmoney),0)into PremDown from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and paycount=1 and flag='0' and not (payyears=1 and payintv=12) and payintv<>0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14);
---??????(????)
  select nvl(count(1),0) into countup from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and transtype<>'FX' and riskmark='Y';
---??????(????)
  select nvl(count(1),0) into countdown from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0 and paycount=1 and flag='0'
  and not (payyears=1 and payintv=12) and payintv<>0 and riskmark='Y'
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14);

  if PremDown>0 then
     rate1:=PremUp/PremDown;
  else
     rate1:=1;
  end if;

  if countdown>0 then
     rate2:=countup/countdown;
  else
     rate2:=1;
  end if;

  GrpRate:=Round((rate1*0.5 + rate2*0.5),2);
  return(GrpRate);
end AdvanceGrpRate;

/
