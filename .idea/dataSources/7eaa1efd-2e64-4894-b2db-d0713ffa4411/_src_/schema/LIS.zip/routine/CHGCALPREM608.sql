CREATE FUNCTION     "CHGCALPREM608" (Amnt in number,InsuYear in number,GetDutyKind in varchar2) return number
is v_tR number;
begin
	if GetDutyKind = '1' then
		v_tR := Amnt/10000*1;
	end if;
	if GetDutyKind = '2' then
	  if InsuYear<10 then
		v_tR := Amnt/10000*1;
	  else
		v_tR := Amnt/10000*(1+(InsuYear-10)*0.1);
	  end if;
	end if;
	if GetDutyKind = '3' then
	  if InsuYear<20 then
		v_tR := Amnt/10000*1.5;
	  else
		v_tR := Amnt/10000*(1.5+(InsuYear-20)*0.1);
	  end if;
	end if;
	if GetDutyKind = '4' then
	  if InsuYear<20 then
		v_tR := Amnt/10000*1.5;
	  else
		v_tR := Amnt/10000*(1.5+(InsuYear-20)*0.1);
	  end if;
	end if;
	return(v_tR);
end;

/
