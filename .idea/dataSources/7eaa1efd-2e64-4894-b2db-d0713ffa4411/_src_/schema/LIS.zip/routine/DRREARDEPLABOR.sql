CREATE FUNCTION     "DRREARDEPLABOR" (ACODE in VARCHAR2,AGROUP in VARCHAR2,YEARMONTH in VARCHAR2, FYCSTANDARD in NUMBER,EDATE in DATE) return integer is
-------------------????????????-------------------------
  ASUM           INTEGER;
  v_SDATE        DATE;
begin
  ASUM   := 0;
  --?????????????
  v_SDATE := TRUNC(EDATE,'MM');
  SELECT COUNT(A.AGENTCODE) INTO ASUM FROM
  (SELECT AGENTCODE,NVL(SUM(FYC),0) DWSUM FROM LACOMMISION
  WHERE PAYYEAR < 1 and TRIM(BRANCHCODE) IN (SELECT trim(AGENTGROUP) FROM LABRANCHGROUP
                             WHERE TRIM(UPBRANCH) = AGROUP AND ENDFLAG = 'N')
    AND CALDATE >= v_SDATE AND CALDATE <= EDATE
    GROUP BY AGENTCODE) A
  WHERE A.DWSUM >= FYCSTANDARD;
  --??
  DECLARE
    CAGENT  VARCHAR2(10);
    CGROUP  VARCHAR2(12);
  CURSOR C_REARGROUPFYC IS
    select distinct AgentCode,TRIM(AgentGroup) from Latreeaccessory
     where AgentGrade in ('A06', 'A07')  And
        AgentCode not in
           (select AgentCode from LATree where AgentGrade >= 'A08' and AgentCode not in
              (select AgentCode from Latreeb where TRIM(indexcalno) = YEARMONTH and AgentGrade = 'A07'))
        and AgentCode not in (select AgentCode from laagent where agentState in ('03', '04', '05'))
        and TRIM(rearAgentCode) = ACODE;
  BEGIN
    OPEN C_REARGROUPFYC;
    LOOP
      FETCH C_REARGROUPFYC INTO CAGENT,CGROUP;
      EXIT WHEN C_REARGROUPFYC%NOTFOUND;
      ASUM := ASUM + DRREARDEPLABOR(CAGENT,CGROUP,YEARMONTH,FYCSTANDARD,EDATE);
    END LOOP;
    CLOSE C_REARGROUPFYC;
  END;
  RETURN ASUM;
end DRREARDEPLABOR;

/
