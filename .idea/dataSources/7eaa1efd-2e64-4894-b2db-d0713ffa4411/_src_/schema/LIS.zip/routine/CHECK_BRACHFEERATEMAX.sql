CREATE function     check_brachfeeratemax(grpcontno1 in varchar2,riskcode1 in varchar2)
 return number
 is
result number;
tempflag integer;
tempflag1 integer;
tempflag2 varchar2(10);

temprate number;
tempbranch number;
templim1 number;
templim2 number;
value1 number;
value2 number;
begin
  tempflag:=0;
  tempflag1:=0;
  tempflag2:='';

  --------0-自留 1-临分 不需校验 分公司变动费用上限
  select (select count(*) from lcgrppol where grpcontno = grpcontno1 and riskcode = riskcode1 and distriflag not in ('3', '4'))
    into tempflag
    from ldsysvar
   where sysvar = 'onerow';

   -----分公司变动费用上限表中没有配置的险种，不需测算
   select count(*) into tempflag1 from ldfeeratemax a where riskcode = riskcode1 and codetype = 'brachfeeratemax';

   select (select braofffeerate + salecommissionrate + agentfeerate
             from lcgrppol
            where riskcode = riskcode1
              and grpcontno = grpcontno1)
     into tempbranch
     from ldsysvar
    where sysvar = 'onerow';

    select (select a.value
              from ldfeeratemax a
             where riskcode = riskcode1
               and codetype = 'brachfeeratemax')
      into value1
      from ldsysvar
     where sysvar = 'onerow';

     select (select a.value1
               from ldfeeratemax a
              where riskcode = riskcode1
                and codetype = 'brachfeeratemax')
       into value2
       from ldsysvar
      where sysvar = 'onerow';

 if tempflag > 0 then
  result := 1;
 end if;
 if tempflag = 0 then
   if (tempflag1=0) then
        result := 1;
   end if;
   if tempflag1>0 then
   ----分公司费用上限的校验中有一个比较特殊，就是建工意外险，40040703、40041412、41250702
   ---- 本处采用配置的形式处理（软编码实现）
   ----- 在ldfeeratemax表中类型为brachfeeratemax=分公司变动费用上限的standbyflag1=1的定义建工险按照费率折扣的形式实现
   select (select a.standbyflag1
               from ldfeeratemax a
              where riskcode = riskcode1
                and codetype = 'brachfeeratemax')
       into tempflag2
       from ldsysvar
      where sysvar = 'onerow';

   if tempflag2='1' then
   select (select sum(prem) / sum(standprem)
             from lcpol
            where riskcode = riskcode1
              and grpcontno = grpcontno1)
     into temprate
     from ldsysvar
    where sysvar = 'onerow';

    select (select limitvalue1
              from ldfeeratemax
             where riskcode = riskcode1
               and codetype = 'brachfeeratemax')
      into templim1
      from ldsysvar
     where sysvar = 'onerow';

     select (select limitvalue2
               from ldfeeratemax
              where riskcode = riskcode1
                and codetype = 'brachfeeratemax')
       into templim2
       from ldsysvar
      where sysvar = 'onerow';

     if(temprate>=templim1 and temprate<templim2) then
       if(tempbranch <= value1) then
         result := 1;
         end if;
      end if;
    if(temprate>=templim2) then
       if(tempbranch <= value2) then
         result := 1;
         end if;
     end if;
     if(temprate<templim1) then
       result := 1;
     end if;
  else
       if(tempbranch <= value1) then
           result := 1;
       end if;
     END if;
   end if;
end if;

 return(result);
end check_brachfeeratemax;

/
