CREATE FUNCTION     "CALALLMARKB11" (
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE, -- ?????
       tIndexCalNo integer   --????
       ) return number as   --???????
v_Rate number;--???????

begin

select
(select Mark from LARateToMark where StartRate<=
  (select nvl(T22,0) from LAIndexInfo where IndexCalNo=tIndexCalNo and IndexType='04' and AgentCode=tAgentCode)
 and endRate>(select nvl(T22,0) from LAIndexInfo where IndexCalNo=tIndexCalNo and IndexType='04' and AgentCode=tAgentCode)
  and RateType='01' and AgentGrade=tAgentGrade)
+
(select Mark from LARateToMark where StartRate<=
  (select nvl(T21,0) from LAIndexInfo where IndexCalNo=tIndexCalNo and IndexType='04' and AgentCode=tAgentCode)
 and endRate>(select nvl(T21,0) from LAIndexInfo where IndexCalNo=tIndexCalNo and IndexType='04' and AgentCode=tAgentCode)
 and RateType='02' and AgentGrade=tAgentGrade )
+
(select nvl(sum(AssessMark),0) from LAAssessMark
where assessym=tIndexCalNo and (assessmarktype='01' or assessmarktype='02') and AgentCode=tAgentCode)
into v_Rate from ldsysvar where sysvar = 'onerow';

return v_Rate;
End CalallmarkB11;

/
