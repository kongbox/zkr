CREATE FUNCTION     "CALFYC" (Flag in varchar2,ACode in varchar2, AGrade in varchar2,TempBegin in date,TempEnd in date,tAreaType in varchar2) return number is
  StanFYC        number;
  tStartDate     date;
  tIndueFormDate date;
  Intvl          integer;
  tLastGrade     varchar2(3);
  Result         number;
---???????????
begin
  --????FYC
  if Flag = 'S' then
    select nvl(sum(fyc),0) into Result from lacommision
    where trim(commdire) = '1'
          and payyear < 1
          and caldate >= TempBegin
          and caldate <= TempEnd
          and trim(agentcode) = trim(ACode);
  end if;


  --?????FYC
  if Flag='B' then
    --???????
    select nvl(agentlastgrade,'C'),StartDate into tLastGrade,tStartDate from latree
    where trim(agentcode) = trim(ACode);

    if trim(tLastGrade) = 'C' or tLastGrade <> 'A01' then
      return(0);
    end if;

    select indueformdate into tIndueFormDate from laagent
    where trim(agentcode) = trim(ACode);

    if tIndueFormDate = tStartDate then
      return(0);
    end if;

    --??????
    if to_char(TempEnd,'yyyymm') <> to_char(tStartDate,'yyyymm') then
      return(0);
    else
      select months_between(startdate,oldstartdate) into Intvl from latree
      where trim(agentcode)=trim(ACode);

      if Intvl > 3 then
        return(0);
      end if;
    end if;

    select IndFYCSum into StanFYC from LAAgentPromRadix
    where trim(LimitPeriod)='01'
          and trim(AgentGrade)='A01'
          and trim(destagentgrade)=trim(AGrade)
          and trim(assesscode)='02'
          and trim(areatype)=trim(tAreaType);

    Result := StanFYC/0.8-StanFYC;
  end if;

  return(Result);
end CALFYC;

/
