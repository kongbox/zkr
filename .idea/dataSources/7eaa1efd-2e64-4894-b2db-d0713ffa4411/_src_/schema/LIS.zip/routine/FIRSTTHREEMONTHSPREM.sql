CREATE FUNCTION     "FIRSTTHREEMONTHSPREM" (tAgentCode in varchar2, tTempEnd in date,tAreaType in varchar2) return number is
  tTempDate date;
  tEmployDate  date;
  tEmployLimit  varchar2(2);
  tDay  varchar2(2);
  tEndDate date;
  tIntvl    integer:=0;
  tWageNoBegin varchar2(6);
  tWageNoEnd varchar2(6);

  Result    number:=0;
  begin

  select employdate into temploydate from laagent where agentcode=tAgentCode;
  tEmployLimit:=getEmployLimit('EmployLimit');
  tDay:=to_char(temploydate,'dd');
  if (tDay>tEmployLimit)
  then
  tEndDate:=add_months(temploydate,4);
  else
  tEndDate:=add_months(temploydate,3);
  end if;
  select yearmonth into tWageNoBegin from lastatsegment where stattype='5' and startdate<=tEmployDate
  and enddate>=tEmployDate;
  select yearmonth into tWageNoEnd from lastatsegment where stattype='5' and startdate<=tEndDate
  and enddate>=tEndDate;
  select nvl(sum(T42),0) into Result from laIndexInfo where IndexType = '00' and AgentCode =tAgentCode  and IndexCalNo >=tWageNoBegin  and IndexCalNo <=tWageNoEnd  and branchtype='1' and branchtype2='01'   ;







  return(Result);
end FirstThreeMonthsPrem;

/
