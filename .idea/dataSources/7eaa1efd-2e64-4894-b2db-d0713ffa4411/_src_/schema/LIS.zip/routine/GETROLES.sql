CREATE FUNCTION     "GETROLES" (prtno in varchar2)
return varchar2 as
res varchar2(5000);
begin
select max(ltrim(sys_connect_by_path(doccode,','),',')) into res
from (
   select doccode,rownum rn from es_doc_relation where bussno=prtno and busstype = 'TB' and subtype = '006'
)
start with rn=1 connect by rn=rownum;
if res is null then
res:= '-';
end if;
return(res);
end;

/
