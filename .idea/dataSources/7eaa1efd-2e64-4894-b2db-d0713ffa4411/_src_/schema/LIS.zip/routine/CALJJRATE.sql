CREATE FUNCTION     "CALJJRATE" (
       tBranchType lawageradix1.branchtype%Type,
       tAgentGroup laagent.agentgroup%Type,
       tWageNo lacommision.wageno%Type,
       tAgentCode laagent.agentcode%Type
  --???
) return number Is
  Result number:=0;
  wagemonth Number;
  num1 Number;
  num2 Number;
 /* num3 Number;*/

  tStartDate           date;
  tAStartDate          date;
  tEndDate            date;
begin
      wagemonth:=substr(tWageNo,5,2);
      if(wagemonth=6 or wagemonth=12 ) then

           select AStartDate into tAStartDate from labranchgroup where AgentGroup=tAgentGroup and BranchManager=tAgentCode;

           select StartDate,EndDate into tStartDate ,tEndDate from lastatsegment where stattype='3' and yearmonth=tWageNo;
           if((tAStartDate is not null) and (tAStartDate<tStartDate)) then

               select nvl(
               (Select nvl(count(*),0)   From lacommision
                        Where wageno>=to_char(tStartDate,'YYYYMM')
                             And wageno<=to_char(tEndDate,'YYYYMM') And branchtype=tBranchType And commdire=1
                           /*  And BranchAttr Like /*tBranchAttr*/
                             /*(Select trim(branchattr) From labranchgroup Where agentgroup =tAgentGroup)||'%' */
                            --???????
                             And agentgroup=tAgentGroup group by agentcode having sum(standprem)>=50),0) into num1 from ldsysvar where sysvar='onerow';

               select nvl((select beginnumber  from LAAgentPower  where agentgroup= tAgentGroup and year=substr(to_char(tStartDate,'YYYYMMDD'),1,4) and month=substr(to_char(tStartDate,'YYYYMMDD'),5,2)),0) into num2 from dual ;

               /*select nvl(count(*),0) into num3 from laagentb  where agentgroup= tAgentGroup and months_between(employdate,tStartDate)>3 ;
               ---?????????
               num2:=num2+num3;*/
               if(num2=0 or num1=0 ) then
                       Result:=1;
               else
                      Result:=num1/num2;
               end if;
          end if;
      end if;
  Return(Result);
 end CALJJRATE;

/
