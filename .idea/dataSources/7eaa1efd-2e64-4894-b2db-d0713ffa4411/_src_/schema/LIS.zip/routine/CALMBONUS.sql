CREATE FUNCTION     "CALMBONUS" (tWageNo in varchar2, tAgentCode in varchar2, tAgentGroup in varchar2) return number is
  tPerson number(12,2);
  tGroup number(12,2);
  Result number(12,2);
begin
     select nvl(sum(FYC),0) into tPerson
      from LACommision
      where CommDire = '1' and trim(WageNo) = trim(tWageNo) and trim(AgentCode) = trim(tAgentCode);
     select nvl(sum(GrpFYC),0) into tGroup
      from LACommision
      where CommDire = '1' and trim(WageNo) = trim(tWageNo) and trim(AgentGroup) = trim(tAgentGroup);
     Result := tPerson + tGroup;
  return(Result);
end CALMBONUS;

/
