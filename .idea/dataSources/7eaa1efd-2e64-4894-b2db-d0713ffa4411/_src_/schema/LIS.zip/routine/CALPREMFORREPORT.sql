CREATE FUNCTION     "CALPREMFORREPORT" (
       cManageCom in VARCHAR2,
       cGrpContNo in VARCHAR2,
       cAgentType in VARCHAR2,
       cAgentCode in VARCHAR2,
       cRiskType in VARCHAR2,
       cRiskCode in VARCHAR2,
       cStartDate in date,
       cEndDate in date,
       cPremType in VARCHAR2) return number is

  tSumPrem number(16,2):=0;
  tSumPrembq number(16,2):=0;
  tSumPremOther number(16,2):=0;
  tSumPremWT number(16,2):=0;
  tManageCom ljapaygrp.managecom%type;
  tGrpContNo ljapaygrp.grpcontno%type;
  tAgentType ljapaygrp.agenttype%type;
  tAgentCode ljapaygrp.agentcode%type;
  tRiskType lmriskapp.risktype2%type;
  tRiskCode lmriskapp.riskcode%type;
  tStartDate date;
  tEndDate date;
begin
     if (cManageCom is null or cManageCom = '' or cManageCom = 'null') then
       tManageCom:=null;
     else
       tManageCom:=cManageCom;
     end if;

     if (cGrpContNo is null or cGrpContNo = '' or cGrpContNo = 'null') then
       tGrpContNo:=null;
     else
       tGrpContNo:=cGrpContNo;
     end if;

     if (cAgentType is null or cAgentType = '' or cAgentType = 'null') then
       tAgentType:=null;
       else
       tAgentType:=cAgentType;
     end if;

     if (cAgentCode is null or cAgentCode = '' or cAgentCode = 'null') then
       tAgentCode:=null;
       else
       tAgentCode:=cAgentCode;
     end if;

     if (cRiskType is null or cRiskType = '' or cRiskType = 'null') then
       tRiskType:=null;
       else
       tRiskType:=cRiskType;
     end if;

     if (cRiskCode is null or cRiskCode = '' or cRiskCode = 'null') then
       tRiskCode:=null;
       else
       tRiskCode:=cRiskCode;
     end if;

     if (cStartDate is null ) then
      tStartDate:=null;
      else
       tStartDate:=cStartDate;
     end if;

     if (cEndDate is null ) then
      tEndDate:=null;
      else
       tEndDate:=cEndDate;
     end if;

     if (cPremType ='1' ) then

     if (tRiskType is not null and tRiskType ='A')

     then
     select nvl(sum(a.sumactupaymoney),0) into tSumPremOther from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='ZC' and a.paycount=1 and a.endorsementno is null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 in  ('A','Z');

     select nvl(sum(a.sumactupaymoney),0) into tSumPrembq from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='PG' and a.endorsementno is not null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 in  ('A','Z');

     tSumPrem := tSumPremOther+tSumPrembq;

     else

     select nvl(sum(a.sumactupaymoney),0) into tSumPremOther from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='ZC' and a.paycount=1 and a.endorsementno is null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 =nvl(tRiskType,b.risktype2);

     select nvl(sum(a.sumactupaymoney),0) into tSumPrembq from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='PG' and a.endorsementno is not null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 =nvl(tRiskType,b.risktype2);

     tSumPrem := tSumPremOther+tSumPrembq;

     end if;

     else

     if (tRiskType is not null and tRiskType ='A')

     then
     select nvl(sum(a.sumactupaymoney*report_modulus(a.grppolno)),0) into tSumPremOther from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='ZC' and a.paycount=1 and a.endorsementno is null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 in  ('A','Z');

     select nvl(sum(a.sumactupaymoney*report_modulus(a.grppolno)),0) into tSumPrembq from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='PG' and a.endorsementno is not null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 in  ('A','Z');

     tSumPrem := tSumPremOther+tSumPrembq;

     else

     select nvl(sum(a.sumactupaymoney*report_modulus(a.grppolno)),0) into tSumPremOther from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='ZC' and a.paycount=1 and a.endorsementno is null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 =nvl(tRiskType,b.risktype2);

     select nvl(sum(a.sumactupaymoney*report_modulus(a.grppolno)),0) into tSumPrembq from ljapaygrp a,lmriskapp b
     where a.managecom like nvl(tManageCom,a.managecom)||'%' and a.GrpContNo=nvl(tGrpContNo,a.GrpContNo) and a.agentcode=nvl(tAgentCode,a.agentcode)
     and a.agenttype=nvl(tAgentType,a.agenttype) and a.makedate>=nvl(tStartDate,a.makedate) and
     a.makedate<=nvl(tEndDate,a.makedate) and a.paytype ='PG' and a.endorsementno is not null and a.riskcode=b.riskcode and a.riskcode=nvl(tRiskCode,a.riskcode) and b.risktype2 =nvl(tRiskType,b.risktype2);

     tSumPrem := tSumPremOther+tSumPrembq;

     end if;

     end if;

  return (tSumPrem);
end CalPremForReport;

/
