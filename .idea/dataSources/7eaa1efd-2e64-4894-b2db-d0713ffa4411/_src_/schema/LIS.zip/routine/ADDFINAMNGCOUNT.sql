CREATE FUNCTION     "ADDFINAMNGCOUNT" (ACODE in VARCHAR2,AGROUP in VARCHAR2,YEARMONTH in VARCHAR2) return integer is
-------------------?????????????---------------------------
  ACODELOOP  VARCHAR2(10);
  ADDCOUNT   INTEGER;
begin
  ACODELOOP := ACODE;
  ADDCOUNT := 0;
  --??????????????
  DECLARE
    ADDCODE  VARCHAR2(10);
    GRADE    VARCHAR2(3);
  CURSOR C_AddFinaMngCount IS

    SELECT AGENTCODE,AGENTGRADE FROM LATREE
      WHERE state<>'3'
       AND TRIM(INTROAGENCY) = ACODELOOP
        AND TRIM(AGENTGROUP) = AGROUP;
      --tjj ????
    --AGENTCODE NOT IN
     -- (SELECT AGENTCODE FROM LAAGENT WHERE AGENTSTATE IN ('03','04','05'));

  BEGIN
    OPEN C_AddFinaMngCount;
    LOOP
      FETCH C_AddFinaMngCount INTO ADDCODE,GRADE;
      EXIT WHEN C_AddFinaMngCount%NOTFOUND;
      IF GRADE in ('A02','A03') THEN
        ADDCOUNT := ADDCOUNT + 1;
      END IF;
      ADDCOUNT := ADDCOUNT + AddFinaMngCount(ADDCODE,AGROUP,YEARMONTH);  --??
    END LOOP;
    CLOSE C_AddFinaMngCount;
  END;
  return ADDCOUNT;
end AddFinaMngCount;

/
