CREATE FUNCTION     "GETLUCKPOLSTATE" (tPrtNo in varchar2)
return varchar2 is
tnum integer;
tempPrtNo varchar2(20);
begin
--select rpad(rtrim(tprtno),20,' ') into tempPrtNo from dual;
tempPrtNo := rpad(rtrim(tprtno),20,' ');
select count(*) into tnum from LCPol where PrtNo= tempPrtNo;
if (tnum=0) then
 return '1';  --??????
end if;

select count(*) into tnum from LCPol where  PrtNo=tempPrtNo and appflag<>'1';
if (tnum>0) then
 return '1'; -- ???

end if;

select count(*) into tnum from LCPol where PrtNo= tempPrtNo and printcount<=0;
if (tnum>0) then
 return '2'; --??????
end if;

return '3'; --??????

end;

/
