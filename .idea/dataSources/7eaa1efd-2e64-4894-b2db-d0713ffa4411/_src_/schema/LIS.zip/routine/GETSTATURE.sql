CREATE FUNCTION     "GETSTATURE" (ContNo1 char, CustomerNo1 char) return number is
  Result number;
begin
  select ImpartParam into Result from LCCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 And Impartver='02' and Impartcode='000' and ImpartParamNo='1';
  return(Result);
end GetStature;

/
