CREATE FUNCTION     "FNC_ZT3_1_1" (payendyear in number) return varchar2
is
tR number;
begin

  tR := 1;

		if payendyear >= 20 then
			tR := 0.1;
		end if;
		if payendyear >= 10 and payendyear < 20 then
			tR := 0.25;
		end if;
		if payendyear < 10 then
			tR := 0.35;
		end if;
	return(tR);
end;

/
