CREATE FUNCTION     "BUSIMAGERBONUS" (tareatype in varchar2,tagentgrade in varchar2,twagecode in varchar2,twageno in varchar2,tagentgroup in varchar2,tindexcalno in varchar2,tdifficulty in varchar2,tagentcode in varchar2,tmonth in varchar2) return number is
  Result number(12,4):=0 ;
  cRenewSum2 number(12,4):=0 ;--????????????
  cRenewSum3 number(12,4):=0 ;--????????????
  cRenewSum4 number(12,4):=0 ;--????????????
  cRatio2 number(12,4):=0 ;
  cRatio3 number(12,4):=0 ;
  cRatio4 number(12,4):=0 ;
  cPassRate2 number(12,4):=0;--??????????
  cPassRate3 number(12,4):=0;--??????????
  cPassRate4 number(12,4):=0;--??????????
  cPassRadix2 number(12,4):=0;--???????
  cPassRadix3 number(12,4):=0;--???????
  cPassRadix4 number(12,4):=0;--???????
  cBusSum2 number(12,4):=0;--????????
  cBusSum3 number(12,4):=0;--????????
  cBusSum4 number(12,4):=0;--????????
  cDifficulty number(12,4):=0 ;--????
begin
  select DepDirManaSdy,AddDepSdy,T53 into cPassRate2,cPassRate3,cPassRate4 from laindexinfo where
  agentcode=tagentcode and indexcalno=tindexcalno and indextype='01' and branchtype='4' and branchtype2='01';

 --?????
    select nvl(sum(fyc),0) into cRenewSum2 from lacommision
    where payyear>=1 and agentgroup=tagentgroup and wageno=twageno
    and commdire='1' and p6=1 and paycount='2';

    select nvl(sum(fyc),0) into cRenewSum3 from lacommision
    where payyear>=1 and agentgroup=tagentgroup and wageno=twageno and commdire='1' and p6=1 and paycount='3';

    select nvl(sum(fyc),0) into cRenewSum4 from lacommision
    where payyear>=1 and agentgroup=tagentgroup and wageno=twageno and commdire='1' and p6=1 and paycount>'3';
  --????
  select drawreward into cRatio2 from lawageparam2 where wagecode =twagecode and paracode='WP0068'
  and areatype=tareatype;
  select drawreward into cRatio3 from lawageparam2 where wagecode =twagecode and paracode='WP0070'
  and areatype=tareatype;
   select drawreward into cRatio4 from lawageparam2 where wagecode =twagecode and paracode='WP0072'
  and areatype=tareatype;

  --????
  select avg(difficulty) into cDifficulty from latree where agentgroup=tagentgroup and agentseries<1 and branchtype='4';

  if cDifficulty >=1.5 then
     cDifficulty:=0;--??
  else
     cDifficulty:=1;
  end if;

  --?????
  if tmonth<=2 then
    cPassRadix2:=1;
    cPassRadix3:=1;
    cPassRadix4:=1;
  else
    select drawreward into cPassRadix2 from lawageparam1 where wagecode=twagecode and paracode='WP0067'
    and areatype=tareatype and lowlimit<=cRenewSum2 and highlimit>=cRenewSum2 and standard=cDifficulty;
    select drawreward into cPassRadix3 from lawageparam1 where wagecode=twagecode and paracode='WP0069'
    and areatype=tareatype and lowlimit<=cRenewSum3 and highlimit>=cRenewSum3 and standard=cDifficulty;
    select drawreward into cPassRadix4 from lawageparam1 where wagecode=twagecode and paracode='WP0071'
    and areatype=tareatype and lowlimit<=cRenewSum4 and highlimit>=cRenewSum4 and standard=cDifficulty;
  end if;
  cBusSum2:=cRenewSum2*cRatio2*cPassRadix2;

  cBusSum3:=cRenewSum3*cRatio3*cPassRadix3;

  cBusSum4:=cRenewSum4*cRatio4*cPassRadix4;

  Result := cBusSum2+cBusSum3+cBusSum4;
  return(Result);
end BusiMagerBonus;

/
