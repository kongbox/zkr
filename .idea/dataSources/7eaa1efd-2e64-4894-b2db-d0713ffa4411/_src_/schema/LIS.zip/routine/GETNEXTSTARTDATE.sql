CREATE FUNCTION     "GETNEXTSTARTDATE" ( tRiskCode in varchar2,tInsuAccNo in varchar2 ,tBaseDate in date) return date is

    tPriceDate date;
begin

  Select max(StartDate) into tPriceDate from LOAccUnitPrice where riskcode=tRiskCode and InsuAccNo=tInsuAccNo and StartDate <=tBaseDate and state='0';

  if tPriceDate is null

  then

    tPriceDate:=to_Date('2999-12-31','yyyy-mm-dd');

   end if;

  return(tPriceDate);

END;

/
