CREATE FUNCTION     "ASSESSGRPFINALSCORE" (
       tAgentCode laagent.agentcode%Type,
       tAgentGrade latree.agentgrade%Type,
       tManageCom latree.managecom%Type,
       tIndexCalNo laindexinfo.indexcalno%Type,
       tBranchType laagent.branchtype%Type,
       tTempBegin latree.startdate%Type,
       tTempEnd latree.startdate%Type
)
return  Number is
  Result Number;
  ---??????
  lastScore  Number;
  thisStandPrem  Number;
  thisScore  Number;
  tAgentKind Varchar2(6);
  lastCalNo      Varchar2(6);
  tStandPrem  number;
  tAreaType char;
Begin

     thisStandPrem:= 0;
     Select nvl(Sum(standprem),0) Into thisStandPrem From lacommision
            Where tmakedate<=tTempEnd And branchtype=tBranchType And paycount='1' And tmakedate>=tTempBegin And AgentCode=tAgentCode;
     Select substr(Agentkind,0,1) Into tAgentKind from LATree where agentcode=tAgentCode;
     select trim(comareatype) Into tAreaType from ldcom where trim(comcode)=tManageCom;
     select distinct(DropGrade) Into tStandPrem from LAAgentPromRadix2
              where agentgrade=tAgentGrade and branchtype=tBranchType and areatype=tAreaType;
     If (tAgentKind is null or length(tAgentKind)=0) then
      thisScore:=thisStandPrem*100/tStandPrem;
     elsif (tAgentKind='G') then
      thisScore:=thisStandPrem*100/(tStandPrem*0.3);
     else
          thisScore:=0;
     End If;
     Select nvl(Max(indexcalno),0) Into lastCalNo From laindexinfo Where AgentCode=tAgentCode And indexType='04';
     If (lastCalNo<>'0' And lastCalNo<>tIndexCalNo) Then
        Select nvl(T27,0) Into lastScore From laindexinfo Where AgentCode=tAgentCode And indexType='04'And indexcalno=lastCalNo;
        Result:=thisScore*0.7+lastScore*0.3;
     Else
       Result:=thisScore;
     End If;
     return(Result);
end AssessGrpFinalScore;

/
