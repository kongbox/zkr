CREATE FUNCTION     "CALSERVERMONEY" (
       tAgentGrade lawageradix1.agentgrade%Type,
       tBranchType lawageradix1.branchtype%Type,
       tAgentCode laagent.agentcode%Type,
       tWageNo lacommision.wageno%Type,
       tAgentGroup laagent.agentgroup%Type,
       tManageCom latree.managecom%Type
)
  return number is
  Result number:=0;
  tFYC number(12,4);
  tK1 number(12,4);
  tK number(12,4);
  tServerRate number(12,4);
  tAreaType             char; --????
begin
select trim(comareatype) Into tAreaType from ldcom where trim(comcode)=tManageCom;
  select T71 Into tK1 from laindexinfo where  indexcalno=tWageNo
   and  agentcode=tAgentCode and  agentgrade=tAgentGrade and  branchtype=tBranchType and  agentgroup=tAgentGroup and indextype='01' and branchtype2='03';
   If(tK1>1.2) then
      tK:=1.2;
   elsif (tK1>0.6) then
         tK:=tK1;

   else
       tK:=0.6;
   end If;
   Select nvl(Sum(P8),0) into tFYC From lacommision Where wageno=tWageNo
       And  AgentCode in (select agentcode from laperagent where popedom in (select trim(code1) from ldcode1 where codetype='agent_popedom' and code=tAgentCode) and agentstate in ('01','02','06'));
   Select nvl(drawrate,1)*tK Into tServerRate From lawageradix1
                    Where branchtype=tbranchtype And wagecode='LRate' and agentgrade=tAgentGrade and branchtype2='03';

   Result:=tFYC*tServerRate;
   Return(Result);

end CALSERVERMONEY;

/
