CREATE FUNCTION     "FNC_209" (c_cureType char,n_caseNo number,n_daysInHos number,d_accidentDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate1 Date;
  d_limitDate2 Date;
  d_limitDate3 Date;
begin

Result:=0;                               --?Result??
-------------------------------------------------------------------------------------------------------------

if c_cureType<>'A' and d_accidentDate<=d_startDate and d_lcgetStartDate<=d_startDate then      --?????????????
                                                             --????????????
     select least(to_date((min(StartDate)+30),'YYYY-MM-DD HH24:MI:SS'),d_lcgetEndDate) into d_limitDate1 from LLCaseReceipt where CaseNo=n_CaseNo and FeeItemType<>'A';      --?????30????????

     select least(to_date((min(StartDate)+60),'YYYY-MM-DD HH24:MI:SS'),d_lcgetEndDate) into d_limitDate2 from LLCaseReceipt where CaseNo=n_CaseNo and FeeItemType<>'A';      --?????60????????

     select least(to_date((min(StartDate)+30),'YYYY-MM-DD HH24:MI:SS'),d_lcgetEndDate) into d_limitDate3 from LLCaseReceipt where CaseNo=n_CaseNo and FeeItemType<>'A';      --?????90????????

   if d_endDate<d_limitDate1 then                                  --?????30??
     	select 50*n_daysInHos into Result from Dual;
   end if;

   if d_limitDate1<=d_endDate and d_endDate<d_limitDate2 then    --?????30?-60??
      select 40*(n_daysInHos-30)+50*30 into Result from Dual;
   end if;

   if d_limitDate2<=d_endDate and d_endDate<d_limitDate3 then    --?????60?-90??
      select 30*(n_daysInHos-60)+(50+40)*30 into Result from Dual;
   end if;

   if d_limitDate3<=d_endDate then                                 --?????90??
      select (50+40+30)*30 into Result from Dual;
   end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_209;

/
