CREATE FUNCTION     "DIRECTDPRTCONTI_RATE" (ACODE     in VARCHAR2,
                                                GCODE     in VARCHAR2,
                                                AGRADE    in VARCHAR2,
                                                YEARMONTH in VARCHAR2,
                                                SDATE in DATE,
                                                EDATE   in DATE)
  return number is
  ----------??????????--------------
  v_AVERAGERATE     NUMBER(12,2);       --?????
  SUMCOUNT          INTEGER;            --?????
  SUMPREM           NUMBER;             --?????
  SUMINVALIDCOUNT   INTEGER;            --????????????
  SUMINVALIDPREM    NUMBER;             --??????????????
begin
  --???????
  SUMPREM := REARDEPRATEPREM(ACODE,GCODE,AGRADE,YEARMONTH,SDATE,EDATE,1);
  IF SUMPREM = 0 THEN
    RETURN -1;
  END IF;
  --???????
  SUMCOUNT := REARDEPRATECOUNT(ACODE,GCODE,AGRADE,YEARMONTH,SDATE,EDATE,1);

  ---??????????????
  SUMINVALIDPREM := REARDEPRATEPREM(ACODE,GCODE,AGRADE,YEARMONTH,SDATE,EDATE,0);

  --????????????
  SUMINVALIDCOUNT := REARDEPRATECOUNT(ACODE,GCODE,AGRADE,YEARMONTH,SDATE,EDATE,0);

  IF SUMPREM > 0 AND SUMCOUNT > 0 THEN
    v_AVERAGERATE := SUMINVALIDPREM/SUMPREM*0.5 + SUMINVALIDCOUNT/SUMCOUNT*0.5;
  ELSIF SUMCOUNT = 0 THEN
    v_AVERAGERATE := SUMINVALIDPREM/SUMPREM*0.5;
  END IF;

  RETURN(v_AVERAGERATE);

end DIRECTDPRTCONTI_RATE;

/
