CREATE FUNCTION     "GETCALDATE" (cGetPolDate In Varchar2,cSignDate In Varchar2,
                                      cMakeDate In Varchar2,cChargeDate In Varchar2,
                                      cBranchType In Varchar2,cPayCont In Varchar2)
return Date Is Result Date;
ChargeDate Date;
Begin
  If cMakeDate Is Null Then
    Return(Null);
  End If;
  Select to_date(cMakeDate) Into Result From dual;
  IF cBranchType = '2'  And cChargeDate Is Not Null Then
  Select to_date(cChargeDate) Into ChargeDate From dual;
    IF ChargeDate > Result THEN
      Result := ChargeDate;
    END IF;
  END IF;
  select EndDate Into Result from LAStatSegment where stattype = '5' and
    Result>=StartDate AND  Result <=EndDate;
  return(Result);
end getcaldate;

--alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS';

/
