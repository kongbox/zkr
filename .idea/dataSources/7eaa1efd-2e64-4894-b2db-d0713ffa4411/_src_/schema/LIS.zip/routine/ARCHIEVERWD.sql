CREATE FUNCTION     "ARCHIEVERWD" (tagentcode in varchar2,tagentgrade in varchar2, twageno in varchar2,
                                       tareatype in varchar2,twagecode in varchar2,
                                       tbranchtype lawageradix.branchtype%type,tbranchtype2 in varchar2,tAgentState in varchar2) return number is
 cstartdate       date;
 cagentlastgrade  varchar2(4);
 cinitgrade       varchar2(4);
 C                varchar2(1);
 cStandPrem       number(20,6):=0;   ---??????
 cRwd             number(20,6):=0;   ---?????
 climitperiod     integer;
 cworkyears       integer;

begin
  ---???????
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;


  ---?????????,?????????,?????
  select agentlastgrade,startdate,initgrade into cagentlastgrade,cstartdate,cinitgrade
  from latree where agentcode=tagentcode;

  if cinitgrade='A103' or cinitgrade='A104' then
     return (0);
  end if;

  select nvl(addcount,0) into cworkyears from laindexinfo
  where agentcode=tagentcode and indextype='00' and indexcalno=twageno and branchtype='1' and branchtype2='01' ;

  if cworkyears<7 then
     return (0);
  end if;

  if ToFormalMonths(tagentcode)>=4 then
  return (0);
  end if;

   ---??????????
  select count(distinct agentcode) into C from laindexinfo
  where addcount>=1 and addcount<=6 and agentgrade<='A102'
        and indextype='00' and agentcode=tagentcode and branchtype='1' and branchtype2='01';

  if C>=1 then
    return (0);
  end if;

  --- ??????
  select sum(nvl(T42,0)) into cStandPrem from laindexinfo
  where agentcode=tagentcode and indextype='00' and addcount>=4 and addcount<=6 and branchtype='1' and branchtype2='01';

   select limitperiod,rewardmoney into climitperiod,cRwd from lawageradix
   where agentgrade=tagentgrade and wagecode=twagecode and areatype=tareatype
         and branchtype=tbranchtype and branchtype2=tbranchtype2
         and fycmin<=cStandPrem and fycmax>cStandPrem;

  ---???????????
  if climitperiod is null or cRwd is null then
     return 0;
  end if;

  if cworkyears=climitperiod then
     return(cRwd);
  else
     return 0;
  end if;

end ArchieveRwd;

/
