CREATE FUNCTION     "ANNUITY" (tagentcode in varchar2, tindexcalno in varchar2,flag in varchar2) return number  is
  Result number(20,6):=0;
  --flag =1 ???? =0 ????
  cPersonAnnuity number(20,6):=0;
  cComAnnuity number(20,6):=0;
begin
  select nvl(T27,0)-nvl(t8,0)-nvl(T17,0)-nvl(T18,0)-nvl(T19,0)
         -nvl(T20,0)-nvl(T21,0)-nvl(T22,0)-nvl(T23,0) into Result
  from laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno and indextype='01'  and branchtype='1' and branchtype2='01';

  if Result>0 then
     if flag='1' then
        select t8 into cPersonAnnuity from  laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno and indextype='01'  and branchtype='1' and branchtype2='01';
        Result :=  cPersonAnnuity;
     else
        select t13 into cComAnnuity from  laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno and indextype='01'  and branchtype='1' and branchtype2='01';
        Result := cComAnnuity;
     end if;
  else
     Result :=0;
  end if;

  return(Result);
end Annuity;

/
