CREATE function     em_amnt(polno1     in varchar2,
                                   risk       in varchar2,
                                   cvalidate1 in varchar2,
                                   insuredno1 in varchar2,
                                   age1       in number,
                                   amnt1      in number)

 return varchar2 is
  Result varchar2(3);
  amnt   number;
begin
  Result := null;
  select nvl(sum(amnt),0) + amnt1
    into amnt
    from lcpol
   where polno != polno1
     and appflag in ('0', '1', '2')
     and (uwflag not in ('1', 'a') or uwflag is null)
     and enddate > to_date(cvalidate1,'yyyy-mm-dd')
     and insuredno = insuredno1
     and grppolno not in (select proposalno from lcapplyrecallpol)
     and riskcode = risk
     and exists (select 1
            from lcgrpaddfield
           where grpcontno = lcpol.grpcontno
             /*and riskcode = lcpol.riskcode*/
             and fieldtype = '100');
  if (age1 >= 18  and age1 <=60 and amnt > 1000000) then
    Result := 1;
  end if;


  return(Result);

END em_amnt;

/
