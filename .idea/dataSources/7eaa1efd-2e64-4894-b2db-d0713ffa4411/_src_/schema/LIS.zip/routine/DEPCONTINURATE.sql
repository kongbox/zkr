CREATE FUNCTION     "DEPCONTINURATE" (cbranchseries in nvarchar2, cWageno in nvarchar2,
                                          cAgentgrade in nvarchar2, cWagecode in nvarchar2,
                                          cBranchtype lawageradix.branchtype%type,cbranchtype2 in varchar2,
                                          cAreatype in nvarchar2,tAgentState in varchar2)
                                          return number is
  --????
  Result               number(20,6):=0 ;
  tDepAvgRate          number(20,6):=0 ;
  tDrawRate           number(20,6):=0 ;
  tBaseWage            number(20,6):=0 ;
  /*cED                  varchar2(8);
  ED                   date;*/
begin
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;
 /*---???A301????10????????????????
     if cagentgrade='A301' then
        select employdate into ED from laagent where agentcode=cagentcode;
        cED:=to_char(ED,'yyyymmdd');
        if substr(cED,7,2)>'10' and cwageno=substr(cED,1,6) then
           return 0;
        end if;
     end if;*/
  --???????
  select Round((decode(sum(T32),0,0,sum(T31)/sum(T32))*0.5 + decode((T34),0,0,sum(T33)/sum(T34))*0.5),2) into tDepAvgRate
  from laindexinfo where branchseries like cbranchseries||'%'
  and indexcalno=cwageno and indextype = '00' and branchtype='1' and branchtype2='01';

--??????
  select nvl(DrawRate,0) into tDrawRate from lawageradix
  where agentgrade=cAgentgrade and wagecode=cWagecode and branchtype=cBranchtype and areatype=cAreatype
        and (FYCMin<=tDepAvgRate and FYCMax>tDepAvgRate) and branchtype2=cbranchtype2;
--???????????????
  select nvl(sum(BaseWage),0) into tBaseWage from laindexinfo
  where branchseries like cbranchseries||'%'
  and indexcalno= cWageno and indextype = '01' and branchtype='1' and branchtype2='01';

  Result:=tBaseWage*tDrawRate;
  return(Result);
end DEPCONTINURATE;

/
