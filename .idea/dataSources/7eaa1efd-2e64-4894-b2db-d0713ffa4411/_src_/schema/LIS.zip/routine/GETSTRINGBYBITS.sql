CREATE FUNCTION     "GETSTRINGBYBITS" (tString in varchar2, tbits in int) return varchar2 is
  Result varchar2(6000);
  tIndex   int ;
begin
  if lengthb(tString)<=tbits then
    Result:=tString;
  else
    for i in tbits/2.. tbits+1 loop
      tIndex:=i;
      Result:=substr(tString,1,tIndex);
      exit when lengthb(Result)>tbits;
    end loop;
    Result:=substr(tString,1,tIndex-1);
  end if;

  return(Result);
end getStringbyBits;

/
