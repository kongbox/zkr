CREATE FUNCTION     "GETINSUREDSTATE" (tGrpContNo in varchar2, tContNo in varchar2)
return varchar2 is
Result varchar2(20);
tAppFlag varchar2(2);
syCnt number;--??
yxCnt number;--??
mqCnt number;--??
zzCnt number;--??
begin
       SELECT to_number(COUNT(*)) INTO syCnt FROM lcpol WHERE grpcontno=tGrpContNo AND contno=tContNo;
       SELECT to_number(COUNT(*)) INTO yxCnt FROM lcpol WHERE appflag='1' AND polstate='1' AND grpcontno=tGrpContNo AND contno=tContNo;
       SELECT to_number(COUNT(*)) INTO mqCnt FROM lcpol WHERE appflag='3' AND polstate='3' AND grpcontno=tGrpContNo AND contno=tContNo;
       SELECT to_number(COUNT(*)) INTO zzCnt FROM lcpol WHERE appflag='4' AND grpcontno=tGrpContNo AND contno=tContNo;
       SELECT appflag INTO tAppFlag FROM lcgrpcont WHERE grpcontno=tGrpContNo;
       if(tAppFlag = '4') THEN
                  Result := '3';
       ELSE
                  if(yxCnt > 0) THEN --????????
                           Result := '1';
                  elsif(syCnt = mqCnt) THEN --????????????
                           Result := '3';
                  elsif(syCnt = zzCnt) THEN --??????????
                           Result := '3';
                  elsif(syCnt = mqCnt + zzCnt) THEN --?????????????
                           Result := '3';
                  ELSE
                           Result := '9';
                  END if;
       END IF;
  --Result := 'getInsuredState';
  return(Result);
end getInsuredState;

/
