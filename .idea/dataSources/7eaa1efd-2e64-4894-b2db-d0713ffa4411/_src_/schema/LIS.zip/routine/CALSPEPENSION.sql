CREATE FUNCTION     "CALSPEPENSION" (
       tAgentCode laagent.agentcode%Type,
       tBranchType lawageradix1.branchtype%Type,
       tWageNo lacommision.wageno%Type,
       --tWageCode lawageradix1.wagecode%Type,
       flag Number
) return number Is
  Result Number;
  cond Number;
begin
----?????????
If (flag=1) then --??????????
        select count(AgentCode) into cond from laagent where RecommendAgent=tAgentCode And branchtype=tBranchType
                           And to_char(indueformdate,'yyyymm')=tWageNo And employdate<=indueformdate;
        Result:=cond*500;
  else if(flag=2) then  --????????
        select count(a.AgentCode) into cond from latree a,labranchgroup b,laagent c where a.branchtype=tBranchType
                           and a.agentgroup=b.agentgroup
                           And to_char(a.StartDate,'yyyymm')=tWageNo And substr(a.AgentGrade,1,1)='T'
                           and a.agentlastgrade<a.agentgrade  and b.branchmanager=tAgentCode and b.branchtype=tBranchType
                           and c.agentcode=a.agentcode and to_char(c.indueformdate,'yyyymm')<>tWageNo;

        Result:=cond*500;
  else    --?????
        select nvl(sum(T2),0)*0.2 Into Result from laindexinfo where agentcode in (select agentcode from latree where EduManager=tAgentCode and branchtype=tBranchType
                          and to_char(RearCommStart,'yyyymm')<=tWageNo and tWageNo<=to_char(RearCommEnd,'yyyymm') and RearBreakFlag='0') and indextype='01'
                          and substr(indexcalno,1,4)=substr(tWageNo,1,4);
  end if;
end if;
Return(Result);
end CALSPEPENSION;

/
