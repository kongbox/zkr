CREATE FUNCTION     "CALFEE" (triskcode in varchar2,money in number,yearinterval in number) return number
is
fee number;
begin
 select money*rate into fee from rt_tl where riskcode=triskcode and minyearinterval<=yearinterval and maxyearinterval>yearinterval;
 return(round(fee,2));
  -- RETURN 0;

end;

/
