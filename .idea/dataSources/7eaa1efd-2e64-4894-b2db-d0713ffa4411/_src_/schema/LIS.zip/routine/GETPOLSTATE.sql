CREATE FUNCTION     "GETPOLSTATE" (Name in type, Name in type, ...) return varchar2 is
  Result varchar2;
begin

  return(Result);
end getPolState;

/
