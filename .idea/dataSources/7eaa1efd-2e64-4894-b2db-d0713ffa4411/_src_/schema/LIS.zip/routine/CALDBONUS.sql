CREATE FUNCTION     "CALDBONUS" (
       tAgentGroup in varchar2, --????
       tWageNo in varchar2) return number is
  tBranchAttr LABranchGroup.BranchAttr%TYPE;
  Result number:=0;
  --???????????

  begin

    select BranchAttr into tBranchAttr
     from LABranchGroup
     where trim(AgentGroup) = trim(tAgentGroup);

    select nvl(sum(DepFYC),0) into Result
     from LACommision
      where CommDire = '1' and trim(WageNo) = trim(tWageNo) and BranchAttr like trim(tBranchAttr)||'%' ;


  return(Result);
end CALDBONUS;

/
