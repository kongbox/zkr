CREATE FUNCTION     "ADVANCEREARDEPLABOR" (
       tbranchseries in VARCHAR2,
       tempbegin in date,
       tempend in date) return number is
-------------------?????????????---------------------------

  monthnum integer;
  dcount   number(12,6):=0;
  agentcount integer;
begin


  --???????
  monthnum:=getmonths(tempbegin,tempend);
  agentcount:=0;

  ---????????
  declare
    cursor c_depcount is
      select sum(nvl(CalCount,0)) from lacommision a,latree b
      where a.tmakedate>=tempbegin and a.tmakedate<=tempend
      and a.commdire='1' and a.p6=0 and a.agentcode=b.agentcode
      and a.branchseries like tbranchseries||'%'
      and b.state='0'
      order by a.agentcode;

      begin
        open c_depcount;
           loop
           fetch c_depcount into dcount;
           exit when c_depcount%notfound;
           if dcount is null then
              dcount:=0;
           end if;
           if dcount/monthnum>=1 then
              agentcount:=agentcount+1;
           end if;

           end loop;
        close c_depcount;
      end;


  return agentcount;
end AdvanceRearDepLabor;

/
