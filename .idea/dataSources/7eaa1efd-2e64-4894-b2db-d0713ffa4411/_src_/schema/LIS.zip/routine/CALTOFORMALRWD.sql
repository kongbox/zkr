CREATE FUNCTION     "CALTOFORMALRWD" (tAgentCode in varchar2,tAgentGrade in varchar2, tWageCode  in varchar2,tAreaType in varchar2,TempEnd in date) return number is
  tID           Date;
  tED           Date;
  tBottom3      varchar2(12);  --????????
  tBottom6      varchar2(12);  --????????
  tEDay         varchar2(6);
  tFlagIn       varchar2(2);
  tLimit        integer;
  tAgentState   varchar2(2);
  Result number;
  ---?????
begin
  -- ?????????????
  select indueformdate,employdate,agentstate into tID,tED,tAgentState from laagent
  where trim(agentcode) = trim(tAgentCode);

  if tAgentState = '02' then
    return(0);
  end if;


  if tID is null or to_char(tID,'yyyymm') <> to_char(TempEnd,'yyyymm') then
    return(0);
  end if;

  -- ?????A02??????
  if tID = tED then
    return(0);
  end if;

  -- ??????????
  tEDay := to_char(tED,'dd');
  if tEDay > trim(getEmployLimit('EmployLimit')) then
  --?????
    if to_char(tED,'mm') <> to_char(tID,'mm')-1 then
      tFlagIn := 'N';
    end if;

    if tFlagIn = 'N' then
      tBottom3 := to_char(add_months(tED,4),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,7),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    else
      tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    end if;
  else
    tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
    tBottom3 := concat(substr(tBottom3,1,8),'01');

    tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
    tBottom6 := concat(substr(tBottom6,1,8),'01');
  end if;

  if tID <= to_date(tBottom3,'yyyy-mm-dd') then
    tLimit := 2;    --??????
  else
    if tID > to_date(tBottom3,'yyyy-mm-dd') and tID <= to_date(tBottom6,'yyyy-mm-dd') then
      tLimit := 5;  --??????
    else
      return(0);    --???????
    end if;
  end if;


  select nvl(RewardMoney,0) into Result from LAWageRadix
  where DrawStart < tLimit
  and DrawEnd >= tLimit
  and judgeifdegrade( tAgentCode ) <> 1
  and trim(AreaType) = trim(tAreaType)
  and trim(AgentGrade) = trim(tAgentGrade)
  and trim(WageCode) = trim(tWageCode)
  ;

  return(Result);
end CALTOFORMALRWD;

/
