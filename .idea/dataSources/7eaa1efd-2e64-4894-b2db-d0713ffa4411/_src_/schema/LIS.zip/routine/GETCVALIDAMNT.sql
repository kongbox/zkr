CREATE FUNCTION     "GETCVALIDAMNT" (strRiskcode in varchar
               ,iType in integer
               ,iPayCount in integer
               ,strPayIntv in varchar
               ,dCashValue in number
               ,dAmnt in number
               ,dPrem in number
               ,iCurYear in integer
               ,iMult in integer
               ,iAppentAge in integer
               ,iGetAge in integer
               ,iInsureYears in integer
               ,iPayYears in integer
               ,iPassMonth in integer
               ,iPassYear in integer) return number is
  CvalidAmnt number(10,2) :=0;
begin

  --110?110B?143
  if strRiskcode in ('00110000','00110B00','00143000') then
     CvalidAmnt := dAmnt*2;
     return CvalidAmnt;
  end if;

   --109?141
  if strRiskcode in ('00109000','00141000') then
     CvalidAmnt:= (1+0.05*iPassYear)*dAmnt;
     return  CvalidAmnt;
  end if;
    --128?126?138
  if strRiskcode in ('00128000','00126000','00138000') then
      if(strPayIntv=0) then
       CvalidAmnt := dPrem*1.5;
       return CvalidAmnt;
      end if;
      if(strPayIntv<>0) then
       CvalidAmnt := dPrem*1.5*iPayCount;
       return CvalidAmnt;
      end if;
  end if;
    --146
  if(strRiskcode='00146000') then

   if(strPayIntv=0) then

      if(iCurYear<1) then
       CvalidAmnt := dPrem+iMult*1000;
       return CvalidAmnt;
      end if;
      if(iCurYear>=1) then
       CvalidAmnt := dPrem+iMult*10000;
       return CvalidAmnt;
      end if;

   end if;

   if(strPayIntv<>0) then
      if(iCurYear<1) then
       CvalidAmnt := dPrem*iPayCount+iMult*1000;
       return CvalidAmnt;
      end if;
      if(iCurYear>=1) then
       CvalidAmnt := dPrem*iPayCount+iMult*10000;
       return CvalidAmnt;
      end if;
   end if;

  end if;
   --108
   if(strRiskcode='00108000') then
     if(iType=2) then
      CvalidAmnt:=iMult*40000;
      return CvalidAmnt;
      end if;
     if(iType<>2) then
      CvalidAmnt:=iMult*20000;
      return CvalidAmnt;
      end if;
  end if;
      --145
    if(strRiskcode='00145000') then
      if(strPayIntv=0) then
       CvalidAmnt:=dPrem*(1+0.03*iPassYear);
       return  CvalidAmnt;
      end if;
      if(strPayIntv<>0) then
        if(iPassYear<iPayYears) then
         CvalidAmnt:=dPrem*(iPassYear+1+0.03*iPassYear+(iPassYear+1)/2);
         return CvalidAmnt;
        end if;
        if(iPassYear>iPayYears) then
         CvalidAmnt:=dPrem*(iPayYears+0.03*iPayYears*(2*iPassYear-iPayYears+1)/2);
         return CvalidAmnt;
        end if;
   end if;
  end if;
      --104
  if(strRiskcode='00104000') then
     CvalidAmnt:=iMult*10000;
     return CvalidAmnt;
  end if;
     --115
  if(strRiskcode='00115000') then
   if((iMult*1000)<100000) then
     CvalidAmnt:=iMult*1000;
     return CvalidAmnt;
   end if;
   if((iMult*1000)>100000) then
     CvalidAmnt:=100000;
     return CvalidAmnt;
   end if;
  end if;
    --107
  if(strRiskcode='00107000') then
     if(strPayIntv=1)then
      if((iPassYear<1) or (iAppentAge+iPassYear)>60) then
        CvalidAmnt := dPrem+dAmnt;
        return CvalidAmnt;
      end if;
      if(iPassYear>1 and (iAppentAge+iPassYear)<60) then
        CvalidAmnt := dAmnt*4;
        return CvalidAmnt;
      end if;
     end if;

     if(strPayIntv<>1) then
      if(iPassYear<1 or(iAppentAge+iPassYear)>60) then
        CvalidAmnt := dAmnt+dPrem*iPayCount;
        return CvalidAmnt;
      end if;
      if(iPassYear>1 and  (iAppentAge+iPassYear)<60) then
        CvalidAmnt := dAmnt*4;
        return CvalidAmnt;
      end if;
    end if;
   end if;

 --133? 134? 135?136?137?147?240?142?235?236?601
 if strRiskcode in ('00133000','00134000','00135000','00136000','00137000','00147000','00240000','00142000','00236000','00235000','00601000') then
   if(iPassYear<1)then
    if((dAmnt*0.1+dPrem)> dAmnt) then
     CvalidAmnt:=dAmnt*0.1+dPrem;
     return CvalidAmnt;
    end if;
    if((dAmnt*0.1+dPrem)< dAmnt) then
     CvalidAmnt:=dPrem;
     return CvalidAmnt;
     end if;
   end if;
   if(iPassYear>=1) then
    CvalidAmnt:=dAmnt;
    return  CvalidAmnt;
   end if;
  end if;

 --230?231?233?234?617?268
  if strRiskcode in ('00230000','00231000','00233000','00234000','00617000','00268000') then
   if(iPassYear<1) then
    CvalidAmnt:=dAmnt*0.1+dPrem;
    return CvalidAmnt;
   end if;
   if(iPassYear>=1) then
    CvalidAmnt:=dAmnt;
    return CvalidAmnt;
   end if;
  end if;
   --129?101
   if strRiskcode in ('00129000','00101000') then
   CvalidAmnt:=dCashValue;
   return CvalidAmnt;
   end if;
   --130
   if strRiskcode in ('00130000') then
    return 0;
   end if;
   --265
   if strRiskcode in('00265000') then
    CvalidAmnt:=dAmnt*(1+0.02*iPassYear);
    return  CvalidAmnt;
   end if;
   --614
   if strRiskcode in('00614000') then
     if(strPayIntv=0) then
      CvalidAmnt:=dAmnt;
      return CvalidAmnt;
     end if;
     if(strPayIntv=12) then
      CvalidAmnt:=dAmnt*(iPassYear+1)/iInsureYears;
      return CvalidAmnt;
     end if;
     if(strPayIntv=1) then
      CvalidAmnt:=dAmnt*(iPassMonth+1/(iInsureYears*12));
      return CvalidAmnt;
     end if;
   end if;

   --615
   if strRiskcode in('00615000') then
     if(strPayIntv=0) then
      CvalidAmnt:=dAmnt;
      return CvalidAmnt;
     end if;
     if(strPayIntv=12) then
      CvalidAmnt:=dAmnt*(iPassYear+1)/(iInsureYears-iAppentAge);
      return CvalidAmnt;
     end if;
     if(strPayIntv=1) then
      CvalidAmnt:=dAmnt*(iPassMonth+1/((iInsureYears-iAppentAge)*12));
      return CvalidAmnt;
     end if;
   end if;
   --153
   if strRiskcode in ('00153000') then
    CvalidAmnt:=dAmnt*3;
    return CvalidAmnt;
   end if;

   --608
   if strRiskcode in ('00608000') then
    if(iPassYear<1) then
     CvalidAmnt:=dPrem;
     return CvalidAmnt;
    end if;
    if(iPassYear>=1) then
     CvalidAmnt:=dAmnt*(iPassYear+1)/iInsureYears;
     return CvalidAmnt;
    end if;
   end if;

   --902
   if strRiskcode in ('00902000') then
    CvalidAmnt := dAmnt*1.1;
    return CvalidAmnt;
   end if;

   --618
   if strRiskcode in ('00618000') then
    if(iGetAge>(iPassYear+iAppentAge)) then
     CvalidAmnt:=iPayCount*dprem;
     return CvalidAmnt;
    end if;
    if (iGetAge<=(iPassYear+iAppentAge)) then
     CvalidAmnt:=dPrem*(80-(iAppentAge+iPassYear)*0.15+1);
     return CvalidAmnt;
    end if;
   end if;

   --619
   if strRiskcode in ('00619000') then
    if(iGetAge>(iPassYear+iAppentAge)) then
     CvalidAmnt:=dPrem;
     return CvalidAmnt;
    end if;
    if (iGetAge<=(iPassYear+iAppentAge)) then
     CvalidAmnt:=dPrem*(80-(iAppentAge+iPassYear)*0.15+1);
     return CvalidAmnt;
    end if;
   end if;
 --105?110A?118?131?132?138?139?143?144?146?148?150?152?201?210?215?216?221?227?232?235?240?241?242?268?273?278?602?603?604?607?609?611?613?616?623?701
   if strRiskcode in ('00105000','00110A00','00118000','00131000','00132000','00138000','00139000','00143000','00144000','00148000','00150000','00152000','00201000','00210000','00215000','00216000','00221000','00227000','00232000','00235000','00240000','00241000','00242000','00268000','00273000','00278000','00603000','00604000','00607000','00609000','00611000','00613000','00616000','00623000','00701000') then
     CvalidAmnt:=dAmnt;
     return CvalidAmnt;
   end if;

  return(CvalidAmnt);
end getCvalidAmnt;

/
