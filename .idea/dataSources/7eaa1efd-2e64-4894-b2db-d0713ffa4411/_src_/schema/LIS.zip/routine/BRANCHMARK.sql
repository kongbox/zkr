CREATE FUNCTION     "BRANCHMARK" (
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE, -- ?????
       tIndexCalNo integer   --????
       ) return number as   --???????
v_Rate number;--???????

begin
select (
select nvl(sum(AssessMark),0) from LAAssessMark where
assessym=tIndexCalNo and
(assessmarktype='05' or assessmarktype='06' or assessmarktype='07' or assessmarktype='08')
and AgentCode=tAgentCode )
+
(select Mark from LARateToMark where StartRate<=
(select T22 from LAIndexInfo where IndexCalNo = tIndexCalNo and IndexType='04' and AgentCode=tAgentCode )
 and endRate>(select T22 from LAIndexInfo where IndexCalNo = tIndexCalNo
 and IndexType='04' and AgentCode=tAgentCode)
  and BranchType='3' and RateType='01' and AgentGrade=tAgentGrade )
into v_Rate from ldsysvar where sysvar = 'onerow';

return v_Rate;
End BranchMark;

/
