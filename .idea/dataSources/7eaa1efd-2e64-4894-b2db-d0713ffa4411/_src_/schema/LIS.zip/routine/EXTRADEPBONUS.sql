CREATE FUNCTION     "EXTRADEPBONUS" (tagentcode in varchar2,tagentgrade in varchar2,
                                     tareatype in varchar,twageno in varchar2,
                                     twagecode in varchar2,tbranchtype lawageradix.branchtype%type,
                                     tbranchtype2 in varchar2,tAgentState in varchar2,tconnmanagerstate in varchar2) return number is

  ---???????,???????????

ExtraDepBonus           number(20,6):=0;
cdrawrate               lawageradix.drawrate%type;
cDepFYCSum              number(20,6):=0;
SingleBonus             number(20,6):=0;
cenddate                larearrelation.enddate%type;
cagentcode              laindexinfo.agentcode%type;
--extrarate               number(20,6):=0;
cRearedGens             integer;
cconnsuccdate           date;
cagentgrade             varchar2(4);
--cstartdate              date;
--tConnSuccDate           date;
cconnmanagerstate       varchar2(1);
Intv1                   integer;
Intv2                   integer;
startdate1              varchar2(8);
enddate1                 varchar2(8);
calstart                varchar2(8);
tEmployLimit            varchar2(6);
calend                  varchar2(8);
calend1                 varchar2(8);
tDay                    varchar2(2);
rate                    number(12,6):=0;
cemploydate             date;
tstartdate              date;
tenddate                date;
tconnsuccdate           date;
cstartdate              date;


begin
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;

---?????????????????????
if tconnmanagerstate='1' or tconnmanagerstate='2' then
return 0;
end if;

---????????????????????
select startdate,nvl(connsuccdate,'') into tstartdate,tconnsuccdate from latree
where agentcode=tagentcode;
  if tconnmanagerstate='4' then
    Intv1:=getmonths(tstartdate,tconnsuccdate);
  end if;
declare
  cursor c_extradep is

  select a.enddate,a.agentcode,a.RearedGens,b.connsuccdate,b.agentgrade,b.connmanagerstate,b.startdate from larearrelation a,latree b
  where a.rearagentcode=tagentcode and a.agentcode=b.agentcode and a.rearedgens<=2 and rearcommflag='1'
        and a.rearlevel='02' and a.state='0' and b.connmanagerstate<>'1' and b.connmanagerstate<>'2';

  begin
    open c_extradep;
      loop
       fetch c_extradep into cenddate,cagentcode,cRearedGens,cconnsuccdate,cagentgrade,cconnmanagerstate,cstartdate;
       exit when c_extradep%notfound;

        if (cconnmanagerstate='0' and tconnmanagerstate='0')
        or (cconnmanagerstate='3' and tconnmanagerstate='3')
        or (cconnmanagerstate='0' and tconnmanagerstate='3')
        or (cconnmanagerstate='3' and tconnmanagerstate='0') or cagentgrade like 'A2%' then
            SingleBonus:=0;
        else
       ---??????????
        select employdate into cemploydate from laagent where agentcode=cAgentCode;
        calstart:=to_char(cemploydate,'yyyymm');
        tEmployLimit:=getEmployLimit('EmployLimit');
        tDay:=to_char(cemploydate,'dd');
        if (tDay>tEmployLimit)
        then

        calend:=to_char(add_months(cemploydate,3),'yyyymm');
        calend1:=to_char(add_months(cemploydate,6),'yyyymm');

        else

         calend:=to_char(add_months(cemploydate,2),'yyyymm');
         calend1:=to_char(add_months(cemploydate,5),'yyyymm');

        end if;
        if (cconnmanagerstate='1' or cconnmanagerstate='2' or cconnmanagerstate='4')then
        Intv2:=getmonths(cemploydate,cconnsuccdate);
        end if;
        SingleBonus:=0;

        if tconnmanagerstate='3' and tagentgrade like 'A3%' then
           rate:=0.5;
           startdate1:=to_char(cemploydate,'yyyymm');
           enddate1:=to_char(cconnsuccdate,'yyyymm');
        elsif cconnmanagerstate='3' and tagentgrade like 'A3%' then
           rate:=0.5;
           startdate1:=to_char(tstartdate,'yyyymm');
           enddate1:=to_char(tconnsuccdate,'yyyymm');

        end if;
  ---??????????
        if tagentgrade like 'A2%' then
           if tstartdate<cconnsuccdate then
               SingleBonus:=0;
           else
              if Intv2>=0 and Intv2<=3 then
                 SingleBonus:=0;
              else
                 rate:=0.5;
                 startdate1:=to_char(cemploydate,'yyyymm');
                 enddate1:=to_char(cconnsuccdate,'yyyymm');
              end if;
            end if;
        end if;

        if (Intv1>=4 and Intv1<=6 and cconnmanagerstate='0')then
           rate:=0.5;
           startdate1:=to_char(tstartdate,'yyyymm');
           enddate1:=to_char(tconnsuccdate,'yyyymm');
        elsif (Intv1>=4 and Intv1<=6 and cconnmanagerstate='4')
               or (Intv2>=4 and Intv2<=6 and cconnmanagerstate='4' and tconnmanagerstate='4')then
           rate:=0.5;
           if cstartdate<tstartdate then
              startdate1:=to_char(cemploydate,'yyyymm');
           else
              startdate1:=to_char(tstartdate,'yyyymm');
           end if;
           if cenddate>tenddate then
              enddate1:=to_char(cconnsuccdate,'yyyymm');
           else
              enddate1:=to_char(tconnsuccdate,'yyyymm');
           end if;
        elsif (Intv2>=4 and Intv2<=6 and tconnmanagerstate='0')
        then
           rate:=0.5;
           startdate1:=to_char(cemploydate,'yyyymm');
           enddate1:=to_char(cconnsuccdate,'yyyymm');
        elsif (Intv2>=0 and Intv2<=3 and tconnmanagerstate='0')then
           rate:=1;
           startdate1:=to_char(cemploydate,'yyyymm');
           enddate1:=to_char(cconnsuccdate,'yyyymm');
        elsif (Intv1>=0 and Intv1<=3 and cconnmanagerstate='0')then
           rate:=1;
           startdate1:=to_char(tstartdate,'yyyymm');
           enddate1:=to_char(tconnsuccdate,'yyyymm');
        elsif (Intv1>=0 and Intv1<=3 and cconnmanagerstate='4')
           or (Intv2>=0 and Intv2<=3 and cconnmanagerstate='4')then
            rate:=1;
             if cstartdate<tstartdate then
              startdate1:=to_char(cemploydate,'yyyymm');
             else
              startdate1:=to_char(tstartdate,'yyyymm');
             end if;
             if cenddate>tenddate then
                enddate1:=to_char(cconnsuccdate,'yyyymm');
             else
              enddate1:=to_char(tconnsuccdate,'yyyymm');
             end if;
         elsif (Intv2>=0 and Intv2<=3 and tconnmanagerstate='0')then
           rate:=1;
           startdate1:=to_char(cemploydate,'yyyymm');
           enddate1:=to_char(cconnsuccdate,'yyyymm');
        end if;
          if  twageno<>to_char(add_months(cconnsuccDate,1),'yyyymm') then

              SingleBonus:=0;
          else

         ---??????????
             select sum(nvl(DepFYCSum,0)) into cDepFYCSum from laindexinfo
             where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
             and indexcalno>=startdate1 and indexcalno<=enddate1;
             if cDepFYCSum<>0 then
             ---???????
             select drawrate into cdrawrate from lawageradix
             where branchtype=tbranchtype and branchtype2=tbranchtype2
             and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
             and reartype=cRearedGens and drawstart=0;
             SingleBonus:=cDepFYCSum*cdrawrate*rate;
             else
             SingleBonus:=0;
             end if;
             end if;
           end if;
              ExtraDepBonus:=ExtraDepBonus+SingleBonus;





       /*if (cagentgrade like 'A3%' and tagentgrade like 'A3%')
       then
           if cconnmanagerstate='1' or cconnmanagerstate='2' or tconnmanagerstate='1' or tconnmanagerstate='2'
           or (cconnmanagerstate='0' and tconnmanagerstate='0')
           then
               SingleBonus:=0;
           elsif (Intv1>4 and Intv1<=7 and cconnmanagerstate='4')  or (Intv2>4 and Intv2<=7 and tconnmanagerstate='4')
           then
              startdate:=calstart;
              enddate:=calend1;
              rate:=0.5;
           elsif (Intv1>=0 and Intv1<=4 and cconnmanagerstate='4')  and  (Intv2>=0 and Intv2<=4 and tconnmanagerstate='4')
              then
              startdate:=calstart;
              enddate:=calend;
              rate:=1;
           end if;
       elsif (cagentgrade like 'A2%' and tagentgrade like 'A3%' and tconnmanagerstate='0') then
              rate:=0.5;
       elsif (cagentgrade like 'A2%' and tagentgrade like 'A3%' and tconnmanagerstate='4') then
             SingleBonus:=0;
       end if;
        ---??????????
             select sum(nvl(DepFYCSum,0)) into cDepFYCSum from laindexinfo
             where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
             and indexcalno>=startdate and indexcalno<=enddate;
             if cDepFYCSum<>0 then
             ---???????
             select drawrate into cdrawrate from lawageradix
             where branchtype=tbranchtype and branchtype2=tbranchtype2
             and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
             and reartype=cRearedGens and drawstart=0;
             SingleBonus:=cDepFYCSum*cdrawrate*rate;
             else
             SingleBonus:=0;
             end if;
              ExtraDepBonus:=ExtraDepBonus+SingleBonus;*/
           /* select employdate into ED from laagent where agentcode=cagentcode;
            if cconnmanagerstate='4' and twageno=to_char(cconnsuccdate,'yyyymm') then
               Intv:=getmonths(ED,cconnsuccdate);
           ---?????????????,??????
            select nvl(startdate,'V'),nvl(ConnSuccDate,'C') into cstartdate,tConnSuccDate
            from latree where agentcode=tagentcode;

            if (tconnmanagerstate='0' and
               (\*1?A??B,A?????B?????B???????????A??B???A??????A2%??*\
                  (Intv>=0 and Intv<=4 and cagentgrade>='A301' and tagentgrade like'A2%'
                   and to_char(cstartdate,'yyyymm')<=to_char(cconnsuccdate,'yyyymm'))
                \*2?A??B,A?????B?????A??B?????A??A2%???B????????*\
                or(Intv>4 and Intv<=7 and cagentgrade>='A301' and tagentgrade like 'A2%'
                   and to_char(cstartdate,'yyyymm')<to_char(cconnsuccdate,'yyyymm'))))
               \*3?C??A,A??B?A B??????B???A??A2%??*\
             or (tconnmanagerstate='4' and Intv>4 and Intv<=7
                 and cagentgrade>='A301' and tagentgrade like 'A2%'
                 and to_char(tConnSuccDate,'yyyymm')<=to_char(cconnsuccdate,'yyyymm'))
              \*4???????????*\
             or (cagentgrade like 'A2%' and Intv>=0 and Intv<=4)
          then
              SingleBonus:=0;
          else

             ---??????????
             select sum(nvl(DepFYCSum,0)) into cDepFYCSum from laindexinfo
             where agentcode=cagentcode and indextype='00'  and branchtype='1' and branchtype2='01'
             and indexcalno<=to_char(cconnsuccdate,'yyyymm');
             if cDepFYCSum<>0 then
             ---???????
             select drawrate into cdrawrate from lawageradix
             where branchtype=tbranchtype and branchtype2=tbranchtype2
             and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
             and reartype=cRearedGens and drawstart=0;
             SingleBonus:=cDepFYCSum*cdrawrate;

             \*---A??B,A?????B?????A?B?????B????????,A??A2%??
                if tconnmanagerstate='0' and Intv>4 and Intv<=7 and cagentgrade>='A301'
                   and to_char(cstartdate,'yyyymm')=to_char(cconnsuccdate,'yyyymm') then
                   SingleBonus:=0.5*SingleBonus;
                end if;*\


             ---???????
            if Intv>=0 and Intv<=4 then
              extrarate:=1;
           ---???????
            else if (Intv>4 and Intv<=7) or tconnmanagerstate='3' then
                    extrarate:=0.5;
                 end if;
            end if;
           else
              SingleBonus:=0;
           end if;
            ExtraDepBonus:=ExtraDepBonus+SingleBonus*extrarate;

         end if;
       end if;    */
      end loop;
   close c_extradep;
  end ;
 /* if enddate1 is not null then
 if twageno=to_char(add_months(to_date(concat(enddate1,'01'),'yyyy-mm-dd'),1),'yyyymm')
  then
                  return(ExtraDepBonus);
               else
                  return 0;
               end if;
  else
    return 0;
  end if;*/
  return(ExtraDepBonus);
  end ExtraDepBonus;

/
