CREATE FUNCTION     "CALTAX" (tAgentCode in varchar2,ReturnType in varchar2,
                           twageno in varchar2,tManageCom in varchar2) return number is
  /*
  ReturnType----'S' ???
            ----'E' ????
            ----'I' ?????
            ----'T' ???
            ----'C' ???
            ----'J' ?????
            ----'K' ????
  */




  cTaxVersion    varchar2(10);

  cSaleRate      number(20,6) := 0;         --?????
  cCityRate      number(20,6) := 0;         --?????
  cEducationRate number(20,6) := 0;         --?????
  cExtraRate     number(20,6) := 0;         --?????
  cExpenseRate   number(20,6) := 0;         --??????
  cDeductRate    number(20,6) := 0;         --??????
  cIncomeTaxRate number(20,6) := 0;         --???????



  cSale          number(20,6) := 0;         --???
  ctax1          number(20,6) := 0;
  cCity          number(20,6) := 0;         --???
  ctax2          number(20,6) := 0;
  cEducation     number(20,6) := 0;         --???
  ctax3          number(20,6) := 0;
  cExtra         number(20,6) := 0;         --???
  ctax4          number(20,6) := 0;
  cExpense       number(20,6) := 0;         --????
  ctax5          number(20,6) := 0;
  cDeduct        number(20,6) := 0;         --????
  ctax6          number(20,6) := 0;
  cIncomeTax     number(20,6) := 0;         --?????
  ctax7          number(20,6) := 0;

  cValue1        number(20,6) := 0;  --??????
  cReleaseMoney  number(20,6) := 0;  --??????
  cQuickCal      number(20,6) := 0;  --?????

  --????
  cWage          number(20,6) := 0;  --????

  cBase1         number(20,6) := 0;  --????????
  cBase2         number(20,6) := 0;  --????????
  cBase3         number(20,6) := 0;  --????????



--??
begin
  --liujw: ???wageno ,if else ?? case

  --?? tIndexCalNo, ????
  --cStr := to_char(TempBegin,'yyyy-mm-dd');
  --cIndexCalNo := substr(cStr,1,4);
  --cIndexCalNo := concat(cIndexCalNo,substr(cStr,6,2));

  --??????????
  select nvl(T27,0),nvl(T17,0),nvl(T18,0),nvl(T19,0),nvl(T20,0),nvl(T21,0),nvl(T22,0),nvl(T23,0)
  into cWage,ctax1,ctax2,ctax3,ctax4,ctax5,ctax6,ctax7 from laindexinfo
  where indexcalno = twageno
  and indextype='01'  and branchtype='1' and branchtype2='01'
  and AgentCode= tAgentCode;

  if cWage <= 0 then
     return 0;
  end if;

  --??tax??
  --select code2 into cTaxVersion From LdCoderela
  --Where code1 = tManageCom
  --and relatype = 'taxareatype';

  cTaxVersion:=substr(tManageCom,1,6);

  --case (ReturnType)
  --?????

  -- if ReturnType = 'S' then
  case
     when ReturnType = 'S' then
          select TaxRate into cSaleRate from latax
          where ManageCom = cTaxVersion and basemin<=cWage and basemax>cwage and TaxType = '01';
          if nvl(cSaleRate,0) = 0 then
             cSale := 0;
          else
              cSale := cWage * cSaleRate;
         end if;
      return cSale;


  --end if;


   --?????
   when ReturnType = 'C' then
      select TaxRate into cCityRate from latax
      where ManageCom = cTaxVersion and trim(TaxType) = '02';
      cCity:=ctax1*cCityRate;
      return cCity;

   --end if;

  --???????
   when ReturnType = 'J' then
     select TaxRate into cEducationRate from latax
     where ManageCom = cTaxVersion and TaxType = '03';
     cEducation:=ctax1*cEducationRate;
     return cEducation;
  --end if;

  --?????
  when ReturnType = 'T' then
     if ctax1 <= 0 then
        return(0);
     end if;
     select sum(nvl(taxrate,0)) into cextrarate from latax
     where TaxType>='04' and TaxType<='13' and managecom=cTaxVersion;
     if ctax1 > 0 then
        cExtra := ctax1* cextrarate;
     end if;
     return cExtra;
  --end if;



  --??????
    when ReturnType = 'E' then
      cBase1 := cWage- ctax1 - ctax2 - ctax3 - ctax4;
      if cBase1 <= 0 then
         return(0);
       end if;
      select TaxRate,nvl(calvalue1,0) into cExpenseRate,cValue1 from latax
      where ManageCom = cTaxVersion and TaxType = '14';
      if cValue1 = 0 then
         cExpense := cBase1 * cExpenseRate;
      else
         cExpense := cValue1;
      end if;
      return(cExpense);
  --end if;


  --??????
   when ReturnType = 'K' then
     cBase2 := cWage- ctax1 - ctax2 - ctax3 - ctax4 - ctax5;
     if cBase2 <= 0 then
        return(0);
     end if;
     select nvl(calvalue1,0),nvl(taxrate,0) into cReleaseMoney,cDeductRate from latax
     where ManageCom = cTaxVersion and taxtype = '15'and cBase2 > BaseMin and cBase2 <= BaseMax;
     if cDeductRate = 0 then
        cDeduct := cReleaseMoney;
     else
        cDeduct := cBase2 * cDeductRate;
     end if;
     return cDeduct;
  --end if;


  --???????
   when ReturnType = 'I' then
     cBase3 := cWage- ctax1 - ctax2 - ctax3 - ctax4 - ctax5- ctax6;
     if cBase3 <= 0 then
        return(0);
     end if;
     select nvl(calvalue2,0), taxrate into cQuickCal,cIncomeTaxRate from latax
     where ManageCom= cTaxVersion and taxtype = '16'
     and cBase3 >= BaseMin and cBase3 < BaseMax;
     cIncomeTax := (cBase3 - cQuickCal)* cIncomeTaxRate;
     return cIncomeTax;
 end case;
end CALTAX;

/
