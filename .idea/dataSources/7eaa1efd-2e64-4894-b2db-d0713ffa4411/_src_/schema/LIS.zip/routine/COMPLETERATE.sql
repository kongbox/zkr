CREATE FUNCTION     "COMPLETERATE" (
       TempBegin date, --????
       TempEnd date,   --????
       tAgentcode LACommision.Agentcode%TYPE, --?????
       tAgentgrade Laplan.Planobject%TYPE  --?????
       ) return number as   --???????

v_Standprem number;--????
v_Planvalue number;--????
v_Month  number;
v_Rate number;
begin

   select months_between(TempEnd,LAST_DAY(TempBegin))+1 into v_Month from dual;

   select nvl(sum(Standprem),0) into v_Standprem from LACommision
   where tmakedate>=TempBegin And tmakedate<=TempEnd and AgentCode=tAgentCode;

   select planvalue/6 into v_Planvalue from laplan where planobject=tAgentGrade
   and PlanPeriod='6' and planperiodunit='1';

   select  v_Standprem/(v_Planvalue*v_Month) into v_Rate from dual;

return v_Rate;
End CompleteRate;

/
