CREATE FUNCTION     "FUNC_APPTRANS" (caseno in char,customerno in char,standbyflag1 in varchar2) return number is
  Result number;

  tcaseno        lloperation.caseno%type;
  tcustomerno    lloperation.customerno%type;
  count1         number;
  count2         number;
  count3         number;

begin
  Result:=0;
  tcaseno:=caseno;
  tcustomerno:=customerno;
  count1:=0;
  count2:=0;
  count3:=0;

  select count(*) into count1 from lloperation where caseno=tcaseno and customerno=tcustomerno and operationtype='D' and operationcode='ZT001';
  if count1>0 then
     select money into Result from apptrans_109 where level1=standbyflag1 and type='ZT001';
  else
     select count(*) into count2 from lloperation where caseno=tcaseno and customerno=tcustomerno and operationtype='D' and operationcode='ZT002';
     if count2>0 then
        select money into Result from apptrans_109 where level1=standbyflag1 and type='ZT002';
     else
        select count(*) into count3 from lloperation where caseno=tcaseno and customerno=tcustomerno and operationtype='D' and operationcode='ZT003';
        if count3>0 then
            select money into Result from apptrans_109 where level1=standbyflag1 and type='ZT003';
        else
            Result:=0;
        end if;
     end if;
  end if;

  return(Result);
end func_apptrans;

/
