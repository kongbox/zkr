CREATE FUNCTION     "FOUTHBUSIBONUS" (tareatype in varchar2,twagecode in varchar2,twageno in varchar2,tagentgroup in varchar2,tenddate in date,tagentcode in varchar2) return number is
  Result number(12,4):=0 ;

  cRenewSum4 number(12,4):=0 ;--????????????
  cPRenewSum4 number(12,4):=0;--???4?????
  cRatio4 number(12,4):=0 ;

  cPassRate4 number(12,4):=0;--??????????

  cPassRadix4 number(12,4):=0;--???????

  cBusSum4 number(12,4):=0;--????????
  cDifficulty number(12,4):=0 ;--????
  cMonth number(12,4):=0;--????
  cEmployDate date;
begin
  --????
  select employdate into cEmployDate from laagent where agentcode=tagentcode;
  cMonth := months_between(tenddate+1,cEmployDate);

  select T53 into cPassRate4 from laindexinfo where
  agentcode=tagentcode and indexcalno=twageno and indextype='01' and branchtype='4' and branchtype2='01';

 --?????
   select nvl(sum(T54),0) into cRenewSum4 from laindexinfo
    where  agentgroup=tagentgroup and indexcalno=twageno
    and indextype='01' and branchtype='4' and branchtype2='01';

     select nvl(sum(T71),0) into cPRenewSum4 from laindexinfo
    where  agentgroup=tagentgroup and indexcalno=twageno
    and indextype='01' and branchtype='4' and branchtype2='01';

  --????

   select nvl(sum(drawreward),1) into cRatio4 from lawageparam2 where wagecode =twagecode and paracode='WP0072'
  and areatype=tareatype;

  --????
  select avg(difficulty) into cDifficulty from latree where agentgroup=tagentgroup and agentseries<1 and branchtype='4';

  if cDifficulty >=1.5 then
     cDifficulty:=0;--??
  else
     cDifficulty:=1;
  end if;

  --?????
  if  cMonth<=2 then

    cPassRadix4:=1;
  else

    select nvl(sum(drawreward),1) into cPassRadix4 from lawageparam1 where wagecode=twagecode and paracode='WP0071'
    and areatype=tareatype and lowlimit<=cPassRate4 and highlimit>cPassRate4 and standard=cDifficulty;
  end if;


  cBusSum4:=(cRenewSum4+cPRenewSum4)*cRatio4*cPassRadix4;

  Result := cBusSum4;
  return(Result);
end FouthBusiBonus;

/
