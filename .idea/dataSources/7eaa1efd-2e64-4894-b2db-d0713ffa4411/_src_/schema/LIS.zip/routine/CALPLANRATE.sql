CREATE FUNCTION     "CALPLANRATE" (
       tAgentCode laagent.agentcode%Type,
       tAgentGroup latree.agentgroup%Type,
       tAgentKind latree.agentkind%Type,
       tBranchType lacommision.branchtype%Type,
       tWageNo lacommision.wageno%Type
)
 return number is
  Result number;
  ---?????????????

  startdate           Varchar2(20);
  enddate             Varchar2(20);
  tMon                Number;
  tManaMon            Number;
  tDate               Date;
  standmoney          Number;
  standplan           Number;
  tRate               Number;
  tResult             Number;
  tQua                Number;
  tQua1                Number;
  wagemonth Number;

Begin

     wagemonth:=substr(tWageNo,5,2);
     if(wagemonth=3 or wagemonth=6 or wagemonth=9 or wagemonth=12 ) then
         --????
         --select nvl(MarkEnd,0) into standplan from LAAgentPromRadix2 where agentgrade=tAgentKind and DestAgentGrade=tAgentKind and branchtype2='01' and branchtype=tBranchType;

         --????
         select max(AStartDate) into tDate from labranchgroupb where agentgroup =tAgentGroup and edortype='07' and branchmanager=tAgentCode;
         --??????
         select months_between(tDate,to_date(tWageNo,'YYYYMMDD')) into tMon from dual;
         --??????????
         tManaMon:=12-wagemonth+tMon;
         tQua:=ceil(tManaMon/3);
         tQua1:=ceil(wagemonth/3);
         if(tMon<=3) then
                startdate:=to_char(add_months(to_date(tWageNo,'yyyymm'),-tMon+1),'yyyymm');
                enddate:=tWageNo;
         elsif(tMon>3 and tMon<=6) then
                startdate:=to_char(add_months(to_date(tWageNo,'yyyymm'),-tMon+1),'yyyymm');
                enddate:=tWageNo;
         elsif(tMon>6 and tMon<=9) then
                startdate:=to_char(add_months(to_date(tWageNo,'yyyymm'),-tMon+1),'yyyymm');
                enddate:=tWageNo;
         else
                startdate:=to_char(add_months(to_date(tWageNo,'yyyymm'),-tMon+1),'yyyymm');
                enddate:=tWageNo;
         end if;

         ---??????????????
         select nvl(sum(standprem),0) into standmoney from lacommision where agentgroup=tAgentGroup and wageno>=startdate and wageno<=enddate;

        -- select nvl(sum(planvalue),0) into standplan from laplan where  PlanObject=tAgentGroup  And planperiod<=enddate And planperiod>=startdate;
         select nvl(MarkEnd,0) into standplan from LAAgentPromRadix2 where agentgrade=tAgentKind and DestAgentGrade=tAgentKind and branchtype2='01' and branchtype=tBranchType;

         select drawrate into tRate from lawageradix1 where wagecode='QPRate' and cond1=tQua and cond2=tQua1;

         tResult:=((standmoney/standplan)/tRate)*100;

         select drawrate into Result from lawageradix1  where wagecode='QuRate' and tResult>=cond1 and tResult<cond2 and branchtype=tBranchType;

     else
         Result:=0;

     end if;

  return(Result);
end calplanrate;

/
