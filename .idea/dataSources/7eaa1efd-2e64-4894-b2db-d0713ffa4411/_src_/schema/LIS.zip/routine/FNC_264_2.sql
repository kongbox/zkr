CREATE FUNCTION     "FNC_264_2" (n_appFlag number,n_caseNo number,d_injuryDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
begin

Result:=0;                               --?Result??

-------------------------------------------------------------------------------------------------------------
if n_appFlag=1 then   --????????????????????????5???????????
   select count(1) into result from LLCaseReceipt where CaseNo=n_CaseNo and  d_lcgetStartDate<=startDate  and startDate<=(d_injuryDate+4);
end if;
----------------------------------------------------------------------------------------------------------------

if n_appFlag<>1 then   --??????

  --?????????????????????????????
  select 1 into result from dual;

end if;

if Result>1 then
    select 1 into result from dual;
end if;


  return(Result);

end fnc_264_2;

/
