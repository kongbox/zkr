CREATE function     getspec(prtno     in varchar2,
                                   grpcontno in varchar2)
return varchar2 as
res varchar2(5000);
begin
  select max(ltrim(sys_connect_by_path(speccontent,'|'),'|'))

    into res
    from (select speccontent, rownum rn
            from lccgrpspec
           where proposalgrpcontno = prtno
             and grpcontno = grpcontno)
   start with rn = 1
  connect by rn = rownum;

  if res is null then
    res := '-';
  end if;
  return(res);
  exception
     when others then return('该字段过长，无法显示，请到"综合查询-保单查询"下查询特别约定');
end;

/
