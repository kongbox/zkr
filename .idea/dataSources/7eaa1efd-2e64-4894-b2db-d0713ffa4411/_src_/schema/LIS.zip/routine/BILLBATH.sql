CREATE FUNCTION     "BILLBATH" (prttype varchar2) return boolean is
  Result boolean;
begin
  DECLARE

  totherno print.otherno%type;
  tmanagecom print.managecom%type;


  print_rec  print%rowtype;

  CURSOR c_print IS

    select grpcontno as otherno,managecom from lcgrpcont where grpcontno not in(
'000000005846088',
'000000006605088',
'000000002392088',
'000000002723088',
'000000002937088',
'000000003151088',
'000000026326088',
'000000033652088',
'000000099830088',
'000000031492088',
'000000088408088',
'000000071810088',
'000000100910088',
'000000081393088',
'000000097349088',
'000000097884088',
'000000100472088',
'000000111573088',
'000000105220088',
'000000062003088',
'000000062110088',
'000000015974088',
'000000018348088',
'000000018455088',
'000000032144088',
'000000042924088',
'000000043031088',
'000000043138088',
'000000052838088',
'000000052945088',
'000000053052088',
'000000053159088',
'000000053266088',
'000000053373088',
'000000053480088',
'000000053587088',
'000000053694088',
'000000053704088',
'000000053811088',
'000000053918088',
'000000054453088',
'000000054560088',
'000000054667088',
'000000075896088',
'000000075906088',
'000000084633088',
'000000070078088',
'000000072987088',
'000000084195088',
'000000100803088',
'000000104675088',
'000000066089088',
'000000069543088',
'000000072345088') and makedate<'2009-11-10' and appflag='1' and not exists (select * from print where otherno=grpcontno and prttype='65')

   ;
  BEGIN
   execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';
      for c_print_result in c_print LOOP

      totherno:=c_print_result.otherno;
      tmanagecom:=c_print_result.managecom;


      EXIT WHEN c_print%NOTFOUND;
      print_rec.otherno:=totherno;
      print_rec.managecom :=tmanagecom;
      print_rec.prttype :='65';
      print_rec.title :='??????';
      print_rec.prttimes :=1;
      print_rec.operator :='001';
      print_rec.makedate :='2009-11-24';
      print_rec.clientip:='127.0.0.1';
      print_rec.serverip:='10.9.41.194';
      print_rec.strpath:='D:/htlis/ui/pdffiles';
      print_rec.filename:='pdffiles';

      insert into print values print_rec;
         commit;



    END LOOP;

   end ;
  Result:=true;
  return(Result);
end billbath;

/
