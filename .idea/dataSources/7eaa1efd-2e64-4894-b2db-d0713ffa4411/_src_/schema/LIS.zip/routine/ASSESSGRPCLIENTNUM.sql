CREATE FUNCTION     "ASSESSGRPCLIENTNUM" (
       tAgentCode laagent.agentcode%Type,
       tBranchType laagent.branchtype%Type,
       tTempBegin laagent.employdate%Type,
       tTempEnd laagent.employdate%Type
)
return number is
  Result Integer;
  tNo               Integer;  --????????
  tempNo            Char(24); -- ???
  tMoney            lacommision.standprem%Type;
  tStart            varchar2(6);
  tEnd              varchar2(6);
Begin
    tNo:= 0;
    tMoney:= 0;
    tStart:=to_char(tTempBegin,'yyyymm');
    tEnd:=to_char(tTempEnd,'yyyymm');
     Declare Cursor cAppntNo Is
         Select Distinct AppntNo From lacommision Where wageno>=tStart And wageno<=tEnd And AgentCode=tAgentCode And branchtype=tBranchType;
     Begin
       Open cAppntNo;
       Loop
         Fetch cAppntNo Into tempNo;
         EXIT WHEN cAppntNo%NOTFOUND;
         Select nvl(Sum(standprem),0) Into tMoney From lacommision
                Where wageno>=tStart And wageno<=tEnd And branchtype=tBranchType And AppntNo=tempNo;
         If (tMoney>=10000) Then
            tNo:= tNo + 1;
         End If;
       End Loop;
       Close cAppntNo;
     End;
     Result:=tNo;
    Return(Result);
end AssessGrpClientNum;

/
