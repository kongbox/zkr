CREATE FUNCTION     "ASSESSMARK" (
       tAgentcode LAIndexInfo.Agentcode%TYPE, --?????
       tIndexCalNo integer   --????
       ) return number as   --???????
v_Mark number;
v_Rate number;
v_ReRate number;
begin

select nvl(T26,0) into v_Rate from LAIndexInfo
where IndexType='04' and IndexCalNo=IndexCalNo and AgentCode=tAgentcode;
if v_Rate>1 then
v_ReRate:=1;
else
v_ReRate:=v_Rate;
end if;

select ((select nvl(sum(AssessMark),0)*0.25 from LAAssessMark where Assessym=tIndexCalNo and (AssessMarkType='03' or AssessMarkType='04') and AgentCode=tAgentcode)
+ (select nvl(sum(AssessMark),0)*0.15 from LAAssessMark where Assessym=tIndexCalNo and AssessMarkType='05' and AgentCode=tAgentcode)
+ (select nvl(sum(AssessMark),0)*0.05 from LAAssessMark where Assessym=tIndexCalNo and AssessMarkType='06' and AgentCode=tAgentcode)) into v_Mark
from ldsysvar where sysvar = 'onerow' ;

return v_Mark+v_ReRate*30;

End AssessMark;

/
