CREATE FUNCTION     "ADDHELP" (tagentcode in varchar2,twageno in varchar2,tareatype in varchar2,
                                   twagecode in varchar2,tbranchtype lawageradix.branchtype%type,
                                   tbranchtype2 in varchar2,tagentgrade in varchar2,tAgentState in varchar2)
                                   return number is
  tRwd                        number(20,6):=0;

  cindueFormStartDate         date;
  cindueFormEndDate           date;
  cagentcode                  varchar2(20);
  cagentgrade                 varchar2(4);
  cagentcount                 integer;
  num                         integer;

  ---???????
begin

  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;


  --????????
 /* select count(distinct a.agentcode) into tagentcount from laindexinfo a
  where exists (select agentcode from latree
                where IntroAgency=tagentcode and InitGrade='A101' and agentcode=a.agentcode)
  and a.ContiuePension>0 and a.indexcalno=twageno
  and branchtype='1' and branchtype2='01';*/

  cagentcount:=0;
  select startdate into cindueFormStartDate from lastatsegment where stattype='5' and yearmonth=to_number(twageno)-6;
  select enddate into cindueFormEndDate from lastatsegment where stattype='5' and yearmonth=to_number(twageno)-1;
   declare
  cursor c_addHelp is

  select a.agentcode,a.agentgrade from latree a,laagent b
  where a.introagency=tagentcode and a.agentcode=b.agentcode and a.initgrade='A101'
  and b.indueformdate is not null and b.indueFormdate>=cindueFormStartDate and b.indueFormDate<=cindueFormEndDate
  and b.agentstate<'03'  ;

  begin
    open c_addHelp;
      loop
       fetch c_addHelp into cagentcode,cagentgrade;
       exit when c_addHelp%notfound;
       num:=0;
       if (ArchieveRwd(cagentcode,cagentgrade,twageno ,tareatype ,'W00005',tbranchtype ,tbranchtype2 ,tAgentState)>0)
       then
        num:=1;
       else
        num:=0;
       end if;
     cagentcount:=num+cagentcount;
     end loop;
   close c_addHelp;
  end ;

  if (cagentcount=0)then
     return 0;
  end if;


  --??????????
    select nvl(rewardmoney,0) into tRwd from lawageradix
    where agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
    and branchtype=tbranchtype and branchtype2=tbranchtype2;

  tRwd:=tRwd*cagentcount;
  return(tRwd);
end AddHelp;

/
