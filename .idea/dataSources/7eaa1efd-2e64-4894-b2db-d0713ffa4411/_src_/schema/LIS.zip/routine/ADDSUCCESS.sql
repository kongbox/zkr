CREATE FUNCTION     "ADDSUCCESS" (tagentcode in varchar2, twageno in varchar2,tareatype in varchar2,
                                      twagecode in varchar2,tbranchtype lawageradix.branchtype%type,
                                      tbranchtype2 in varchar2,
                                      tagentgrade in varchar2,tAgentState in varchar2
                                      )return number is

  cRwd                  number(20,6):=0;
  cRwdTotal             number(20,6):=0;
  cindueFormStartDate   date;
  cindueFormEndDate     date;
  cagentcount           integer:=0;
  cagentcode           varchar2(10);
  cagentgrade          varchar2(4);

  ---???????
begin

  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;

  --????????
/* select count(distinct a.agentcode) into cagentcount from laindexinfo a
 where exists (select agentcode from latree
       where IntroAgency=tagentcode and InitGrade='A101' and agentcode=a.agentcode)
 and a.FirstPension>0
 and a.indexcalno=twageno and a.indextype='01' and branchtype='1' and branchtype2='01';
  */
  select startdate into cindueFormStartDate from lastatsegment where stattype='5' and yearmonth=to_number(twageno)-3;
  select enddate into cindueFormEndDate from lastatsegment where stattype='5' and yearmonth=to_number(twageno);
   declare
  cursor c_addSucc is
 ---?????????????????????????????
  select a.agentcode,a.agentgrade from latree a,laagent b
  where a.introagency=tagentcode and a.agentcode=b.agentcode and a.initgrade='A101'
  and b.indueformdate is not null and b.indueFormdate>=cindueFormStartDate and b.indueFormDate<=cindueFormEndDate
  and b.agentstate<'03'  ;

  begin
    open c_addSucc;
      loop
       fetch c_addSucc into cagentgrade,cagentgrade;
       exit when c_addSucc%notfound;
       if (ToFormalRwd(cagentcode,cagentgrade,twageno ,tareatype ,tbranchtype ,tbranchtype2,'W00004','2')>0)
       then cagentcount:=cagentcount+1;
       end if;

     end loop;
   close c_addSucc;
  end ;




  if (cagentcount=0) then
      return 0;
  end if;
    select rewardmoney into cRwd from lawageradix
    where agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
    and branchtype=tbranchtype and branchtype2=tbranchtype2;

  cRwdTotal:=cRwd * cagentcount;
  return(cRwdTotal);
end AddSuccess;

/
