CREATE FUNCTION     "GETCHANGEGETRATE610RATE" (GetRate in number,level in varchar2)
return number is v_tR number;
begin

	v_tR :=0;
	if level = '1' then
		v_tR := 0.98;
	end if;
	if level = '2' then
		v_tR := 0.95;
	end if;
	if level = '3' then
		v_tR := 1;
	end if;
	if level = '4' then
		v_tR := 0.93;
	end if;
	if level = '5' then
		v_tR := 0.80;
	end if;
	if level = '6' then
		v_tR := 0.80;
	end if;
	if GetRate = 0.7 or GetRate = 0.9 then
		v_tR := 1;
	else
	   	v_tR :=v_tR*GetRate/0.9;
	end if;

	return(v_tR);
end;

/
