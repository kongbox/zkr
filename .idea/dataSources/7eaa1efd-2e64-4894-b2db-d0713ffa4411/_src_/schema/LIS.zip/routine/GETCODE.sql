CREATE FUNCTION     "GETCODE" (tCodetype in varchar2, tCode in varchar2)
 return varchar2 is
  Result varchar2(20);
begin
  Result := '';
  select platformcode into result from ldcode where code=tCode and codetype=tCodetype;
  return(Result);
end getCode;

/
