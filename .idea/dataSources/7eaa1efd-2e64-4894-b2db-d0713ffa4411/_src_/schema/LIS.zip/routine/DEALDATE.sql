CREATE FUNCTION     "DEALDATE" (TempDate in date) return date is

   Result date;

begin
  ---??????????
Result:=Add_months(TempDate,-2);


  return(Result);
end DealDate;

/
