CREATE FUNCTION     "DESTAGENTGRADE" (tagentgrade in varchar2,tassesstype in varchar2) return varchar2 is
----------------????????????-------------------------
  Result varchar2(4);
begin
if tassesstype='01' then
  if tagentgrade='G131' then
     Result:='G123';
  elsif tagentgrade='G132' then
     Result:='G131';
  elsif tagentgrade='G133' then
     Result:='G132';
  elsif tagentgrade='G141' then
     Result:='G133';
  elsif tagentgrade='G142' then
     Result:='G141';
  elsif tagentgrade='G143' then
     Result:='G142';
  elsif tagentgrade='G123' then
     Result:='G122';
  elsif tagentgrade='G201' or tagentgrade='G301' then
     Result:='G143';
  elsif tagentgrade='G202' then
     Result:='G201';
  end if;
else
  if tassesstype='02' and tagentgrade='G202' then
     Result:='G203';
  end if;
end if;

  return(Result);
end DestAgentGrade;

/
