CREATE FUNCTION     "CALACTUPREM" (tPolNo in varchar2) return number is
  Result number(12,2);
   tPayMoney  number(12,2);
begin
    select nvl(sum(sumActuPayMoney),0) into tPayMoney from ljapayperson
    where paytype='ZC' and polno=tPolNo;

     select nvl(sum(getmoney),0) into Result
      from ljagetendorse
      where polno=tPolNo and feefinatype='TF';
 Result := tPayMoney - Result;
  return(Result);
end calactuprem;

/
