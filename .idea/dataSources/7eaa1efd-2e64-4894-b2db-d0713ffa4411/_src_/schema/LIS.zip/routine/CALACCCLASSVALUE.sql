CREATE FUNCTION "CALACCCLASSVALUE" (tGrpContNo in varchar2 ,tPolNo in varchar2, tPayPlanCode in varchar2,tInsuAccNo in varchar2,tPriceDate in Date) return Number is

   tAccountValue number:=0 ;
   tSellPrice number(12,8):=0;
   tBuyPrice number(12,8):=0;
   tRiskCode LCPol.RiskCode%Type;
   tUnitCount Lcinsureaccclass.Unitcount%Type;
   tActuPriceDate date; --?????
begin

   if (tGrpContNo is null or tGrpContNo ='' or tGrpContNo = 'null') and (tPolNo is null or tPolNo ='' or tPolNo = 'null') then

   return 0;

   end if;

   if tGrpContNo is null or tGrpContNo ='' or tGrpContNo = 'null' then --??????????,??????????????

   select riskcode into tRiskCode from lcpol where PolNo=tPolNo ;

    tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);

   tSellPrice :=getprice(tRiskCode,tInsuAccNo ,tActuPriceDate,'1');

   if tSellPrice is null then

      tSellPrice :=0;

   end if;

   if (tPayPlanCode is null or tPayPlanCode = 'null' or tPayPlanCode = '')
   then
      select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where PolNo=tPolNo and InsuAccNo=tInsuAccNo;
   else
      select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where PolNo=tPolNo and PayPlanCode = tPayPlanCode and InsuAccNo=tInsuAccNo;
   end if;
   tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);



   else if tPolNo is null or tPolNo ='' or tPolNo = 'null' then --????,??????????,??????????????

   select riskcode into tRiskCode from lcpol where GrpContNo=tGrpContNo and rownum=1;

   tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);

   tSellPrice :=getprice(tRiskCode,tInsuAccNo ,tActuPriceDate,'1');

   if tSellPrice is null then

      tSellPrice :=0;

   end if;

   if (tPayPlanCode is null or tPayPlanCode = 'null' or tPayPlanCode = '')
   then
      select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where GrpContNo=tGrpContNo and InsuAccNo=tInsuAccNo and exists (select 'X' from lcpol where polno=lcinsureacctrace.polno and polstate='1');
   else
      select nvl(sum(round(UnitCount*tSellPrice,2)),0) into tUnitCount from lcinsureacctrace where GrpContNo=tGrpContNo and PayPlanCode = tPayPlanCode and InsuAccNo=tInsuAccNo and exists (select 'X' from lcpol where polno=lcinsureacctrace.polno and polstate='1');
   end if;



   end if;

  end if;
   tAccountValue:=tUnitCount;

  return(tAccountValue);

END;

/
