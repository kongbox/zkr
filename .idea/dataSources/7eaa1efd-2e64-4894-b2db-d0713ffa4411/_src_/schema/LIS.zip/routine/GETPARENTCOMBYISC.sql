CREATE FUNCTION     "GETPARENTCOMBYISC" (tComCodeISC in varchar2)
return varchar2 as
tParentComCodeISC varchar2(10);
begin
select max(ParentComCodeISC) into tParentComCodeISC from LFComISC where trim(ComCodeISC)= trim(tComCodeISC);
return(tParentComCodeISC);
end getParentComByISC;

/
