CREATE FUNCTION     "GETEMPSTATE" (cEmployDate in date,cIndexCalno in varchar2) return integer is
  Result integer;
begin
  if to_char(cEmployDate,'yyyymm') <> cIndexCalNo then
    Result := 1;
  else
    if to_number(to_char(cEmployDate,'dd')) > 10 then
      Result := -1;
    else
      Result := 1;
    end if;
   end if;
  return(Result);
end getEmpState;

/
