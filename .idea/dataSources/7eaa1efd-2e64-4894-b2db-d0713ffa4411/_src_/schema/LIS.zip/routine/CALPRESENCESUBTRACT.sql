CREATE FUNCTION     "CALPRESENCESUBTRACT" (tAgentCode in varchar2, TempBegin  in date,TempEnd in date) return number is
  tCount1     integer := 0;
  tCount2     integer := 0;
  tCount3     integer := 0;
  tCount4     integer := 0;
  tSubMoney1  number(12,2) := 0;
  tSubMoney2  number(12,2) := 0;
  tSubMoney3  number(12,2) := 0;
  tSubMoney4  number(12,2) := 0;

  tMoney      number(12,2) := 0;
  tTimes      integer := 0;

  Result      number := 0;
----??????-----
begin
--'01':????'02':????'03':????'04':????
  select nvl(sum(Times),0) into tCount1 from lapresence
  where trim(AClass) = '01'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and trim(AgentCode) = trim(tAgentCode)
        ;

  select nvl(sum(Times),0) into tCount2 from lapresence
  where trim(AClass) = '02'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and trim(AgentCode) = trim(tAgentCode)
        ;

  select nvl(sum(Times),0) into tCount3 from lapresence
  where trim(AClass) = '03'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and trim(AgentCode) = trim(tAgentCode)
        ;

  select nvl(sum(Times),0) into tCount4 from lapresence
  where trim(AClass) = '04'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and trim(AgentCode) = trim(tAgentCode)
        ;


  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '01';
  tSubMoney1 := tCount1 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '02';
  tSubMoney2 := tCount2 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '03';
  tSubMoney3 := tCount3 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '04';
  tSubMoney4 := tCount4 * tMoney / tTimes;

  Result := nvl(tSubMoney1,0) + nvl(tSubMoney2,0) + nvl(tSubMoney3,0) + nvl(tSubMoney4,0);
  return(Result);
end CalPresenceSubtract;

/
