CREATE FUNCTION     "CALYEARMONEY" (
       tAgentGrade lawageradix1.agentgrade%Type,
       tBranchType lawageradix1.branchtype%Type,
       tAgentCode laagent.agentcode%Type,
       tWageNo lacommision.wageno%Type,
       tAgentGroup laagent.agentgroup%Type,
       flag Number
       ----0?????1???????????2???? ,3????
       ----????????????(agentkind,assessway)
) return number Is
  Result number:=0;
  ----?????????????????????,3????
  wagemonth Number;
  tfinishprem Number;
  tdepfyc Number;
  rate Number;
  yearnum Number;
  tEndDate date;
  --tBranchAttr labranchgroup.branchattr%Type;


----??????????????????????????


Begin
  wagemonth:=substr(tWageNo,5,2);
  If(flag=0) Then ----???
     Result:=0;
  Elsif(flag=1) Then ----?????????
       Select nvl(sum(FYC),0)  Into tdepfyc From lacommision
              Where wageno=tWageNo And branchtype=tBranchType And commdire=1
              And agentgroup=tAgentGroup ;
         Result:=tdepfyc*0.05;

  Elsif(flag=2) then  ----???
        If(wagemonth='03' Or wagemonth='09' Or wagemonth='06' Or wagemonth='12') Then
              Select nvl(sum(fyc),0)*0.7 Into tdepfyc From lacommision
                     Where wageno>=to_char(add_months(to_date(tWageNo,'yyyymm'),-2),'yyyymm')
                     And wageno<=tWageNo And branchtype=tBranchType And commdire=1
                   /*  And BranchAttr Like /*tBranchAttr*/
                     /*(Select trim(branchattr) From labranchgroup Where agentgroup =tAgentGroup)||'%' */
                    --???????
                     And agentgroup=tAgentGroup
                     And agentcode<>tagentcode;


              select T74 into rate from laindexinfo Where
                    indexcalno=tWageNo And IndexType='01' and
                    agentcode=tAgentCode And branchtype=tBranchType
                    And BranchType2='01' ;

              Result:=tdepfyc*rate*0.05;
        Else
              Result:=0;
        End If;
  else
        select nvl(sum(fyc),0) into tdepfyc  from lacommision where branchtype='2' and agentcode=tAgentCode and wageno=tWageNo and commdire='1';
        Select nvl((Select drawrate From lawageradix1
                    Where branchtype=tbranchtype And wagecode='MnRate'),1) Into rate From ldsysvar where sysvar='onerow';

--????????
        Result:=tdepfyc*rate;
        if(tAgentGrade='T01') then
             rate:=1;
        else
             select enddate into tEndDate from lastatsegment  where stattype='1' and yearmonth=tWageNo;
             select floor(months_between(InDueFormDate,tEndDate)/12)  into yearnum  from laagent where agentcode=tAgentCode;
             Select nvl((Select drawrate From lawageradix1
                      Where branchtype=tbranchtype And wagecode='YDraw'
                      And yearnum>=cond1 And yearnum<cond2),1) Into rate From ldsysvar where sysvar='onerow';

        end if;
        Result:=Result*rate;

  End If;


  return(Result);

end CALYEARMONEY;

/
