CREATE FUNCTION     "CALDEPBACKPREM" (tagentcode in varchar2, tagentgrade in varchar2,
                                          twagenobegin in varchar2,twagenoend in varchar2,
                                          tdestagentgrade in varchar2,tareatype in varchar2,
                                          tassesstype in varchar2) return number is
--------------------------------------???????-----------------------------------------------------------
  BackPremSum    number(20,6):=0 ;
  singleprem     number(20,6):=0 ;
  cdirteamfycsum number(20,6):=0 ;
  cagentcode     varchar2(10);
  cstartdate     date;
  startmonth     varchar2(6);
  num            integer;
begin
  ---??????????
  if tagentgrade<'A301' then
     return 0;
  end if;

  Declare
  cursor c_backprem is
    ---?????????????
    select a.agentcode,a.startdate from larearrelation a where
    exists (select agentcode from latree where agentcode=a.agentcode and initgrade<>'A201' and initgrade<>'A301')
    and trim(a.rearagentcode)=tagentcode and a.rearlevel='02'
    and a.rearedgens=1 and a.rearflag='1';

    begin
      open c_backprem;
        loop
          fetch c_backprem into cagentcode,cstartdate;
          exit when c_backprem%notfound;

          singleprem:=0 ;
          cdirteamfycsum:=0;
          startmonth:=to_char(add_months(cstartdate,-1),'yyyymm');
          ---???????????????????????
          select count(*) into num from laassessaccessory
          where branchtype='1' and branchtype2='01'
          and assesstype='00' and indexcalno=startmonth
          and agentcode=tagentcode;

          if num=0 then
             if twagenobegin<=startmonth then
                  select nvl(sum(T43),0) into singleprem from laindexinfo
                  where agentcode=cagentcode and indextype='00'
                  and indexcalno>=startmonth and indexcalno<=twagenoend;
                  cdirteamfycsum:=1;
             elsif twagenobegin>startmonth then
                   select nvl(sum(T43),0) into singleprem from laindexinfo
                   where agentcode=cagentcode and indextype='00'
                   and indexcalno>=twagenobegin and indexcalno<=twagenoend;
                 ---????
                   select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                   where agentgrade=tagentgrade and assesscode =tassesstype
                   and areatype =tareatype and destagentGrade =tdestagentgrade;
             end if;
         else
             if num>0 then
                select nvl(sum(T43),0) into singleprem from laindexinfo
                where agentcode=cagentcode and indextype='00'
                and indexcalno>=twagenobegin and indexcalno<=twagenoend;
                if twagenobegin=startmonth then
                   ---?????????
                   cdirteamfycsum:=1;
                elsif twagenobegin>startmonth then
                   ---?????????
                   select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                   where agentgrade=tagentgrade and assesscode =tassesstype
                   and areatype =tareatype and destagentGrade =tdestagentgrade;
                end if;
             end if;
        end if;
          BackPremSum:=BackPremSum+singleprem*cdirteamfycsum;
        end loop;
      close c_backprem;
   end;
 return(BackPremSum);
end CalDepBackPrem;

/
