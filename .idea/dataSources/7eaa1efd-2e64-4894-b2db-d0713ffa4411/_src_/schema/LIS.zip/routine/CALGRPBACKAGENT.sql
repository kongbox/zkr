CREATE FUNCTION     "CALGRPBACKAGENT" (tagentcode in varchar2, tagentgrade in varchar2,
                                          twagenobegin in varchar2,twagenoend in varchar2,tbranchcode in varchar2,
                                          tdestagentgrade in varchar2,tareatype in varchar2,
                                          tassesstype in varchar2) return number is
--------------------------------------??????-----------------------------------------------------------


  cdirmngcount   number (10,2):=0;
  cagentcode     varchar2(10);
  cstartdate     date;
  agentno        integer;
  backagent      integer;
  calbegin       varchar2(6);
  calbetween     varchar2(6);
  calend         varchar2(6);
  cagentgroup    varchar2(20);
begin
  ---????????
  if tagentgrade< 'A201' then
     return 0;
  end if;

  backagent:=0;
  Declare
  cursor c_backagent is
    ---?????????????  --liujw:??????????
    select a.agentcode,a.startdate,a.agentgroup from larearrelation a where
    exists (select agentcode from latree where agentcode=a.agentcode and initgrade<>'A201' and initgrade<>'A301')
    and a.rearagentcode=tagentcode and a.rearlevel='01'
    and a.rearedgens=1 and a.rearflag='1' and a.state='0';

    begin
      open c_backagent;
        loop
          fetch c_backagent into cagentcode,cstartdate,cagentgroup;
          exit when c_backagent%notfound;
          calbegin:=to_char(cstartdate,'yyyymm');
          calbetween:=to_char(add_months(cstartdate,2),'yyyymm');
          calend:=to_char(add_months(cstartdate,5),'yyyymm');

          agentno:=0;
          cdirmngcount:=0;
          ---????????????????
          ---?????
           if (calbegin<=twagenobegin and calbetween>=twagenoend)
            or (calbegin<=twagenobegin and calbetween<=twagenoend)
            or (calbegin>twagenobegin and calbegin<=twagenoend and twagenoend<calbetween)then
             ---????????? --liujw:????tBranchCode??????????????????????????
              select count(distinct AgentCode) into agentno from LATree
              where  Agentgroup= cagentgroup  and Agentcode<>cAgentcode and state = '0';
              ---??????????
              cdirmngcount:=1;
          else
            if (calbetween<=twagenobegin and calend>=twagenoend)
            or (calbetween>=twagenobegin and calend>=twagenoend)
            or (twagenobegin>calbegin and twagenobegin<calbetween and twagenoend>calend)then
               ---?????????
               select count(AgentCode) into agentno from LATree
               where  Agentgroup= tBranchCode  and Agentcode<>cAgentcode and state = '0';
               ---??????????
               select nvl(dirmngcount,0) into cdirmngcount  from laagentpromradix
               where agentgrade=tagentgrade and assesscode =tassesstype
               and areatype =tareatype and destagentGrade =tdestagentgrade;
             end if;
          end if;


          backagent:=backagent+agentno*cdirmngcount;
        end loop;
      close c_backagent;
   end;
 return(backagent);
end CalGrpBackAgent;

/
