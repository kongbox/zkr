CREATE FUNCTION     "CHGINSUYEAR801" (PayIntv number , InsuYear number )
return number
is
tR number;
begin
	if PayIntv = 0 then
		tR := 1;
	else
		tR := InsuYear;
	end if;

	return(tR);
end;

/
