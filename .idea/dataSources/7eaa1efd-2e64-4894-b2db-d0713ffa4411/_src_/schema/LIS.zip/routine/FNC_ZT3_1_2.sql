CREATE FUNCTION     "FNC_ZT3_1_2" (payendyear in number) return varchar2
is
tR number;
begin

  tR := 1;

		if payendyear >= 20 then
			tR := 0.15;
		end if;
		if payendyear >= 10 and payendyear < 20 then
			tR := 0.2;
		end if;
		if payendyear < 10 then
			tR := 0.25;
		end if;
	return(tR);
end;

/
