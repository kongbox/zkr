CREATE FUNCTION     "ADVANCESTANDPREM" (
       tagentcode in VARCHAR2,
       tagentgroup in VARCHAR2,
       tempbegin in date,
       tempend in date,
       tgens in INTEGER) return number is
-------------------???????????????---------------------------
  --ACODELOOP VARCHAR2(10);
  GENSCOUNT INTEGER;
  SUMSTANDPREM NUMBER;
begin
  --ACODELOOP := ACODE;
  SUMSTANDPREM := 0;

  --?????????????
  SELECT sum(nvl(standprem,0)) INTO SUMSTANDPREM FROM lacommision
   WHERE commdire='1' and p6=0 and agentcode=tagentcode
   and tmakedate>=tempbegin and tmakedate<=tempend;
  --??????????????? ?????
  DECLARE
    ADDCODE  VARCHAR2(10);
  CURSOR C_ADDAGENTFYC IS
    SELECT AGENTCODE FROM LATREE
     WHERE AGENTGROUP = tagentgroup
       AND INTROAGENCY = tagentcode
       AND STATE='0';

  BEGIN
    GENSCOUNT := tgens + 1;
    OPEN C_ADDAGENTFYC;
    LOOP
      FETCH C_ADDAGENTFYC INTO ADDCODE;
      EXIT WHEN C_ADDAGENTFYC%NOTFOUND;
      if GENSCOUNT<2 then
        SUMSTANDPREM := SUMSTANDPREM + AdvanceStandPrem(addcode,tagentgroup,tempbegin,tempend,genscount);
      end if;
    END LOOP;
    CLOSE C_ADDAGENTFYC;
  END;

  return SUMSTANDPREM;
end AdvanceStandPrem;

/
