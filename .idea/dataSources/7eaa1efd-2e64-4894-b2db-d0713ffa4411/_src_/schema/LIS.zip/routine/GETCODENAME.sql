CREATE FUNCTION     "GETCODENAME" (TCodeType IN varchar2,TCode IN varChar2)
return VarChar2  IS

TCodeName varchar2(50);
intFlag integer;
begin
       select count(*) INTO intFlag from LDcode  where CodeType=TCodeType and Code=TCode;
       if intFlag=1 then
              select trim(CodeName) INTO TCodeName from LDcode  where CodeType=TCodeType and Code=TCode;
        else
              TCodeName:=trim(TCodeType)||':'||trim(TCode);
        end if ;

  return (TCodeName);
end getCodeName;

/
