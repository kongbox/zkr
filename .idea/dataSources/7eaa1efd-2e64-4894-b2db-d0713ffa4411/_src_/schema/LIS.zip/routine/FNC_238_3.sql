CREATE FUNCTION     "FNC_238_3" (c_cureType char ,c_contNo char,c_polno char,c_insuredNo char,n_caseNo char,n_daysInHos number,n_fee number,d_accidentDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_minStartDate Date;
  d_limitDate Date;
  c_havaPre number;
  c_havaNext number;
begin
--?????????
--select fnc_238(1?'90000006810',50,500,to_date('2006-06-11'),to_date('2006-07-30'),to_date('2005-06-01'),to_date('2006-05-31')) from dual;

Result:=0;                               --?Result??

c_havaPre:=0;

c_havaNext:=0;

                                         --???????????
select nvl(Count(*),0) into c_havaPre from lcpol where contno=c_contNo and appflag in ('1','4') and riskcode='00238000' and insuredno=c_insuredNo and enddate=(select getstartdate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --???????????
select nvl(Count(*),0) into c_havaNext from lcpol where contno=c_contNo and appflag in ('1','4') and riskcode='00238000' and insuredno=c_insuredNo and getstartdate=(select enddate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

select min(StartDate) into d_minStartDate from LLCaseReceipt where CaseNo=n_CaseNo;	--???????

                                         --???????????????????????
select least((min(StartDate)+180),(d_lcgetEndDate+30)) into d_limitDate from LLCaseReceipt where CaseNo=n_CaseNo;

-------------------------------------------------------------------------------------------------------------


if c_cureType<>'A' and d_accidentDate<=d_startDate then     --??????,???????????????

-------------------------------------------------------------------------------------------------------------
--??????????????,????????????????????????? --
  if  d_lcgetStartDate<=d_startDate and  d_startDate <=d_lcgetEndDate and c_havaNext=0 and d_startDate<=d_limitDate then

    if d_endDate<=d_limitDate then       --??????????????
      	if (n_fee/n_daysInHos)>20 then     --???????20
        	select 20*n_daysInHos into Result from Dual;
      	else
        	select n_fee into Result from Dual;
      	end if ;
    else                                 --??????????????
  	    if (n_fee/n_daysInHos)>20 then     --???????20
        	  select 20*(d_limitDate-d_startDate) into Result from Dual;
      	else
        	  select n_fee*(d_limitDate-d_startDate)/n_daysInHos into Result from Dual;
      	end if;
    end if;

  end if ;
-------------------------------------------------------------------------------------------------------------
--????????????????????180?????????????????????? --
  if d_lcgetStartDate<=d_startDate and  d_startDate <d_lcgetEndDate and  c_havaNext<>0  and d_startDate<=(d_minStartDate+180) then

    if d_endDate<=d_lcgetEndDate then   --???????
      if d_endDate<(d_minStartDate+180) then --???????180??
        if (n_fee/n_daysInHos)>20 then     --???????20
        	select 20*n_daysInHos into Result from Dual;
      	else
        	select n_fee into Result from Dual;
      	end if ;
      else                                 --???????180??
    	  if (n_fee/n_daysInHos)>20 then     --???????20
        	  select 20*((d_minStartDate+180)-d_startDate) into Result from Dual;
      	else
        	  select n_fee*((d_minStartDate+180)-d_startDate)/n_daysInHos into Result from Dual;
      	end if;
      end if;
   else                                  --???? ?????????
      if d_lcgetEndDate<(d_minStartDate+180) then --lcget????180??
        if (n_fee/n_daysInHos)>20 then     --???????20
        	select 20*(d_lcgetEndDate-d_startDate) into Result from Dual;
      	else
        	select n_fee*(d_lcgetEndDate-d_startDate)/n_daysInHos into Result from Dual;
      	end if ;
      else                                 --lcget????180??
    	  if (n_fee/n_daysInHos)>20 then     --???????20
        	  select 20*((d_minStartDate+180)-d_startDate) into Result from Dual;
      	else
        	  select n_fee*((d_minStartDate+180)-d_startDate)/n_daysInHos into Result from Dual;
      	end if;
      end if;
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
  --????????????????????????????????????? ???????180???????????????????--
  if  d_startDate<d_lcgetStartDate and  d_lcgetStartDate<=d_endDate and  d_endDate <d_lcgetEndDate and c_havaPre<>0 and d_lcgetEndDate<=(d_minStartDate+180) then
    if d_endDate<(d_minStartDate+180) then --??????180??
      if (n_fee/n_daysInHos)>20 then     --???????20
      	select 20*(d_endDate-d_lcgetStartDate) into Result from Dual;
    	else
      	select n_fee*(d_endDate-d_lcgetStartDate)/n_daysInHos into Result from Dual;
    	end if ;
    else                                 --??????180??
  	  if (n_fee/n_daysInHos)>20 then     --???????20
      	  select 20*((d_minStartDate+180)-d_lcgetStartDate) into Result from Dual;
    	else
      	  select n_fee*((d_minStartDate+180)-d_lcgetStartDate)/n_daysInHos into Result from Dual;
    	end if;
    end if;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_238_3;

/
