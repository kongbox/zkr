CREATE FUNCTION     "ASSESSGRPSTANDPERM" (
       tAgentCode laagent.agentcode%Type,
       tIndexCalNo laindexinfo.indexcalno%Type,
       tBranchType laagent.branchtype%Type,
       tTempBegin latree.startdate%Type,
       tTempEnd latree.startdate%Type
)
return  Number is
  Result Number;
  ---??????
  lastStandPrem  Number;
  thisStandPrem  Number;
  lastCalNo      Varchar2(6);

Begin
     lastStandPrem:= 0;
     thisStandPrem:= 0;
     Select nvl(Sum(standprem),0) Into thisStandPrem From lacommision
            Where tmakedate<=tTempEnd And branchtype=tBranchType And paycount='1' And tmakedate>=tTempBegin And AgentCode=tAgentCode;
     Select nvl(Max(indexcalno),0) Into lastCalNo From laindexinfo Where AgentCode=tAgentCode And indexType='04';
     If (lastCalNo<>'0' And lastCalNo<>tIndexCalNo) Then
        Select nvl(T1,0) Into lastStandPrem From laindexinfo Where AgentCode=tAgentCode And indexType='04'And indexcalno=lastCalNo;
        Result:=thisStandPrem*0.85+lastStandPrem*0.15;
     Else
        Result:=thisStandPrem;
     End If;
     return(Result);
end AssessGrpStandPerm;

/
