CREATE FUNCTION     "CALGRPBACKPREM" (tagentcode in varchar2, tagentgrade in varchar2,
                                          twagenobegin in varchar2,twagenoend in varchar2,
                                          tdestagentgrade in varchar2,tareatype in varchar2,
                                          tassesstype in varchar2,flag in varchar2) return number is
--------------------------------------?????--------------------------------------
---flag: 'prem' ??????'agentcount'??????

  BackSum    number(10,2):=0 ;
  single         number(10,2):=0 ;
  cdirteamfycsum number (10,2):=0;
  cagentcode     varchar2(10);
  cstartdate     date;
  startmonth     varchar2(6);
  num            integer;
  cagentgroup    varchar2(20);

begin
  ---????????
  if tagentgrade< 'A201' then
     return 0;
  end if;

  Declare
  cursor c_backprem is
    ---?????????????
    select a.agentcode,a.startdate,a.agentgroup from larearrelation a where
    exists (select agentcode from latree where agentcode=a.agentcode and initgrade<>'A201' and initgrade<>'A301')
    and a.rearagentcode=tagentcode and a.rearlevel='01'
    and a.rearedgens=1 and a.rearflag='1';

    begin
      open c_backprem;
        loop
          fetch c_backprem into cagentcode,cstartdate,cagentgroup;
          exit when c_backprem%notfound;
          single:=0 ;
          cdirteamfycsum:=0;
          startmonth:=to_char(add_months(cstartdate,-1),'yyyymm');
          ---???????????????????????
          select count(*) into num from laassessaccessory
          where branchtype='1' and branchtype2='01'
          and assesstype='00' and indexcalno=startmonth
          and agentcode=tagentcode;
          if num=0 then
             if twagenobegin<=startmonth then
                if flag='prem' then
                   ---????????????????
                   select nvl(sum(T43),0) into single from laindexinfo
                   where agentcode=cagentcode and indextype='00'
                   and branchtype='1' and branchtype2='01'
                   and indexcalno>=startmonth and indexcalno<=twagenoend;
                elsif flag='agentcount' then
                   select count(distinct AgentCode) into single from LATree
                   where  Agentgroup= cagentgroup  and Agentcode<>cAgentcode and state = '0';
                end if;

                ---?????????
                cdirteamfycsum:=1;
            elsif twagenobegin>startmonth then
                if flag='prem' then
                   ---????????????????
                   select nvl(sum(T43),0) into single from laindexinfo
                   where agentcode=cagentcode and indextype='00'
                   and branchtype='1' and branchtype2='01'
                   and indexcalno>=twagenobegin and indexcalno<=twagenoend;
                elsif flag='agentcount' then
                   select count(distinct AgentCode) into single from LATree
                   where  Agentgroup= cagentgroup  and Agentcode<>cAgentcode and state = '0';
                end if;
                ---?????????
                 select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                 where agentgrade=tagentgrade and assesscode =tassesstype
                 and areatype =tareatype and destagentGrade =tdestagentgrade;
             end if;
         else
           if num>0 then
              if flag='prem' then
                    ---????????????????
                    select nvl(sum(T43),0) into single from laindexinfo
                    where agentcode=cagentcode and indextype='00'
                    and branchtype='1' and branchtype2='01'
                    and indexcalno>=twagenobegin and indexcalno<=twagenoend;
              elsif flag='agentcount' then
                     select count(distinct AgentCode) into single from LATree
                     where  Agentgroup= cagentgroup  and Agentcode<>cAgentcode and state = '0';
              end if;
              if twagenobegin=startmonth then
                 ---?????????
                 cdirteamfycsum:=1;
              elsif twagenobegin>startmonth then
                 ---?????????
                 select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                 where agentgrade=tagentgrade and assesscode =tassesstype
                 and areatype =tareatype and destagentGrade =tdestagentgrade;
              end if;
            end if;
          end if;
            BackSum:=BackSum+single*cdirteamfycsum;

        end loop;
      close c_backprem;
   end;
 return(BackSum);
end CalGrpBackPrem;

/
