CREATE FUNCTION     "CHGCALINSUYEAR611" (InsuYear in number) return number is
v_tR number;
v_Integer number;
v_Mod number;
begin
 v_Mod := mod(InsuYear,12);
 v_Integer := trunc(InsuYear/12);
    case
 when v_Mod = 1 then
  v_tR := 0.2;
 when v_Mod = 2 then
  v_tR := 0.3;
 when v_Mod = 3 then
  v_tR := 0.4;
 when v_Mod = 4 then
  v_tR := 0.5;
 when v_Mod = 5 then
  v_tR := 0.6;
 when v_Mod = 6 then
  v_tR := 0.7;
 when v_Mod = 7 then
  v_tR := 0.75;
 when v_Mod = 8 then
  v_tR := 0.8;
 when v_Mod = 9 then
  v_tR := 0.85;
 when v_Mod = 10 then
  v_tR := 0.9;
 when v_Mod = 11 then
  v_tR := 0.95;
 when v_Mod = 0 then
  v_tR := 0;
 end case;

v_tR := v_tR+v_Integer;
 return(v_tR);
end;

/
