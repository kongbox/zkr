CREATE FUNCTION     "BUSIMAGERYEARBONUS" (twagecode in varchar2, tareatype in varchar2,tindexcalno in varchar2,
tagentcode in varchar2,tyearmark in varchar2,tagentgrade in varchar2) return number is
  Result number(12,4):=0;
  cMageBonus number(12,4):=0;--????
  cRate number(12,4):=1;--?????
  cGradeRate number(12,4):=1;--????
  cYearBonus number(12,4):=0;--???????
  cAgentState varchar2(6);--????
  /*cBeginMonth number(12,6):=0;--????????????
  cAgentGrade latree.agentgrade%type;--??
  cPassPeriod number(12,6):=0;--??????
  i integer:=0;--????*/
begin
  if tyearmark ='0' then
    return(Result);
  end if;
  select agentstate into cAgentState from laagent where agentcode=tagentcode;
  if cAgentState>'03' then
    return(Result) ;
  end if;
--??????
  select nvl(sum(T42),0) into cMageBonus from laindexinfo where indexcalno like Concat(Substr(tindexcalno,1,4),'%') and agentcode=tagentcode and
  indextype='01'  and branchtype='4' and branchtype2='01';
--?????
  select nvl(sum(drawreward),1) into cRate from lawageparam2 where wagecode=twagecode and paracode='WP0073'
  and areatype=tareatype;
--????
  select  nvl(sum(drawreward),1) into cGradeRate from lawageparam2 where wagecode=twagecode and paracode='WP0074'
  and areatype=tareatype and associateobj=tagentgrade;
-- ???????
  select nvl(sum(AddBonus),0) into cYearBonus from laindexinfo where indexcalno =tindexcalno and agentcode=tagentcode and
  indextype='01' and branchtype='4' and branchtype2='01';
/*--3????????????????????????,??????????????????????????????????????
--?????????????
--???????????
  select agentgrade into cAgentGrade from laindexinfo where agentcode=tagentcode
  and indexcalno=Concat(Substr(tindexcalno,1,4),'01') and indextype='01' and branchtype='4' and branchtype2='01';

  if Substr(cAgentGrade,1,2)='G2' then--???????
     i:=12;
     while i<=14 and cAgentGrade<'G201'
     loop
       select agentgrade into cAgentGrade from laindexinfo where agentcode=tagentcode
       and indexcalno=to_char(add_months(to_date(tindexcalno||'01','yyyy-mm-dd'),-i),'yyyymm')
       and indextype='01' and branchtype='4' and branchtype2='01';
       i:=i+1;
     end loop;
     if i<=14 then  --???????
       i:=i+1;
     end if;
  end if;
 */
  Result := cMageBonus*cRate*cGradeRate+cYearBonus;
   return(Result);
end BusiMagerYearBonus;

/
