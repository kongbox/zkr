CREATE FUNCTION     "DISTRICTYEARBONUS" (tagentcode in varchar2,twagecode in varchar2,tareatype in varchar2,tagentgrade in varchar2,tindexcalno in varchar2,tyearmark in varchar2) return number is
  Result number(12,4):=0;
  cSumMagerBonus number(12,4):=0;--????????
  cRatio number(12,4):=1;--???????
  cGradeRatio number(12,4):=1;--????
  cMagerYearBonus number(12,4):=0;--????????????
  cyear laindexinfo.indexcalno%type;
  cAgentState laagent.agentstate%type;
begin
  if tyearmark='0' then
     return(Result);
  end if;
  --??????
  select agentstate into cAgentState from laagent where agentcode=tagentcode;
  if cAgentState>'03' then
    return(Result) ;
  end if;
  cyear :=  Substr(tindexcalno,1,4);
  --??????
  select nvl(sum(t47),0) into cSumMagerBonus from laindexinfo where agentcode=tagentcode and indexcalno like
  cyear||'%' and indextype='01' and branchtype='4' and branchtype2='01';
  --?????
  select nvl(sum(drawreward),1) into cRatio from lawageparam2 where wagecode=twagecode and paracode='WP0082'
  and areatype=tareatype;
  --????
  select nvl(sum(drawreward),1) into cGradeRatio from lawageparam2 where wagecode=twagecode and paracode='WP0083'
  and associateobj=tagentgrade and areatype=tareatype;
  --??????????
  select nvl(sum(t26),0) into cMagerYearBonus from laindexinfo where agentcode=tagentcode and indexcalno =tindexcalno
  and indextype='01' and branchtype='4' and branchtype2='01';

  Result:=cSumMagerBonus*cRatio*cGradeRatio+cMagerYearBonus;
  return(Result);
end DistrictYearBonus;

/
