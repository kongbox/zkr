CREATE FUNCTION     "CALADDBONUS" (tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,YearMark varchar2,YearBegin in date,YearEnd in date) return number is
  FYC1     number(10,2):=0;
  FYC2     number(10,2):=0;
  tFYC     number(10,2):=0;
  --tYear    varchar2(10);
  --tMon     varchar2(10);
  --tStr     varchar2(20);
  --tE       varchar2(10);
  tY       varchar2(10);
  tDrawRate number(10,2):=0;
  fyc       number(10,2):=0;
  Result    number(10,2):=0;

--???????
begin

  if YearMark = '0' then
    return (0);
  end if;

  --???????????FYC?
  ---?? 2004-02-19?????LAWage???F04???LAIndexInfo???FirstPension

  select nvl(sum(FirstPension),0) into tFYC from laagent b,laindexinfo a
      where a.agentcode = b.agentcode
            and trim(a.indexcalno) >= trim(to_char(b.employdate,'yyyymm')) and trim(indexcalno) < trim( to_char(YearEnd,'yyyymm'))
            and trim(a.indextype)='01'
            and trim(to_char(b.employdate,'yyyy')) = to_char(YearEnd,'yyyy')
            and exists (select 'X' from latree where agentcode = a.agentcode and state<>'3' and introagency=tAgentcode)
            ;
  select nvl(sum(fyc),0) into fyc from laagent b,lacommision a
      where a.agentcode = b.agentcode
       and a.commdire = '1'
       and trim(a.wageno) = to_char(YearEnd,'yyyymm')
       and trim(to_char(b.employdate,'yyyy'))= to_char(YearEnd,'yyyy')
       and exists (select 'X' from latree where agentcode = a.agentcode and state<>'3' and introagency=tAgentcode);

  FYC1:= nvl(tFYC,0) + fyc;

  --??????????????????FYC?
   --?????????
   ---?? 2004-02-19?????LAWage???F04???LAIndexInfo???FirstPension
     tY:= to_char(YearEnd,'yyyy')-1;
    select nvl(sum(FirstPension),0) into FYC2 from laagent b,laindexinfo a
      where a.agentcode = b.agentcode
            and trim(a.indexcalno) >= trim(to_char(YearBegin,'yyyymm'))
            and trim(a.indexcalno) <= trim( concat(to_char(YearBegin,'yyyy'),to_char(add_months(b.employdate,-1),'mm')))
            and trim(a.indextype)='01'
            and trim(to_char(b.employdate,'yyyy')) = trim(tY)
            and to_char(b.employdate,'mm')<>'01'
            and exists (select 'X' from latree where agentcode = a.agentcode and state<>'3' and introagency=tAgentcode)
            ;

  select nvl(drawrate,0) into tDrawRate from lawageradix
  where trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    and trim(AreaType)=trim(tAreaType);

  Result:=(FYC1+FYC2)*tDrawRate;

  return(Result);
end CALADDBONUS;

/
