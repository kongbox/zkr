CREATE FUNCTION     GETRISKEFFECTAMNT(tPolNo lcpol.polno%type)
  return number is
  Result       number;
  tSumDutyAmnt number;
  tDutyAmnt    number;
  DutyCode lcduty.dutycode%type;
  CURSOR tDutyCur IS
    SELECT distinct dutycode FROM lcduty WHERE polno = tPolNo;
begin
  Result       := 0;
  tSumDutyAmnt := 0;
  tDutyAmnt    := 0;
  --根据责任的有效保额来进行处理
  open tDutyCur;
  loop
    FETCH tDutyCur
      INTO DutyCode;
    EXIT WHEN tDutyCur%NOTFOUND;
    select max(getRiskDutyEffectAmnt(tPolNo,
                                     DutyCode,
                                     b.GetDutyCode,
                                     a.getdutykind))
      into tDutyAmnt
      from lmdutygetclm a, lcget b
     where a.getdutycode = b.getdutycode
       and b.dutycode = DutyCode
       and b.polno = tPolNo;
    tSumDutyAmnt := tSumDutyAmnt + tDutyAmnt;
  end loop;
  close tDutyCur;
  if tSumDutyAmnt > 0 then
    Result := tSumDutyAmnt;
  end if;
  return(Result);
end GETRISKEFFECTAMNT;

/
