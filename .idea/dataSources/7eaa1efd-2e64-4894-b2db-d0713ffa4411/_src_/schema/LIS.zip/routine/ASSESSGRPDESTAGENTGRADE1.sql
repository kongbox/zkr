CREATE FUNCTION     "ASSESSGRPDESTAGENTGRADE1" (
       tAgentCode latree.agentcode%Type,
       tAgentGrade latree.agentgrade%Type,
       tIndexCalNo lacommision.wageno%Type,
       tBranchType latree.branchtype%Type,
       tManageCom latree.managecom%Type
)
return latree.agentgrade%Type is
  Result latree.agentgrade%Type;

  tAgentgrade1          Varchar2(6); --????????
  tAgentgrade2          Varchar2(6); --?????????
  maintainprem          Number;   --??????
  promoteprem           Number;   --??????
  maintainmanpower      Number;   --??????
  promotemanpower       Number;   --??????
  maintainmanpower1     Number;  --????????
  promotemanpower1      Number;  --????????
  tT1                   Number;  --??????
  tMngAgentCount        Number; --??????
  tT2                   Number;--????????
  tAreaType             char; --????
Begin
     select trim(comareatype) Into tAreaType from ldcom where trim(comcode)=tManageCom;
     select dropgrade,markbegin,markend Into maintainprem,maintainmanpower,maintainmanpower1 from LAAgentPromRadix2
     where AgentGrade=tAgentGrade and DestAgentGrade=tAgentGrade and BranchType=tBranchType and AreaType=tAreaType;

     select dropgrade,markbegin,markend Into promoteprem,promotemanpower,promotemanpower1 from LAAgentPromRadix2
     where AgentGrade=tAgentGrade and DestAgentGrade>AgentGrade and BranchType=tBranchType and AreaType=tAreaType;

     select T1,MngAgentCount,T2   Into tT1, tMngAgentCount, tT2 from LAIndexInfo where  agentcode=tAgentCode and  indextype='04' and indexcalno=tIndexCalNo;
     If (tT1>=promoteprem and tMngAgentCount>=promotemanpower and tT2>=promotemanpower1 ) then
              select agentgrade Into tAgentgrade1 from latree where agentcode=tAgentCode and branchtype=tBranchType
                    and managecom=tManageCom and agentkind=tAgentGrade;
             select agentgrade1 Into tAgentgrade2 from laassessaccessory where indexcalno=tIndexCalNo and agentcode=tAgentCode and managecom=tManageCom
                    and assesstype='01' and agentgrade=tAgentgrade1;
             If (tAgentgrade2>=tAgentgrade1) then
                 select  DestAgentGrade Into Result from  LAAgentPromRadix2 where  AgentGrade=tAgentGrade and DestAgentGrade>tAgentGrade
                 and BranchType=tBranchType and AreaType=tAreaType;
             else Result:=tAgentGrade;
             End If;
        Else If (tT1>=maintainprem and tMngAgentCount>=maintainmanpower and tT2>=maintainmanpower1) then
                select DestAgentGrade Into Result from LAAgentPromRadix2 where agentgrade=tAgentGrade and DestAgentGrade=tAgentGrade
                       and BranchType=tBranchType and AreaType=tAreaType;
        Else If (tT1<maintainprem and tMngAgentCount>=maintainmanpower and tT2>=maintainmanpower1) then
                select DestAgentGrade Into Result from LAAgentPromRadix2 where agentgrade=tAgentgrade and dropgrade is null
                and markbegin=maintainmanpower and markend=maintainmanpower1
                and BranchType=tBranchType and AreaType=tAreaType;
        Else
              select DestAgentGrade Into Result from LAAgentPromRadix2 where agentgrade=tAgentGrade and dropgrade is null
                and markbegin is null and markend is null  and BranchType=tBranchType and AreaType=tAreaType;
     End If;
    End If;
  End If;
  Return(Result);
end AssessGrpDestAgentGrade1;

/
