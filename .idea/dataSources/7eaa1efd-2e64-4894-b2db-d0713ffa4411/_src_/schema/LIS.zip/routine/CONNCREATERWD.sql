CREATE FUNCTION     "CONNCREATERWD" (tAgentCode in varchar2, tAgentGrade in varchar2,tManageCom in varchar2,tWageCode in varchar2,TempBegin in date,TempEnd in date) return number is
  tStartDate          date;
  tGroup     varchar2(20);
  tBranchAttr varchar2(255);
  tLinkEnd            date;
  tEmployDate         date;
  tIndueFormDate      date;
  tAssStartDate       date;
  tArrPeriod          number(12,3):=0;
  tSendMons           integer:=0;
  tMul                number(12,3):=0;
  tSumF24             number(12,3):=0;

  --????
  tPayIntvl           integer:=0;
  --????
  tCalStart           date;
  tPayMonStart        varchar2(2);
  tPayMonEnd          varchar2(2);

  tMod                number(12,3):=0;
  tMonthLimit         integer:=0;

  --????
  tPayMode            varchar2(1);
  --???????
  tStandRate          number(12,3):=0;
  --?????FYC
  tPrem               number(12,3):=0;
  tFYC                number(12,3):=0;
  --?????????
  tSumPrem            number(12,3):=0;
  tSumFYC             number(12,3):=0;

  --??????????
  tStandardSum        number(20,10):=0;
  --??????
  tStandard           number(20,10):=0;

  --???????????A04?Y????N????
  tJudgeFlag      varchar2(1);
  tManageComCond  varchar2(10);

  iCount          integer :=0 ;
  Result number;
begin


  tManageComCond := trim(tManageCom);

  --??????????
  select employdate,indueformdate,startdate,agentgroup into tEmployDate,tIndueFormDate,tStartDate,tGroup
  from laagenttreeview
  where agentcode = trim(tAgentCode);

  tBranchAttr:=trim(getbranchattr(tGroup));

  --???????????
  if tIndueFormDate <> tEmployDate then
    return(0);
  end if;

  tJudgeFlag := doJudgeGrade(tAgentCode);
  if tJudgeFlag = 'N' then
    return(0);
  end if;


  --???????????
  select ArrangePeriod,nvl(linkenddate,to_date('3000-01-01','YYYY-MM-DD')) into tArrPeriod,tLinkEnd
  from lalinkassess
  where tManageComCond like trim(managecom)||'%' and trim(agentgrade) = trim(tAgentGrade)
  ;

  --???????????????
  if TempBegin > tLinkEnd then
    return(0);
  end if;

  --???????
  tSendMons := DateInterval(tEmployDate,TempBegin);
  tSendMons := tSendMons - tArrPeriod;

  --??tAgentGrade,tManageCom,tWageCode,tPayMode ?LALinkWage??????????
  select count(*) into iCount from LALinkWage
  where tManageComCond like trim(managecom)||'%'
    and trim(payperiodtype) = '02'
    and trim(paymonth)= '01'
    and trim(agentgrade) = trim(tAgentGrade)
    and trim(wagecode) = trim(tWageCode)
    ;
  if iCount > 0 then
    select MonthLimit,payinterval,paymode into tMonthLimit,tPayIntvl,tPayMode from LALinkWage
    where trim(payperiodtype) = '02'
      and trim(paymonth)= '01'
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode) = trim(tWageCode)
      ;
  else
    return 0;
  end if;


  --????????????????
  tMod := mod(tSendMons,tPayIntvl);
  tMul := tSendMons/tPayIntvl;
  if tSendMons > tMonthLimit or tMod <> 0 or tMul<=0 then
    return(0);
  end if;


  --???????????????????????????????????????
  if tAgentGrade > 'A05' then
    if tPayMode = '0' then
      if tSendMons <> tMonthLimit then
        return(0);
      end if;
    end if;
  end if;


  --????
  tAssStartDate := Getdate(tEmployDate,tArrPeriod,TempBegin);
  if tMul = 1 then
    tPrem := Gettransmoney(tAssStartDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
    tFYC  := Gettransmoney(tAssStartDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'F');
  else
    tCalStart := getDate(tAssStartDate,(tMul-1)*tPayIntvl,TempBegin);
    tPrem := Gettransmoney(tCalStart,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
    tFYC  := Gettransmoney(tCalStart,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'F');
  end if;


  --????????
  if tAgentGrade >= 'A05' then
    tPayMonStart := trim(to_char((tMul-1)*tPayIntvl+1,'09'));
    tPayMonEnd := trim(to_char((tMul-1)*tPayIntvl+tPayIntvl,'09'));
    select sum(baserate) into tStandard from lalinkwage
    where trim(payperiodtype) = '02'
      and trim(paymonth)>=trim(tPayMonStart)
      and trim(paymonth)<=trim(tPayMonEnd)
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode)
      ;

    select standrate into tStandRate from lalinkwage
    where trim(payperiodtype) = '02'
      and trim(paymonth)= trim(tPayMonStart)
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode)
      ;
  else
    select sum(baserate) into tStandard from lalinkwage
    where trim(payperiodtype) = '02'
    and trim(agentgrade) = trim(tAgentGrade)
      and tManageComCond like trim(managecom)||'%'
      and trim(wagecode)=trim(tWageCode)
      ;

    select standrate into tStandRate from lalinkwage
    where trim(payperiodtype) = '02'
      and trim(paymonth)= '01'
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode)
      ;
  end if;




  tAssStartDate := getdate(tEmployDate,tArrPeriod,TempBegin);
  if tSendMons = tMonthLimit then
    tSumPrem := Gettransmoney(tAssStartDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
    tSumFYC  := Gettransmoney(tAssStartDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'F');

    --????????
    select sum(baserate) into tStandardSum from lalinkwage
    where trim(payperiodtype) = '02'
    and trim(tManageComCond) like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode) = trim(tWageCode)
      ;


    if tSumPrem >= tStandardSum then
    --??2004-02-18?????LAWage???F24?????LAIndexInfo???T33??
      select nvl(sum(T33),0) into tSumF24 from laindexinfo
      where trim(indextype)='01'
      and trim(indexcalno) >= to_char(tAssStartDate,'yyyymm')
        and trim(indexcalno) <= to_char(TempEnd,'yyyymm')
        and trim(agentcode) = trim(tAgentCode)
        ;

      Result := tSumFYC * tStandRate - tSumF24;
    else
      if tPrem >= tStandard then
        Result := tFYC*tStandRate;
      else
        Result := 0;
      end if;
    end if;
  else
    if tPrem >= tStandard then
      Result := tFYC*tStandRate;
    else
      Result := 0;
    end if;
  end if;

  return(Result);
end connCreateRwd;

/
