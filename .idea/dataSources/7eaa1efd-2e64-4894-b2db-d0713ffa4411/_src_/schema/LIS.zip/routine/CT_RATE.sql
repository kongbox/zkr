CREATE function     ct_rate(tedorvalidate in date,tpolno in varchar2,tedorno in varchar2) return number is
  Result number;
  triskcode lmrisk.riskcode%type;
  tcount number;
  tpassmonth number;
  tcvalidate date;
  tpayintv number;
  tinsuyear number;
  tGrpPolNo lcgrppol.grppolno%type;
begin
  select cvalidate into tcvalidate from lcpol where polno=tpolno;
  select payintv into tpayintv from lcpol where polno=tpolno;
  select riskcode into triskcode from lcpol where polno=tpolno;
  select months_between(tedorvalidate,tcvalidate) into tpassmonth from dual;
  select floor(tpassmonth/12+1) into tinsuyear from dual;
  if triskcode='102' then
    select count(*) into tcount from lcduty where polno=tpolno;
    if tcount>1 then
      select nvl((select rate from rate_102_cv where c4=-1 and tinsuyear-1=payyears),1) into result from dual;
    else
      select nvl((select rate from rate_102_cv where c4=1 and tinsuyear-1=payyears),1) into result from dual;
    end if;
  elsif triskcode='101' then
    select nvl((select rate from rate_101_cv where payintv=tpayintv and tinsuyear=payyears),1) into result from dual;
  elsif triskcode='161' then
    select nvl((select rate from rate_161_cv where payintv=tpayintv and tinsuyear=payyears),1) into result from dual;
  elsif triskcode='403' then
    select nvl((select rate from rate_403_cv where tinsuyear=endyears),1) into result from dual;
  elsif triskcode='404' then
    select nvl((select rate from rate_404_cv where payintv=tpayintv and tinsuyear=endyears),1) into result from dual;
  elsif triskcode='405' then
    select nvl((select rate from rate_405_cv where payintv=tpayintv and tinsuyear=endyears),1) into result from dual;
  elsif triskcode='409' then
    select nvl((select rate from rate_409_cv where payintv=tpayintv and tinsuyear=endyears),1) into result from dual;
  elsif triskcode='601' then
    select nvl((select rate from rate_601_cv where payintv=tpayintv and tinsuyear=payyears),1) into result from dual;
  elsif triskcode='803' then
    if tinsuyear<5 then
      select nvl((select rate from rate_113 where tinsuyear=styears),1) into result from dual;
    else
      result:=1;
    end if;
  elsif triskcode='162' then
    select nvl((select rate from rate_162_cv where tpassmonth>=downlimit and tpassmonth<uplimit),1) into result from dual;
  elsif triskcode='808' then
    select nvl((select rate from rate_808 where payintv=tpayintv and tinsuyear=payyears),1) into result from dual;
  elsif triskcode='139' then
    select 1 into result from dual;
  elsif (triskcode='40810701' or triskcode='40810702' or triskcode='40810703' or triskcode='40810801') then
    select grppolno into tgrppolno from lcpol where polno=tpolno;
    if tgrppolno is not null then
      select count(*) into tcount from lcaccgrppol where grppolno=tgrppolno and tinsuyear-1>=minyearinterval and tinsuyear-1<maxyearinterval and appflag='1';
      if (tcount>0) then
        select loanvaluerate into result from lcaccgrppol where grppolno=tgrppolno and tinsuyear-1>=minyearinterval and tinsuyear-1 <maxyearinterval and appflag='1';
        return 1-result;
      end if;
    end if;
    select nvl((select rate from rate_188_cv where tpassmonth>=downlimit and tpassmonth<uplimit),1) into result from dual;
  elsif (triskcode='40820701' or triskcode='40820801' or triskcode='40021501') then
    select grppolno into tgrppolno from lcpol where polno=tpolno;
    if tgrppolno is not null then
      select count(*) into tcount from lcaccgrppol where grppolno=tgrppolno and tinsuyear-1>=minyearinterval and tinsuyear-1 <maxyearinterval and appflag='1';
      if (tcount>0) then
        select loanvaluerate into result from lcaccgrppol where grppolno=tgrppolno and tinsuyear-1>=minyearinterval and tinsuyear-1<maxyearinterval and appflag='1';
        return 1-result;
      end if;
    end if;
    select nvl((select rate from rate_188_cv where tpassmonth>=downlimit and tpassmonth<uplimit),1) into result from dual;
  end if;
  return(Result);
end ct_rate;

/
