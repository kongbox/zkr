CREATE FUNCTION     "DISTRICTPASSRATE" (tagentcode in varchar2,tdistrict in varchar2,tpaycount lacommision.paycount%type,tstartdate in date,tenddate in date) return number  is
  Result number(12,4):=0;
  cAgentState varchar2(2);--??????
  cRetireflag varchar2(1);--1??????=0??????????
  cSumDuePayMoney number(12,4):=0;--??
  cSumActuPayMoney number(12,4):=0;--??
  cGroup  labranchgroup.agentgroup%type;--???????
  cDuePayMoney number(12,4):=0;
  cActuPayMoney number(12,4):=0;--?????????????
--  cActuPayMoney1 number(12,4):=0;
--  cSumActuPayMoney1 number(12,4):=0;
begin
/*  declare
    cursor c_agentgroup is
      select agentgroup from labranchgroup where upbranch=tdistrict;
      begin
        open c_agentgroup;
          loop
            fetch c_agentgroup into cGroup;
            exit when c_agentgroup%notfound;
            if tpaycount<4 then
               select sum(sumDuePayMoney) into cDuePayMoney from ljspayperson a ,lacommisiondetail b
               where trim(a.agentgroup) = cGroup and trim(PayCount)=tPayCount
               and trim(LastPayToDate)>=tStartDate-60 and trim(LastPayToDate)<=tEndDate-60
               and a.contno=b.grpcontno and b.poltype='1';
            else
               select sum(sumDuePayMoney) into cDuePayMoney from ljspayperson a ,lacommisiondetail b
               where trim(a.agentgroup) = cGroup and trim(PayCount)>=tPayCount
               and trim(LastPayToDate)>=tStartDate-60 and trim(LastPayToDate)<=tEndDate-60
               and a.contno=b.grpcontno and b.poltype='1';
            end if;
            cSumDuePayMoney:=cSumDuePayMoney+cDuePayMoney;


              if tpaycount<4 then
                 select sum(transMoney) into cActuPayMoney from LACommision where trim(agentgroup) = cGroup and trim(PayCount)=tPayCount and trim(LastPayToDate)>=tStartDate-60
                 and calcdate is null and trim(LastPayToDate)<=tEndDate-60 and trim(LastPayToDate)<=tEndDate-60
                 and p6='1' and commdire='1' and transtype<>'FX';--?????????
              else
                 select sum(transMoney) into cActuPayMoney from LACommision where trim(agentgroup) = cGroup
                 and trim(PayCount)>=tPayCount and trim(LastPayToDate)>=tStartDate-60
                 and calcdate is null and trim(LastPayToDate)<=tEndDate-60 and trim(LastPayToDate)<=tEndDate-60
                 and p6='1' and commdire='1' and transtype<>'FX';
              end if;
              cSumActuPayMoney:=cSumActuPayMoney+cActuPayMoney;
              --??????????????
             if tRetireFlag =1 then
              if tpaycount<4 then
                 select sum(transMoney) into cActuPayMoney1 from LACommision where trim(agentgroup) = cGroup and trim(PayCount)=tPayCount and trim(LastPayToDate)>=tStartDate-60
                 and calcdate is null and trim(LastPayToDate)<=tEndDate-60 and trim(LastPayToDate)<=tEndDate-60
                 and p6='1' and commdire='1' and transtype<>'FX' and TMakeDate<=tEndDate-30;--?????????
              else
                 select sum(transMoney) into cActuPayMoney1 from LACommision where trim(agentgroup) = cGroup
                 and trim(PayCount)>=tPayCount and trim(LastPayToDate)>=tStartDate-60
                 and calcdate is null and trim(LastPayToDate)<=tEndDate-60 and trim(LastPayToDate)<=tEndDate-60
                 and p6='1' and commdire='1' and transtype<>'FX' and TMakeDate<=tEndDate-30;
              end if;
              cSumActuPayMoney1:=cSumActuPayMoney1+cActuPayMoney1;
             end if;


          end loop;
        close c_agentgroup;
      end;
 */
 --??????
 select agentstate into cAgentState from laagent where agentcode=tagentcode;
 if cAgentState<'03' then
    cRetireFlag :='0';
 else
    cRetireFlag :='1';
 end if;

 --???? branchseries ????????????
 if cRetireFlag='0' then --?????
 --??????????????????????????????????branchseries,???????
 /* if tpaycount=2 then
    select sum(t62) into cSumDuePayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
    select sum(DepFYCSum) into cSumActuPayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
  end if;

  if tpaycount=3 then
    select sum(T65) into cSumDuePayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
    select sum(InitPension) into cSumActuPayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
  end if;

   if tpaycount=4 then
    select sum(t68) into cSumDuePayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
    select sum(t56) into cSumActuPayMoney from laindexinfo where branchseries like tdistrict+'%%' and indexcalno=tindexcalno
    and indextype='01';
  end if;
  if cSumActuPayMoney+cSumDuePayMoney=0 then
    Result :=1;
  else
    Result :=cSumActuPayMoney/cSumActuPayMoney+cSumDuePayMoney;
  end if;
*/
  declare
    cursor c_agentgroup is
      select agentgroup from labranchgroup where upbranch=tdistrict;
      begin
        open c_agentgroup;
          loop
            fetch c_agentgroup into cGroup;
            exit when c_agentgroup%notfound;
            if tpaycount<4 then
               select nvl(sum(sumDuePayMoney),0) into cDuePayMoney from ljspayperson a ,lacommisiondetail b
               where a.agentgroup = cGroup and PayCount=tPayCount
               and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
               and b.poltype='1' and a.payintv<>'-1' and not exists(select 1 from lacommision c where a.contno=c.contno
               and c.flag='2' and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
            else
               select nvl(sum(sumDuePayMoney),0) into cDuePayMoney from ljspayperson a ,lacommisiondetail b
               where a.agentgroup = cGroup and PayCount>=tPayCount
               and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
               and b.poltype='1' and a.payintv<>'-1' and not exists(select 1 from lacommision c where a.contno=c.contno
               and c.flag='2' and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
            end if;
            cSumDuePayMoney:=cSumDuePayMoney+cDuePayMoney;
           end loop;
        close c_agentgroup;
      end;
      --??
      if tpaycount< 4 then
         select nvl(sum(transmoney),0) into cSumActuPayMoney from lacommision where branchseries like '%'||tdistrict||'%' and PayCount=tPayCount and LastPayToDate>=tStartDate-60
         and lastpaytodate<=tEndDate-60 and p6='1' and transtype<>'FX'
         and payintv<>'-1' and flag='0' and commdire='1';
      else
         select nvl(sum(transmoney),0) into cSumActuPayMoney from lacommision where branchseries like '%'||tdistrict||'%' and PayCount>=tPayCount and LastPayToDate>=tStartDate-60
         and lastpaytodate<=tEndDate-60 and p6='1' and transtype<>'FX'
         and payintv<>'-1' and flag='0' and commdire='1';
      end if;
      if cSumActuPayMoney+cSumDuePayMoney=0 then
        Result :=1;
      else
        Result :=cSumActuPayMoney/(cSumActuPayMoney+cSumDuePayMoney);
      end if;
else --??????????????????????????????????????????
  if tPayCount<4 then
        select nvl(sum(transmoney),0) into cActuPayMoney from lacommision where branchseries like '%'||tdistrict||'%' and PayCount=tPayCount and LastPayToDate>=tStartDate-60
        and lastpaytodate<=tEndDate-60 and p6='1' and transtype<>'FX' and payintv<>'-1'
        and TMakeDate<=add_months(tEndDate,-1) and flag='0'  and commdire='1';
  else
        select nvl(sum(transmoney),0) into cActuPayMoney from lacommision where branchseries like '%'||tdistrict||'%' and PayCount>=tPayCount and LastPayToDate>=tStartDate-60
        and calcdate is null and lastpaytodate<=tEndDate-60 and p6='1' and transtype<>'FX'
        and TMakeDate<=add_months(tEndDate,-1) and flag='0'  and commdire='1';
  end if;
  if cSumActuPayMoney+cSumDuePayMoney=0 then
    Result :=1;
  else
    Result :=cActuPayMoney/cSumActuPayMoney+cSumDuePayMoney;
  end if;
end if;

  return(Result);
end DistrictPassRate;

/
