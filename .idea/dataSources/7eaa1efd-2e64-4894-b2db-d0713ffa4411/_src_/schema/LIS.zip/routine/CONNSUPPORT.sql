CREATE FUNCTION     "CONNSUPPORT" (tAgentGrade in varchar2, tManageCom in varchar2, tWageCode in varchar2,tAgentCode in varchar2,TempBegin in date,TempEnd in date) return number is
  tMonthLimit     number(12,2):=0;
  tStandMoney     number(20,10):=0;
  tEmployDate     date;
  tIndueFormDate  date;

  tGroup          varchar2(20);
  tBranchAttr     varchar2(255);
  tStartDate      date;
  tPremiumSum     number(20,10):=0;
  tIntvl          integer:=0;
  tArrPeriod      integer:=0;
  tLinkEnd        date;
  tEDay           varchar2(2);
  tSendMons       integer:=0;
  tBaseRate       number(20,10):=0;
  tTempMon        varchar2(2);
  tEmployMon      varchar2(2);
  tArrSum         number(20,10):=0;
  LoopCount       integer:=0;
  tBeforeDate     varchar2(6);
  tF22            number(20,10):=0;
  tSumF22         number(20,10):=0;
  tArrStandMoney  number(20,10):=0;
  tAssessDate     date;
  tTempDate       date;

  tArrStandSum    number(20,10):=0;
  tArrPaySum      number(20,10):=0;
  tIndexCalNo     varchar2(6);
  tIndexCalNo1    varchar2(6);
  tBaseRate1      number(20,10):=0;


  --???????
  tAssStandSum    number(20,10):=0;
  tAssPaySum      number(20,10):=0;

  --?????????A04
  tJudgeFlag      varchar2(1);
  tManageComCond  varchar2(10);
  iCount          integer := 0;
  tYearCount      integer := 0;

  --??????
  tEmployLimit    varchar2(2);

  ResultRepay          number(20,10):=0;
  ResultCurrMonth      number(20,10):=0;
begin

  tManageComCond := trim(tManageCom);

  --??????????
  select employdate,indueformdate,agentgroup,startdate into tEmployDate,tIndueFormDate,tGroup,tStartDate from laagenttreeview
  where trim(agentcode) = trim(tAgentCode);

  tBranchAttr:=trim(getbranchattr(tGroup));

  --???????????
  if tIndueFormDate <> tEmployDate then
    return(0);
  end if;

  tJudgeFlag := doJudgeGrade(tAgentCode);
  if tJudgeFlag = 'N' then
    return(0);
  end if;

  --???????????
  select nvl(arrangeperiod,0),nvl(linkenddate,to_date('3000-01-01','yyyy-mm-dd')) into tArrPeriod,tLinkEnd
  from lalinkassess
  where tManageComCond like trim(managecom)||'%'
  and trim(agentgrade) = trim(tAgentGrade)
  ;

  --???????????????
  if TempBegin > tLinkEnd then
    return(0);
  end if;

  --?????
  tEDay := to_char(tEmployDate,'dd');

  --???????
  tTempMon := to_char(TempBegin,'mm');
  tEmployMon := to_char(tEmployDate,'mm');

  tEmployLimit := trim(getEmployLimit('EmployLimit'));
  --??15??????????????????
  if tTempMon = tEmployMon then
    if tEDay > tEmployLimit then
      return(0);
    end if;
  end if;

  if to_char(TempBegin,'yyyy') = to_char(tEmployDate,'yyyy') then
    tSendMons := tTempMon - tEmployMon + 1;
  else
    tYearCount := to_char(TempBegin,'yyyy') - to_char(tEmployDate,'yyyy');
    tSendMons := 12 - tEmployMon + 1;
    tSendMons := tSendMons + tTempMon;
    tSendMons := tSendMons + (tYearCount-1)*12;
  end if;
  if tEDay > tEmployLimit then
    tSendMons := tSendMons - 1;
  end if;

  if tSendMons <= 0 then
    return(0);
  end if;

  --?LAlinkwage???????????????
  select count(*) into iCount from lalinkwage
      where trim(payperiodtype)='01'
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode) = trim(tWageCode)
        ;
  if iCount <= 0 then
    return 0;
  end if;

  if tSendMons <= tArrPeriod then
    select count(*) into iCount from lalinkwage
      where trim(payperiodtype)='01'
        and trim(paymonth)= trim(to_char(tSendMons,'09'))
        and tManageComCond like trim(managecom)||'%'
        and trim(agentgrade) = trim(tAgentGrade)
        and trim(wagecode) = trim(tWageCode)
        ;
    if iCount <= 0 then
      return 0;
    end if;

    select BaseRate,MonthLimit,StandMoney,BaseRate1 into tArrStandMoney,tMonthLimit,tStandMoney,tBaseRate1 from lalinkwage
    where trim(payperiodtype)='01'
      and trim(paymonth)=trim(to_char(tSendMons,'09'))
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode) = trim(tWageCode)
      ;

    if tSendMons = tArrPeriod then
      select sum(baserate),sum(standmoney) into tArrStandSum,tArrPaySum from lalinkwage
      where trim(payperiodtype)='01'
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
        and trim(wagecode) = trim(tWageCode)
        ;

    end if;
  else
    --??tAgentGrade,tManageCom,tWageCode ?LALinkWage??????????
    select StandMoney,BaseRate,MonthLimit,BaseRate1 into tStandMoney,tBaseRate,tMonthLimit,tBaseRate1 from LALinkWage
    where trim(payperiodtype)='02'
      and trim(paymonth)=trim(to_char(tSendMons-tArrPeriod,'09'))
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
      and trim(wagecode) = trim(tWageCode)
      ;

    if tSendMons = tMonthLimit+tArrPeriod then
      select sum(BaseRate),sum(StandMoney) into tAssStandSum,tAssPaySum from LALinkWage
      where trim(payperiodtype)='02'
      and tManageComCond like trim(managecom)||'%'
      and trim(agentgrade) = trim(tAgentGrade)
        and trim(wagecode) = trim(tWageCode)
        ;
    end if;
  end if;


  --???????
  tIntvl := tMonthLimit + tArrPeriod;


  --??????????????????
  if tSendMons > tIntvl  then
    return(0);
  end if;


  --??????????
  tAssessDate:= getDate(tEmployDate,tArrPeriod,TempBegin);


  --?????
  if tSendMons = 1 then
    tPremiumSum := gettransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
  else
    tPremiumSum := gettransmoney(TempBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
  end if;


  --???????????????????????????????
  if tSendMons <= tArrPeriod then
    if tSendMons = tArrPeriod then
      tArrSum := gettransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      if tArrSum >= tArrStandSum then
        --????????????????
        LoopCount := tArrPeriod - 1;
        for tCount in 1..LoopCount loop
          tTempDate := add_months(TempBegin,-tCount);
          tBeforeDate := to_char(tTempDate,'yyyymm');
          ---??2004-02-18??,??LAWage???F22?????LAIndexInfo???
          ---T31??
          select nvl(T31,0) into tF22 from laindexinfo
          where trim(indextype)='01'
            and trim(indexcalno) = trim(tBeforeDate)
            and trim(agentcode) = trim(tAgentCode)
            ;
          tSumF22 := tSumF22 + tF22;
        end loop;
        ResultRepay := tArrPaySum - tSumF22;
        --return(Result);
      else
      ResultRepay:=0;    --caigang 2004-04-28??
      end if;            --
      end if;

        if tPremiumSum >= tArrStandMoney then
          ResultCurrMonth := tStandMoney;

        else
          if tPremiumSum/(tArrStandMoney)>= tBaseRate1 then
            ResultCurrMonth := tStandMoney * tPremiumSum/tArrStandMoney;
          else
            ResultCurrMonth := 0;
          end if;
        end if;

    else
      if tPremiumSum >= tArrStandMoney then
        ResultCurrMonth := tStandMoney;
      else
        if tPremiumSum/(tArrStandMoney)>= tBaseRate1 then
          ResultCurrMonth := tStandMoney * tPremiumSum/tArrStandMoney;
        else
          ResultCurrMonth := 0;
        end if;
      end if;

  end if;


  --??????????
  if tSendMons>tArrPeriod and tSendMons<=tIntvl then
    --?????
    if tSendMons = tIntvl then
      if tArrPeriod > 0 then
        tArrSum := gettransmoney(tAssessDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      else
        tArrSum := gettransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      end if;
      if tArrSum >= tAssStandSum then
        --????????????????
        tIndexCalNo := to_char(tAssessDate,'yyyymm');
        tIndexCalNo1 := to_char(TempEnd,'yyyymm');
        ---??2004-02-18??,??LAWage???F22?????LAIndexInfo???
          ---T31??
        select nvl(sum(T31),0) into tSumF22 from laindexinfo
        where trim(indextype)='01'
          and trim(IndexCalNo)>=trim(tIndexCalNo)
          and trim(IndexCalNo)<=trim(tIndexCalNo1)
          and trim(agentcode)=trim(tAgentCode)
          ;
        ResultRepay := tAssPaySum - tSumF22;
      else
      ResultRepay:=0;
      end if;
      else
      ResultRepay:=0;
      end if;

        if tPremiumSum >= tBaseRate then
          ResultCurrMonth := tStandMoney;
        else
          if tPremiumSum/(tBaseRate) >= tBaseRate1 then
            ResultCurrMonth := tStandMoney * tPremiumSum/tBaseRate;
          else
            ResultCurrMonth := 0;
          end if;
        end if;

  end if;
 if (ResultCurrMonth>ResultRepay) then
 return ResultCurrMonth;
 else
 return ResultRepay;
 end if;
end ConnSupport;

/
