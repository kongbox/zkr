CREATE FUNCTION     "CALBASEWAGE" (
       tAgentCode LABaseWage.AgentCode%TYPE
       ) return number is
  Result number;

  --??????
begin
  select decrypt(BaseWage) into Result
   from LABaseWage
   where AgentCode = tAgentCode;
  return(Result);
end CalBaseWage;

/
