CREATE FUNCTION     "CALPIECE" (
       tStartDate date, --????
       tEndDate date,   --????
       tAgentgroup Ljtempfee.Agentgroup%TYPE,
       tflag integer   --0????? 1?????
       ) return number is
tNum number;
tRiskCode Ljtempfee.Riskcode%TYPE;
tOrigin LAWageCtrlRela.Originfactor%TYPE;
tDest LAWageCtrlRela.Destfactor%TYPE;
tcount integer;
Result number:=0;
TYPE CalPieceCursor IS REF CURSOR;
t_cursor CalPieceCursor;
begin
  if tflag=0 then
     open t_cursor for
        select count(distinct(Ljtempfee.Otherno)),Ljtempfee.Riskcode
        from Ljtempfee,Lmriskapp
        where Ljtempfee.makedate>=tStartDate and Ljtempfee.makedate<=tEndDate
              and (Ljtempfee.Tempfeetype='1' or Ljtempfee.Tempfeetype='5' or Ljtempfee.Tempfeetype='6')
              and Lmriskapp.Subriskflag='M' and Ljtempfee.Riskcode=Lmriskapp.Riskcode
              and Ljtempfee.Agentgroup=tAgentgroup
              group by Ljtempfee.Riskcode;
  elsif tflag=1 then
     open t_cursor for
        select count(distinct(Ljtempfee.Otherno)),Ljtempfee.Riskcode
        from Ljtempfee,Lmriskapp
        where Ljtempfee.makedate>=tStartDate and Ljtempfee.makedate<=tEndDate
              and (Ljtempfee.Tempfeetype='1' or Ljtempfee.Tempfeetype='5' or Ljtempfee.Tempfeetype='6')
              and Lmriskapp.Subriskflag='M' and Ljtempfee.Riskcode=Lmriskapp.Riskcode
              and Lmriskapp.Riskperiod='L' and Ljtempfee.Payintv=0
              and Ljtempfee.Agentgroup=tAgentgroup
              group by Ljtempfee.Riskcode;
  end if;

  loop
      fetch t_cursor into tNum,tRiskCode;
      exit when t_cursor%notfound;
      select count(*) into tcount
       from LAWageCtrlRela
       where CtrlRelaType='01' and RiskCode=tRiskCode;
      if tcount=0 then
         Result:=Result+tNum;
      else
        select Originfactor,Destfactor into tOrigin,tDest
         from LAWageCtrlRela
         where CtrlRelaType='01' and RiskCode=tRiskCode;
          Result:=Result+tNum*(TO_NUMBER(tDest)/TO_NUMBER(tOrigin));
      end if;
  end loop;
  close t_cursor;
  return(Result);
end CALPIECE;

/
