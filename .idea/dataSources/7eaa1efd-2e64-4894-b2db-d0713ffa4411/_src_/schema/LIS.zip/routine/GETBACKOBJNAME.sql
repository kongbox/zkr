CREATE function     GetBackObjName(tPrtNo LCGrpCont.PrtNo%type) return varchar2 is
Result         varchar2(5000);
   cursor c_BackName is
   select distinct (case backobjtype
            when '1' then
             '操作员'
            when '2' then
             '客户'
            when '3' then
             '业务员'
          end) as objName
     from LCGrpIssuePol
    where proposalgrpcontno = tPrtNo
    ;
begin
    Result :=null;
    for backName in c_BackName loop
        if Result is null then
           Result :=backName.objName;
        else
           Result :=Result||'.'||backName.objName;
        end if;
       exit when c_BackName%notfound;
       end loop;
      if Result is null then
         Result:='';
      end if;
    return(Result);
end GetBackObjName;

/
