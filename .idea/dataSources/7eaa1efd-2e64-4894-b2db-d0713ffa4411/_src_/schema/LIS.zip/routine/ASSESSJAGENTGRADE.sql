CREATE FUNCTION     "ASSESSJAGENTGRADE" (
       tAgentCode latree.agentcode%Type,
       tAgentGrade latree.agentgrade%Type,
       tBranchType latree.branchtype%Type,
       tIndexCalNo lacommision.wageno%Type,
       tManageCom latree.managecom%Type
)
  return  latree.agentgrade%Type is
  Result  latree.agentgrade%Type;
  tGrade latree.agentgrade%Type;
  tAgentGrade1 latree.agentgrade%Type; --?????????
  tAreaType             char; --????
  tT27  number;
begin
   select trim(comareatype) Into tAreaType from ldcom where trim(comcode)=tManageCom;

   select T27 into tT27 from laindexinfo
   where  agentcode = tAgentCode  and  managecom = tManageCom  and  indextype ='04' and  indexcalno = tIndexCalNo;

   select  destagentgrade  into tGrade from LAAgentPromRadix2
   where  agentgrade= tAgentGrade  and  branchtype = tBranchType
   and  areatype =tAreaType and (tT27>=MarkEnd or MarkEnd is null) and (tT27<MarkBegin);

  select nvl((select trim(AgentLastGrade) from latree where trim(agentcode)=tAgentCode and trim(agentgrade)=tAgentGrade and trim(branchtype)=tBranchType
  and trim(managecom)=tManageCom and trim(branchtype2)='03'),'00')  into tAgentGrade1 from dual;
if(tAgentGrade1<>'00') then
  if (substr(tAgentGrade1,2,2)>substr(tAgentGrade,2,2)) then
      if (substr(tAgentGrade,2,2)>substr(tGrade,2,2)) then
          Result:='00';
      else
          Result:=tGrade;
      end if;
   else
       Result:=tGrade;
  end If;
else
  Result:=tGrade;
end if;

  return(Result);

end AssessJAgentGrade;

/
