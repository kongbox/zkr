CREATE FUNCTION     "DISTRICTMAGERBONUS" (tareatype in varchar2,twagecode in varchar2,tindexcalno in varchar2,tagentcode in varchar2,tBranchAttr in varchar2,tenddate in date) return number is
  Result number(12,4):=0 ;
  cRenewSum2 number(12,4):=0 ;--???????????
  cRenewSum3 number(12,4):=0 ;--???????????
  cRenewSum4 number(12,4):=0 ;--???????????
  cRatio2 number(12,4):=0 ;
  cRatio3 number(12,4):=0 ;
  cRatio4 number(12,4):=0 ;
  cPassRate2 number(12,4):=0;--??????
  cPassRate3 number(12,4):=0;--??????
  cPassRate4 number(12,4):=0;--??????
  cPassRadix2 number(12,4):=0;--???????
  cPassRadix3 number(12,4):=0;--???????
  cPassRadix4 number(12,4):=0;--???????
  cBusSum2 number(12,4):=0;--????????
  cBusSum3 number(12,4):=0;--????????
  cBusSum4 number(12,4):=0;--????????
  cEmployDate date;--?????????26?
  cmonth number(12,4):=0;--????
  cGroupMagerBonus number(12,4):=0;--????????
begin
--????????
  --select nvl(sum(t43),0),nvl(sum(t44),0),nvl(sum(t54),0) into cRenewSum2,cRenewSum3,cRenewSum4 from laindexinfo a,latree b where
  --b.upagent= tagentcode and a.agentcode=b.agentcode and indexcalno=tindexcalno and indextype='01' and a.branchtype='4' and a.branchtype2='01';

  select nvl(sum(t43),0),nvl(sum(t44),0),nvl(sum(t54),0) into cRenewSum2,cRenewSum3,cRenewSum4 from laindexinfo a
  where branchattr like tBranchAttr||'%' and indexcalno=tindexcalno and indextype='01' and a.branchtype='4' and a.branchtype2='01';
--???
  select nvl(sum(t45),1),nvl(sum(t46),1),nvl(sum(t60),1) into cPassRate2,cPassRate3,cPassRate4 from laindexinfo where agentcode =tagentcode
  and indexcalno=tindexcalno and indextype='01' and branchtype='4' and branchtype2='01';

  --????
  select nvl(sum(drawreward),1) into cRatio2 from lawageparam2 where wagecode =twagecode and paracode='WP0077'
  and areatype=tareatype;
  select nvl(sum(drawreward),1) into cRatio3 from lawageparam2 where wagecode =twagecode and paracode='WP0079'
  and areatype=tareatype;
   select nvl(sum(drawreward),1) into cRatio4 from lawageparam2 where wagecode =twagecode and paracode='WP0081'
  and areatype=tareatype;

  --??????
  select employdate into cEmployDate from laagent where agentcode=tagentcode;
  cmonth := months_between(tenddate+1,cEmployDate);

  --????
  if cmonth<=2 then
    cPassRadix2:=1;
    cPassRadix3:=1;
    cPassRadix4:=1;
  else
    select nvl(sum(drawreward),1) into cPassRadix2 from lawageparam1 where wagecode=twagecode and paracode='WP0076'
    and areatype=tareatype and lowlimit<=cPassRate2 and highlimit>cPassRate2 ;
    select nvl(sum(drawreward),1) into cPassRadix3 from lawageparam1 where wagecode=twagecode and paracode='WP0078'
    and areatype=tareatype and lowlimit<=cPassRate3 and highlimit>cPassRate3 ;
    select nvl(sum(drawreward),1) into cPassRadix4 from lawageparam1 where wagecode=twagecode and paracode='WP0080'
    and areatype=tareatype and lowlimit<=cPassRate4 and highlimit>cPassRate4 ;
  end if;
  cBusSum2:=cRenewSum2*cRatio2*cPassRadix2;

  cBusSum3:=cRenewSum3*cRatio3*cPassRadix3;

  cBusSum4:=cRenewSum4*cRatio4*cPassRadix4;
  --????????????
  select  nvl(sum(T42),0) into cGroupMagerBonus from laindexinfo where agentcode=tagentcode and indexcalno=tindexcalno
  and indextype='01' and branchtype='4' and branchtype2='01';
  Result := cBusSum2+cBusSum3+cBusSum4+cGroupMagerBonus;
  return(Result);
end DistrictMagerBonus;

/
