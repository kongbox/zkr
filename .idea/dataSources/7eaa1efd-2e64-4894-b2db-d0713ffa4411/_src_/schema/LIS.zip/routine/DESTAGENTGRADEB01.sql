CREATE FUNCTION     "DESTAGENTGRADEB01" (
       TempBegin date, --????
       TempEnd date,   --????
       tAreaType laagentpromradix1.areatype%TYPE, --????
       tChannelType laplan.plancond1%TYPE, --????
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE, -- ?????
       tIndexCalNo integer   --????
       ) return varchar2 as   --???????
v_Grade varchar2(10);--??????
StandPrem number;
begin
--??????
select DestAgentGrade into v_Grade from LAAgentPromRadix1 where
MarkEnd>(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and MarkBegin<=(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and AgentGrade=tAgentGrade and AreaType =tAreaType and ChannelType = tChannelType;--??????(??????)

if v_Grade>tAgentGrade then --??????

select sum(StandPrem) into StandPrem from LACommision where caldate>=TempBegin And caldate<=TempEnd and AgentCode=tAgentCode ;
--????????
 select max(planobject) into v_Grade from laplan where
 planperiodunit='1' and planvalue<=StandPrem and branchtype='3'
 and plancond1=tChannelType and PlanPeriod='3';
  --???????????
  if substr(tAgentGrade,2)+3<substr(v_Grade,2) then
   v_Grade:=replace(concat(substr(v_Grade,1,1),to_char(substr(tAgentGrade,2)+3,'09')),' ');
   else
   v_Grade:=tAgentGrade;
   end if;

 ELSIF v_Grade<tAgentGrade then --??????
 v_Grade:='00';--B01?????

 else
 v_Grade:=tAgentGrade;

end if;

 return v_Grade;
End DestAgentGradeB01;

/
