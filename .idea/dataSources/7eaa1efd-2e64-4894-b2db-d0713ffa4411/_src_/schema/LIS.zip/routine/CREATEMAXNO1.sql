CREATE FUNCTION     "CREATEMAXNO1" (cNoType in ldmaxno1.notype%type,
                                       cNoLimit in ldmaxno1.nolimit%type)
 return integer is
 pragma autonomous_transaction;
 tMaxNo integer := 0;  --??????

begin

    --????1
    update LDMaxNo1 set MaxNo = MaxNo+1 where NoType = cNoType and NoLimit = cNoLimit
    Returning MaxNo Into tMaxNo; --?????

    If(Sql%Notfound) then  --?????????????? 1 ???
       Insert Into LDMaxNo1 (NOTYPE,NOLIMIT,MAXNO) values(cNoType,cNoLimit,1) ;
       tMaxNo := 1;
     End If ;
     commit;
  return(tMaxNo); --????
end CreateMaxNo1;

/
