CREATE FUNCTION     "FSFDFSD" (tagentcode in varchar2) return varchar2 is
  tagentgrade varchar2(6);
begin
  select agentgrade into tagentgrade from latree where agentcode='9999999999999999999';
  if tagentgrade is null then
     return ('C');
  end if ;

end fsfdfsd;

/
