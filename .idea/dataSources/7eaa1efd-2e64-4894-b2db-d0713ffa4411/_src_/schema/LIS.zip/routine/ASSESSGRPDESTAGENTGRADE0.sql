CREATE FUNCTION     "ASSESSGRPDESTAGENTGRADE0" (
       tAgentCode latree.agentcode%Type,
       tAgentGrade latree.agentgrade%Type,
       tIndexCalNo lacommision.wageno%Type,
       tBranchType latree.branchtype%Type,
       tManageCom latree.managecom%Type,
       tTempBegin laagent.employdate%Type,
       tTempEnd laagent.employdate%Type
)
return latree.agentgrade%Type is
  Result latree.agentgrade%Type;

  lastCalNo        Varchar2(6);
  addCustom        Number;
  tCount           Integer;
  tAreaType char;
Begin
  select trim(comareatype) Into tAreaType from ldcom where trim(comcode)=tManageCom;
    If (tAgentGrade = 'T01') Then
      tCount:=months_between(to_date(tTempEnd,'yyyymm'),to_date(tTempBegin,'yyyymm'));
      If (tCount=3) then
        select distinct(a.DestAgentGrade) Into Result from LAAgentPromRadix2 a,LAIndexInfo b
                   where a.AgentGrade=tAgentGrade and a.BranchType=tBranchType and a.AreaType=tAreaType
                   and b.T1>=a.DropGrade and a.LimitPeriod='01'
                   and b.indextype='04' and b.indexcalno=tIndexCalNo;
                   If Result is null then
                   Result:='00';
                   end If;
        Else If (tCount=6) then
              select distinct(a.DestAgentGrade) Into Result from LAAgentPromRadix2 a,LAIndexInfo b
                   where a.AgentGrade=tAgentGrade and a.BranchType=tBranchType and a.AreaType=tAreaType
                   and b.T1>=a.DropGrade and a.LimitPeriod='02'
                   and b.indextype='04' and b.indexcalno=tIndexCalNo;
                   If Result is null then
                   Result:='00';
                   end If;
        End If;
       End If;

    Else
         /*Select distinct(a.DestAgentGrade) Into Result from LAAgentPromRadix2 a,LAIndexInfo b
                  where a.AgentGrade=tAgentGrade and a.BranchType=tBranchType and (a.MarkBegin is null or a.MarkBegin>b.T27)
                  and (a.MarkEnd<=b.T27 or a.MarkEnd is null) and (a.YearCode>=b.IndCustSum or a.YearCode is null)
                  and  b.IndexCalNo=tIndexCalNo and b.AgentCode=tAgentCode and b.IndexType='04';*/
         select nvl(Max(IndexCalNo),0) Into lastCalNo from LAIndexInfo  Where AgentCode=tAgentCode And indexType='04' and IndexCalNo<>tIndexCalNo;
         If (lastCalNo<>0) then
             select nvl((select a.indcustsum-b.indcustsum  from LAIndexInfo a,LAIndexInfo b
             where a.indexcalno=tIndexCalNo and b.indexcalno=lastCalno
             and a.indextype='04' and b.indextype='04' and a.agentcode=tAgentCode and b.agentcode=tAgentCode),0) Into addCustom from dual;
         Else
             select nvl((select indcustsum  from laindexinfo where agentcode=tAgentCode and indextype='04' and indexcalno=tIndexCalNo),0) Into addCustom from dual;
         End If;
     select distinct(a.DestAgentGrade) Into Result from LAAgentPromRadix2 a,LAIndexInfo b
             where a.AgentGrade=tAgentGrade and a.BranchType=tBranchType and a.AreaType=tAreaType
             and (a.MarkBegin is null or a.MarkBegin>=b.T27)
             and (a.MarkEnd is null or a.MarkEnd<=b.T27) and (a.YearCode>=addCustom or a.YearCode is null) and b.agentcode=tAgentCode
             and b.indextype='04' and b.indexcalno=tIndexCalNo;

    End If;
   Return(Result);
end  AssessGrpDestAgentGrade0;

/
