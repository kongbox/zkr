CREATE FUNCTION     "DIRADDSUCCESSCOUNT" (tagentcode in varchar2, tbranchcode in varchar2,
                                              twagenoend in varchar2,tassessway in varchar2)
                                               return integer is
----------------------------------------????????----------------------------
  cagentcode     varchar2(10);
  DirAddCount    integer;
  tcount         integer;
  cagentgrade1   varchar2(4);
  cagentgrade    varchar2(4);
  cnum           number(12,6):=0;
begin
  DirAddCount:=0;
  tcount:=0;
  declare
  cursor C_DirAddCount is
     select agentcode,agentgrade from latree
     where introagency=tagentcode
     and agentgroup=tbranchcode and state='0';

  begin
     open C_DirAddCount;
        loop
           fetch C_DirAddCount into cagentcode,cagentgrade;
           exit when C_DirAddCount%notfound;
           cnum:=0;
           ---????????
          select count(*) into cnum from laassessaccessory
          where agentcode=cagentcode and assesstype=tassessway
          and branchtype='1' and branchtype2='01'
          and indexcalno=twagenoend;
          if cnum=0 then
             if cagentgrade<'A103' then
                tcount:=0;
             else
                tcount:=1;
             end if;

           else
             select agentgrade1 into cagentgrade1 from laassessaccessory
             where agentcode=cagentcode and assesstype=tassessway
             and branchtype='1' and branchtype2='01'
             and indexcalno=twagenoend;
             if  cagentgrade1>='A103' then
                 tcount:=1;
             else
                 tcount:=0;
             end if;
          end if;
          DirAddCount:=DirAddCount+tcount;
        end loop;
     close C_DirAddCount;
  end;



  return(DirAddCount);
end DirAddSuccessCount;

/
