CREATE FUNCTION     "DEL_GRPCONTIMPORT" (tPrtNo in varchar2) return int is

aaa int;
begin
delete  from lcinsured where contno in ( select contno from lcpol where prtno=tPrtNo);
delete  from lcprem where contno in ( select contno from lcpol where prtno=tPrtNo);
delete  from lcduty where contno in ( select contno from lcpol where prtno=tPrtNo);
delete  from lcget where contno in ( select contno from lcpol where prtno=tPrtNo);
delete  from lcbnf where contno in ( select contno from lcpol where prtno=tPrtNo);
delete  from lcinsuredrelated where polno in ( select polno from lcpol where prtno=tPrtNo);
delete  from lcpol where prtno=tPrtNo;
delete  from lccont where prtno=tPrtNo;
update lcgrpcont set peoples2=0, prem=0,amnt=0 where prtno=tPrtNo;
update lcgrppol set peoples2=0, prem=0,amnt=0 where  prtno=tPrtNo;
return 1 ;
end del_GrpContImport;

/
