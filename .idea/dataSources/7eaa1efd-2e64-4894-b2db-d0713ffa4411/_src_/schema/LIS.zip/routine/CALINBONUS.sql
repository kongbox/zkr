CREATE FUNCTION     "CALINBONUS" (
       cWageNo in varchar2,
       cAgentGroup in varchar2,
       cAgentCode in varchar2)
       return number is
  tfactPrem number(12,2):=0;
  tPlanPrem number(12,2):=0;
  tSumFYC number(12,2):=0;
  tAgentGroup varchar2(12);
  tBranchAttr varchar2(70);

  sBaseWage number(13,2):=0;
  Result number(12,2):=0;

begin
     select substr(BranchAttr,1,9) into tBranchAttr from LABranchGroup
     where trim(AgentGroup)=cAgentGroup;

     select AgentGroup into tAgentGroup from LABranchGroup
     where trim(BranchAttr)=tBranchAttr;

     select sum(PlanValue) into tPlanPrem from LAPlan
     where BranchType='2' and PlanType='2'
     and trim(PlanObject)=trim(tAgentGroup) and PlanPeriodUnit=1
     and trim(PlanPeriod)=cWageNo;

     select sum(TransMoney),sum(FYC) into tfactPrem,tSumFYC
      from LACommision
      where CommDire='1' and BranchType='2'
      and trim(WageNo)=cWageNo and trim(BranchAttr) like tBranchAttr||'%';

     select sum(decrypt(a.BaseWage)) into sBaseWage
     from LABaseWage a,LATree b
     where a.BranchType = '2'
           and b.agentgrade like 'E%' and a.agentcode=b.agentcode;

      if tfactPrem<=tPlanPrem then
         Result:= (tSumFYC*0.06)*(CalBaseWage(cAgentCode)/sBaseWage);
      else
         Result:= ((tPlanPrem/tfactPrem)*tSumFYC*0.06+(1-tPlanPrem/tfactPrem)*tSumFYC*0.08)*(CalBaseWage(cAgentCode)/sBaseWage);
      end if;

  return(Result);
end CalInBonus;

/
