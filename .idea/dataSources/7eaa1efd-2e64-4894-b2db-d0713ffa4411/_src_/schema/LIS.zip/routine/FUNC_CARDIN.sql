CREATE FUNCTION     "FUNC_CARDIN"
(ManageCom in varchar2,
CertifyCode in varchar2,
SAPNo in varchar2,
CNo in varchar2,
StartNo in varchar2,
EndNo in varchar2,
SumCount in varchar2)
return varchar2 is Flag varchar2(50);

  mCertifyCode lzcard.CertifyCode%type;  --????
  mSubCode lzcard.SubCode%type;--????
  mRiskCode lzcard.RiskCode%type;
  mRiskVersion lzcard.RiskVersion%type;
  mStartNo lzcard.StartNo%type;  --?????
  mEndNo lzcard.EndNo%type;  --?????
  mSendOutCom lzcard.SendOutCom%type;  --???
  tReceiveCom lzcard.ReceiveCom%type;  --???
  mReceiveCom lzcard.ReceiveCom%type;  --???
  mSumCount lzcard.SumCount%type;  --????
  mTakeBackNo lzcard.TakeBackNo%type;
  mStateFlag lzcard.StateFlag%type;
  mOperateFlag lzcard.OperateFlag%type;
  mOperator lzcard.Operator%type;
  mMakeDate lzcard.MakeDate%type;
  mMakeTime lzcard.MakeTime%type;
  mModifyDate lzcard.ModifyDate%type;
  mModifyTime lzcard.ModifyTime%type;
  mManageCom lzcard.ManageCom%type;
  tCount number;


begin
  mCertifyCode:=CertifyCode;
  mSubCode:=SAPNo;
  mRiskCode:='000';
  mRiskVersion:='2002';
  mStartNo:=StartNo;
  mEndNo:=EndNo;
  mSendOutCom:='A%';
  mReceiveCom:=ManageCom;
  mSumCount:=SumCount;
  mTakeBackNo:=CNo;
  mStateFlag:='0';
  mOperateFlag:='0';
  mOperator:='SAP';
  mMakeDate:=substr(SYSDATE,1,10);
  mMakeTime:='00:00:00';
  mModifyDate:=mMakeDate;
  mModifyTime:='00:00:00';
  mManageCom:=substr(ManageCom,1,2);
  Flag:='0????';

  if mCertifyCode is null then
      Flag:='1???????';
      return(Flag);
  end if;
  select certifycode into mCertifyCode from LMCertifyDes where certifycode=mCertifyCode;
  if mCertifyCode is null then
      Flag:='1????????';
      return(Flag);
  end if;
  if length(mStartNo) != length(mEndNo) then
     Flag:='1???????????';
     return(Flag);
  end if;
  if mStartNo > mEndNo then
     Flag:='1??????????';
     return(Flag);
  end if;
  select 'A'||ManageCom into mReceiveCom from dual;
  if mReceiveCom is null then
     Flag:='1?????????';
     return(Flag);
  end if;
  SELECT count(*) into tCount FROM LZCard WHERE CertifyCode=mCertifyCode AND StateFlag = '0' /*AND ReceiveCom = mReceiveCom */
  AND StartNo <= mStartNo AND EndNo >= mStartNo
  AND StartNo <= mEndNo AND EndNo >= mEndNo AND length(StartNo)=length(mStartNo) and ManageCom like mManageCom||'%';
  if tCount>0 then
     Flag:='1??????????????';
     return(Flag);
  end if;
  if length(ManageCom)=2 then

     insert into LZCard ( CertifyCode,SubCode,RiskCode,RiskVersion,StartNo,EndNo,SendOutCom,ReceiveCom,SumCount,Prem,Amnt,
     HandleDate,TakeBackNo,StateFlag,OperateFlag,Operator,MakeDate,MakeTime,ModifyDate,ModifyTime,managecom)
     values (mCertifyCode,mSubCode,mRiskCode,mRiskVersion,mStartNo,mEndNo,mSendOutCom,mReceiveCom,mSumCount,0.0,0.0,
     mMakeDate,mTakeBackNo,mStateFlag,mOperateFlag,mOperator,mMakeDate,mMakeTime,mModifyDate,mModifyTime,mManageCom);

     insert into LZCardTrack ( CertifyCode,SubCode,RiskCode,RiskVersion,StartNo,EndNo,SendOutCom,ReceiveCom,SumCount,Prem,Amnt,
     HandleDate,TakeBackNo,Stateflag,OperateFlag,Operator,MakeDate,MakeTime,ModifyDate,ModifyTime,managecom)
     values (mCertifyCode,mSubCode,mRiskCode,mRiskVersion,mStartNo,mEndNo,mSendOutCom,mReceiveCom,mSumCount,0.0,0.0,
     mMakeDate,mTakeBackNo,mStateFlag,mOperateFlag,mOperator,mMakeDate,mMakeTime,mModifyDate,mModifyTime,mManageCom);
     commit;

  Flag:='0????';
  elsif length(ManageCom)=4 then
  select 'A'||substr(ManageCom,1,2) into tReceiveCom from dual;

    insert into LZCard ( CertifyCode,SubCode,RiskCode,RiskVersion,StartNo,EndNo,SendOutCom,ReceiveCom,SumCount,Prem,Amnt,
    HandleDate,TakeBackNo,StateFlag,OperateFlag,Operator,MakeDate,MakeTime,ModifyDate,ModifyTime,managecom)
    values (mCertifyCode,mSubCode,mRiskCode,mRiskVersion,mStartNo,mEndNo,tReceiveCom,mReceiveCom,mSumCount,0.0,0.0,
    mMakeDate,mTakeBackNo,mStateFlag,mOperateFlag,mOperator,mMakeDate,mMakeTime,mModifyDate,mModifyTime,mManageCom);

    insert into LZCardTrack ( CertifyCode,SubCode,RiskCode,RiskVersion,StartNo,EndNo,SendOutCom,ReceiveCom,SumCount,Prem,Amnt,
    HandleDate,TakeBackNo,Stateflag,OperateFlag,Operator,MakeDate,MakeTime,ModifyDate,ModifyTime,managecom)
    values (mCertifyCode,mSubCode,mRiskCode,mRiskVersion,mStartNo,mEndNo,mSendOutCom,tReceiveCom,mSumCount,0.0,0.0,
    mMakeDate,mTakeBackNo,mStateFlag,mOperateFlag,mOperator,mMakeDate,mMakeTime,mModifyDate,mModifyTime,mManageCom);

    insert into LZCardTrack ( CertifyCode,SubCode,RiskCode,RiskVersion,StartNo,EndNo,SendOutCom,ReceiveCom,SumCount,Prem,Amnt,
    HandleDate,TakeBackNo,Stateflag,OperateFlag,Operator,MakeDate,MakeTime,ModifyDate,ModifyTime,managecom)
    values (mCertifyCode,mSubCode,mRiskCode,mRiskVersion,mStartNo,mEndNo,tReceiveCom,mReceiveCom,mSumCount,0.0,0.0,
    mMakeDate,mTakeBackNo,mStateFlag,mOperateFlag,mOperator,mMakeDate,mMakeTime,mModifyDate,mModifyTime,mManageCom);
    commit;

  Flag:='0????';
  else
   Flag:='1?????????';
  end if;
  return(Flag);
end func_cardin;

/
