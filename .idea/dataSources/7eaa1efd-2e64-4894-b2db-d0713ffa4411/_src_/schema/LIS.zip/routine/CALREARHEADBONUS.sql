CREATE FUNCTION     "CALREARHEADBONUS" (tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,TempBegin in date, TempEnd in date) return number is
  FYC1   number := 0;
  tFYC   number := 0;
  Result number := 0;
  tDrawRate  number := 0;

  cursor d_View is
    select branchattr from labranchgroup
    where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
            and CommBreakFlag='0'
            and AgentGrade='A08'
            and trim(RearAgentCode)= trim(tAgentCode)
            )
           and EndFlag<>'Y'
           and branchlevel='03'
           ;

begin

  for v_View in d_View Loop
    ---tjj change 0101---
    ---tBranchAttr:= getbranchattr(v_View.agentgroup);
    select nvl(sum(fyc),0) into tFYC from lacommision
      where CommDire='1'
            and payyear <1
            and caldate>=TempBegin
            and caldate<=TempEnd
            and trim(branchattr) like concat(trim(v_View.BranchAttr),'%');
    FYC1 := nvl(tFYC,0) + FYC1;
  end Loop;


  select nvl(drawrate,0) into tDrawRate from lawageradix
  where trim(AreaType)=trim(tAreaType)
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode);

  Result := FYC1 * tDrawRate;

  return(Result);
end CALREARHEADBONUS;

/
