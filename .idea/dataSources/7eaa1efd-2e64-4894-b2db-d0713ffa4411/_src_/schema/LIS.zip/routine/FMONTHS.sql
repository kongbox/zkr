CREATE FUNCTION     "FMONTHS" (Day1 in date,Day2 in date) return varchar2 is
  Result float;
  --?????/12
begin
  select mod(floor(months_between(Day1,day2)),12)/12 into Result from Dual;
  return(Result);
end FMonths;

/
