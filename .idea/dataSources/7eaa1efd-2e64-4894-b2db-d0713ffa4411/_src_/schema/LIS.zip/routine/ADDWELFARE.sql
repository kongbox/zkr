CREATE FUNCTION     "ADDWELFARE" (tagentcode in varchar2, tareatype in varchar2,
                                     tmanagecom in varchar2) return number is
  taddwelfare       number(20,6):=0;
  tDrawBase        lawelfareradix.drawbase%type;
  tDrawRate        lawelfareradix.drawrate%type;
  checknum         integer;
begin
---????????????
 select count(*) into checknum from  LAWelfareRadix
where ManageCom=tManageCom and ObjectType='1' and ObjectCode=tAgentcode and AClass='06' and State='1';
if checknum<>1 then
   return(0);
end if;

 /* select nvl(T27,0)-nvl(T17,0)-nvl(T18,0)-nvl(T19,0)-nvl(T20,0)-nvl(T21,0)
        -nvl(T22,0)-nvl(T23,0)-nvl(T49,0) into tleftmoney
  from laindexinfo where agentcode=tagentcode and indexcalno=twageno and indextype='01'
  and branchtype='1' and branchtype2='01';*/

  select nvl(DrawBase,0),nvl(DrawRate,0) into tDrawBase,tDrawRate from LAWelfareRadix
  where ObjectType='1' and ObjectCode=tagentcode
  and ManageCom=tareatype and Aclass='05' and state='1';
  ---???????????????
  taddwelfare:=tDrawBase*tDrawRate;
 /* ---??????
  if tleftmoney< taddwelfare then
     return 0;
  else */
     return (taddwelfare);
 /* end if; */

end AddWElFARE;

/
