CREATE FUNCTION     "CALGRPCURRMONEY" (tAgentCode laagent.agentcode%type,
  tIndexCalNo in varchar2)
  return number is
  Result number;


begin
  select nvl(InitPension,0)  --????
  +nvl(FirstPension,0)       --????
/*  +nvl(PersonBonus,0)        --??/??/?????*/
/* +nvl(T1,0)                 --????*/
  +nvl(T29,0)                --???
  +nvl(SpecialPension,0)     --??????
/*  +nvl(DepDirManaSdy,0)      --?????*/
/*  +nvl(PosSdy,0)             --????*/
  +nvl(T2,0)                 --???
/*  -nvl(T28,0)                --??????*/

  +nvl(T68,0) --?????
  +nvl(T1,0)   --?????
  +nvl(DepDirManaSdy,0)   --?????????
  +nvl(T69,0)  --?????
  +nvl(T70,0)  --?????
  into Result from laindexinfo
  where agentcode = tAgentCode
  and indextype='01'
  and indexcalno=tIndexCalNo;

  return(Result);
end calgrpcurrmoney;

/
