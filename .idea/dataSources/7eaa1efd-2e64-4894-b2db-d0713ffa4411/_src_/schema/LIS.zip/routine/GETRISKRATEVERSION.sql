CREATE FUNCTION     "GETRISKRATEVERSION" (
       --?????
       tScanDate date,   --????
       tRiskCode laratecommision.riskcode%type,
       tBranchType lacommision.branchtype%type
       ) return varchar as   --???????
result varchar(2);
begin
if (tRiskCode='112203' and tBranchType='1')
then
if (tScanDate>to_date('2004-08-25','yyyy-MM-dd'))
then
   result:='12';
 else
  result:='11';
end if;
else
  result:='11';
end if;

return result;

End ;

/
