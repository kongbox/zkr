CREATE FUNCTION     "DEGRADERATE" (twagenoend in varchar2, tbranchcode in varchar2) return number  is
--------------------?????-------------------------------
  DeGradeRate  number(12,6):=0;
  num          Integer;
  cnum         Integer;
begin
 ---??????????
  select count(distinct agentcode) into num from laassessaccessory
  where IndexCalNo=twagenoend and assesstype='00' and agentgroup=tbranchcode;
  ---?????????
  select count(distinct agentcode) into cnum from laassessaccessory
  where IndexCalNo=twagenoend and assesstype='00' and agentgroup=tbranchcode
  and agentgrade1<agentgrade and agentgrade1<>'00';

  DeGradeRate:=cnum/num;
  return(DeGradeRate);
end DeGradeRate;

/
