CREATE FUNCTION     "ADDBONUS" (tagentcode in varchar2,
                                    tareatype in varchar, twagecode in varchar2,
                                    twageno in varchar,
                                    tbranchtype lawageradix.branchtype%type,tbranchtype2 in varchar2,
                                    tagentgrade in varchar2,tAgentState in varchar2)  return number is


cdrawrate          number(20,6):=0;
cdrawstart         integer;
cdrawend           integer;
cInitPensionSum    number(20,6):=0;
Result             number(20,6):=0;
/*cED                varchar2(8);
ED                 date;*/
 ---?????
begin
    ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;

  select nvl(drawrate,0),nvl(drawstart,0),nvl(drawend,0) into cdrawrate,cdrawstart,cdrawend from lawageradix
  where agentgrade=tagentgrade and wagecode=twagecode and areatype=tareatype
  and branchtype=tbranchtype and branchtype2=tbranchtype2;

  select sum(nvl(a.IndFYCSum,0)) into cInitPensionSum from laindexinfo a
  where exists (select 'X' from latree where IntroAgency=tagentcode  and agentcode=a.agentcode and state='0')
        and a.indextype='00'  and branchtype='1' and branchtype2='01'
        and a.addcount>=cdrawstart
        and a.addcount<=cdrawend
        and a.indexcalno=twageno;

  Result:=cInitPensionSum*cdrawrate;
  return(Result);
end AddBonus;

/
