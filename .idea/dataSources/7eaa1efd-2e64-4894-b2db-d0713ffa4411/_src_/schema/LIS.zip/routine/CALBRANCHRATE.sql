CREATE FUNCTION     "CALBRANCHRATE" (
       tWageNo in varchar2,
       tAgentGroup in varchar2)
       return number is
  tPlan number;
  Result number;
begin
  select PlanValue into tPlan
   from LAPlan
   where PlanPeriodUnit=1
    and BranchType='3' and PlanType='2'
    and trim(PlanPeriod)=trim(tWageNo)
    and trim(PlanObject)=trim(tAgentGroup);
  Result := BranchCompass(tWageNo,tAgentGroup)/tPlan;
  return(Result);
end CalBranchRate;

/
