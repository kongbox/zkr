CREATE function fixAcc4   return varchar2 is
   Result varchar2(50);
   tFixGrpContno varchar2(50); --从lctempinteresttraceFix2取出需要处理的保单号
   tMaxBaladate date;          --最大补结息日期
   tFixCE number;              --需要修复的金额
   PRAGMA AUTONOMOUS_TRANSACTION;
begin

FOR FixGrpContno  IN (
                  select grpcontno,Fixce from lctempinteresttraceFix2 where acctype = '1' and Fixce > 0
              ) LOOP
              tFixGrpContno := FixGrpContno.Grpcontno;
              tFixCE:=FixGrpContno.Fixce;

              select max(Balastartdate) into tMaxBaladate from lctempinteresttraceFix where  grpcontno= tFixGrpContno;

              --插入需要更新的明细记录
              insert into lctempinteresttraceFix4
              select  grpcontno,
                      POLNO,
                      SERIALNO,
                      INSUACCNO,
                      RISKCODE,
                      dqrate,
                      balastartdate,
                      balaenddate+1 balaenddate,
                      baladays,
                      yearbaladays,
                      yearbaladate,
                      balamoney oldbalamoney,
                      tFixCE newbalamoney,
                      dqinterest,
                      round(tFixCE * dqrate / yearbaladays * baladays,2) dqinterestXG
                      from lctempinteresttrace where grpcontno=tFixGrpContno and insuaccno='260001' and Balastartdate > tMaxBaladate and DQInterest=0;



                      --需要修复的总和
                      insert into lctempinteresttraceFix5
                      select  grpcontno,
                      POLNO,
                      SERIALNO,
                      INSUACCNO,
                      RISKCODE,
                      dqrate,
                      balastartdate,
                      balaenddate,
                      baladays,
                      yearbaladays,
                      yearbaladate,
                      oldbalamoney,
                      newbalamoney,
                      dqinterest,
                      (select sum(dqinterestXG) from lctempinteresttraceFix4 where  grpcontno=tFixGrpContno)dqinterestXG
                      from lctempinteresttraceFix4 where grpcontno=tFixGrpContno;

    END LOOP;
   commit;
  Result := '执行完毕';
  return(result);
  end fixAcc4;
/
