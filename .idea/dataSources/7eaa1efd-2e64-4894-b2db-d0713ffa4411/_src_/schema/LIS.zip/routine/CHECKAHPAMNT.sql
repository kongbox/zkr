CREATE function     checkAHPAmnt(contNo1 in varchar2,polNo1 in varchar2,edorNo1 in varchar2) return  varchar2 is
 result varchar2(2);-- 返回的结果 1 true   else  false
 amntLimit number;--意外险的保额上限
 occFlag varchar2(3);--该被保险人的职业类别
 amntFlag varchar2(3);
 insuredNo1 varchar2(20);
 cvaildate1 lcpol.cvalidate %type;
 amnt number; --该被保人的累计意外险保额；
 amnt1 number;--意外险 lcpol中的保险金额
 amnt2 number;-- 交通意外险中汽车责任中保额较高的累计之和
 amnt3 number;--保全增额意外险 lppol中的保险金额
 amnt4 number;-- 保全增额交通意外险中汽车责任中保额较高的累计之和

 begin
    Result:=null;--初始化result值
 --先判断这个人是否购买了意外险 若没有直接返回 null
    select count(*) into amntFlag from lcpol cp
       where cp.polno = polNo1
           and exists (select 1 from lmriskapp where risktype = 'A' and SubRiskFlag = 'M' and riskcode = cp.riskcode);
    if (amntFlag=0) then
       return result;
    end if;
    select nvl(occupationtype,0),nvl(insuredno,'0000000000') into occFlag,insuredNo1 from lcinsured where contno = contNo1 and grpcontno = (select grpcontno from lccont where contno = contNo1);
    if occFlag =1 then amntLimit:= 10000000;
      elsif occFlag =2 then amntLimit:= 5000000;
      elsif occFlag =3 then amntLimit:= 1000000;
      elsif occFlag =4 then amntLimit:= 600000;
      elsif (occFlag =5 or occFlag=6) then amntLimit:= 200000;
      else amntLimit:= 0;
    end if;
    select nvl(cvalidate,to_date('2000/01/01','YYYY/MM/DD')) into cvaildate1 from lcpol where polno=polNo1;
 -- 存在lcpol中   只存身故险
    select nvl(sum(nvl(amnt, 0) / (case insuredpeoples
                                           when 0 then
                                            1
                                           else
                                            insuredpeoples
                                         end)),
                     0) into amnt1
            from lcpol a
           where insuredno = insuredNo1
             and a.OccupationType = occFlag
             and appflag in ('0', '1', '2')
             and (uwflag not in ('1', 'a') or uwflag is null)
             and grppolno not in (select proposalno from lcapplyrecallpol) --lcapplyrecallpol  撤单申请表
             and riskcode in (select riskcode
                                from lmriskapp
                               where risktype = 'A'
                                 and SubRiskFlag = 'M')
             and enddate > cvaildate1
             and a.polno<>polNo1
             and riskcode not in
                 ('40041413', '70041413', '40040704', '70040803');
 --交通意外险只累计 汽车责任中较高的 保额
  select nvl(sum(max(cd.amnt)), 0)
    into amnt2
    from lcpol cp, lcduty cd
   where cp.polno = cd.polno
     and cp.riskcode in ('40041413', '70041413','40040704','70040803')
     and cd.dutycode in ('903104', '903105', '702504', '702505','901401','901801','701401')
     and (cp.uwflag not in ('1', 'a') or cp.uwflag is null)
     and appflag in ('0', '1', '2')
     and cp.grppolno not in (select proposalno from lcapplyrecallpol)
     and cp.riskcode in (select riskcode
                           from lmriskapp
                          where risktype = 'A'
                            and SubRiskFlag = 'M')
     and cp.enddate >cvaildate1
     and cp.insuredno = insuredNo1
     and cp.occupationtype = occFlag
     and cp.polno<>polNo1
   group by cd.polno;


   -- 存在lppol中   只存身故险
    select nvl(sum(nvl(amnt, 0) / (case insuredpeoples
                                           when 0 then
                                            1
                                           else
                                            insuredpeoples
                                         end)),
                     0) into amnt3
            from lppol a
           where polno=polNo1
           and edorno=edorNo1
           and riskcode in (select riskcode
                                from lmriskapp
                               where risktype = 'A'
                                 and SubRiskFlag = 'M')
             --and enddate > cvaildate1
             and riskcode not in
                 ('40041413', '70041413', '40040704', '70040803');
 --交通意外险只累计 汽车责任中较高的 保额
  select nvl(sum(max(cd.amnt)), 0)
    into amnt4
    from lppol cp, lpduty cd
   where cp.polno = cd.polno
     and cp.riskcode in ('40041413', '70041413','40040704','70040803')
     and cd.dutycode in ('903104', '903105', '702504', '702505','901401','901801','701401')
     and cp.riskcode in (select riskcode
                           from lmriskapp
                          where risktype = 'A'
                            and SubRiskFlag = 'M')
     --and cp.enddate >cvaildate1
     and cp.polno=polNo1
     and cp.edorno=edorNo1
   group by cd.polno;
--该被保人的意外险的保额为和
        amnt:= amnt1+amnt2+amnt3+amnt4;
     if(amnt>amntLimit) then
        result := 1;
      end if;
     return (result);

   end checkAHPAmnt;

/
