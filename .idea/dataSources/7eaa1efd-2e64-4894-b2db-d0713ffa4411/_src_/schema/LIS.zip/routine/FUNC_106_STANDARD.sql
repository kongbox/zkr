CREATE FUNCTION     "FUNC_106_STANDARD" (Je_gf in number) return number is
  Result number;
  tJe_gf number;
begin
  tJe_gf:=Je_gf;
  if tJe_gf<=1000 then
    select tJe_gf*0.55 into Result from dual;
  elsif tJe_gf>1000 and tJe_gf<=5000 then
    select 550+(tJe_gf-1000)*0.6 into Result from dual;
  elsif tJe_gf>5000 and tJe_gf<=10000 then
    select 2950+(tJe_gf-5000)*0.7 into Result from dual;
  elsif tJe_gf>10000 and tJe_gf<=30000 then
    select 6450+(tJe_gf-10000)*0.8 into Result from dual;
  else
    select 22450+(tJe_gf-30000)*0.95 into Result from dual;
  end if;
  return(Result);
end func_106_standard;

/
