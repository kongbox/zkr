CREATE FUNCTION     "CHARGEBONUS" (tareatype in varchar2,twagecode in varchar2,tindexcalno in varchar2,tagentcode in varchar2,tpaycount in varchar2) return number is
  Result number(12,4):=0;
  cPassRate2 number(12,4):=0;--?????
  cPassRate3 number(12,4):=0;--?????
  cPassRate4 number(12,4):=0;--4????
  cPassRateWage2 number(12,4):=0;--???????
  cPassRateWage3 number(12,4):=0;--???????
  cPassRateWage4 number(12,4):=0;--4??????
  cDifficulty number(12,4):=0;--????
  cDifficultyRatio number(12,4):=0;--?????????
  cDueCount2 latollwageradix.receive2%type;--??????
  cDueCount3 latollwageradix.receive2%type;--??????
  cDueCount4 latollwageradix.receive2%type;--4?????
  cJustRatio2 number(12,4):=0;--????
  cJustRatio3 number(12,4):=0;--????
  cJustRatio4 number(12,4):=0;--????
begin
  select nvl(sum(difficulty),1) into cDifficulty from latree where agentcode=tagentcode;


  --???
  if tpaycount='2' then

  select T49,IndFYCSum into cDueCount2,cPassRate2 from laindexinfo
  where indexcalno=tindexcalno and indextype='01' and agentcode=tagentcode and branchtype='1' and branchtype2='01';

  select nvl(sum(drawreward),0) into cPassRateWage2 from lawageparam1 where wagecode =twagecode and paracode='WP0084'
  and lowlimit<=cPassRate2 and highlimit>cPassRate2 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio2 from lawageparam1 where wagecode =twagecode and paracode='WP0086'
  and lowlimit<=cDueCount2 and highlimit>cDueCount2 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode=twagecode and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;
  Result := (cPassRateWage2*cJustRatio2)*cDifficultyRatio;
  end if;

  if tpaycount='3' then

  select T50,MonAvgFYC into cDueCount3,cPassRate3 from laindexinfo
  where indexcalno=tindexcalno and indextype='01' and agentcode=tagentcode and branchtype='1' and branchtype2='01';

  select nvl(sum(drawreward),0) into cPassRateWage3 from lawageparam1 where wagecode =twagecode and paracode='WP0085'
  and lowlimit<=cPassRate3 and highlimit>cPassRate3 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio3 from lawageparam1 where wagecode =twagecode and paracode='WP0087'
  and lowlimit<=cDueCount3 and highlimit>cDueCount3 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode=twagecode and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;

  Result := (cPassRateWage3*cJustRatio3)*cDifficultyRatio;
  end if;

  if tpaycount='4' then

  select T61,T53 into cDueCount4,cPassRate4 from laindexinfo
  where indexcalno=tindexcalno and indextype='01' and agentcode=tagentcode and branchtype='1' and branchtype2='01';

  select nvl(sum(drawreward),0) into cPassRateWage4 from lawageparam1 where wagecode =twagecode and paracode='WP0088'
  and lowlimit<=cPassRate4 and highlimit>cPassRate4 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cJustRatio4 from lawageparam1 where wagecode =twagecode and paracode='WP0089'
  and lowlimit<=cDueCount4 and highlimit>cDueCount4 and areatype=tareatype;

  select nvl(sum(drawreward),1) into cDifficultyRatio from lawageparam2 where wagecode=twagecode and paracode='WP0090'
  and areatype=tareatype and associateobj=cDifficulty;

  Result := (cPassRateWage4*cJustRatio4)*cDifficultyRatio;
  end if;


  return(Result);
end ChargeBonus;

/
