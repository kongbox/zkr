CREATE FUNCTION     "GETPARENTCOM" (cComCode in varchar2)
return varchar2 as
tComCodeISC varchar2(10);
tParentComCodeISC varchar2(10);
begin
select max(ComCodeISC) into tComCodeISC from LFComToISCCom where trim(ComCode)=trim(cComCode);
select max(ParentComCodeISC) into tParentComCodeISC from LFComISC where trim(ComCodeISC)= trim(tComCodeISC);
return(tParentComCodeISC);
end;

/
