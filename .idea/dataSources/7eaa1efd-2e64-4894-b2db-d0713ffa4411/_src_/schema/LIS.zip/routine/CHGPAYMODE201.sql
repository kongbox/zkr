CREATE FUNCTION     "CHGPAYMODE201" (paymode in varchar2) return varchar2
is
tR varchar2(20);
begin
 if paymode = '0' then
  tR := '12';
 else
  tR := paymode;
 end if;

 return(tR);
end;

/
