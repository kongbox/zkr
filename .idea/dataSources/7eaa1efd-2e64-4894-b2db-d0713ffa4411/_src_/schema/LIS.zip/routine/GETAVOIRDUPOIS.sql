CREATE FUNCTION     "GETAVOIRDUPOIS" (ContNo1 char, CustomerNo1 char) return integer is
  Result integer;
begin
  select ImpartParam into result from LCCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 And Impartver='02' and Impartcode='000' and ImpartParamNo='2';
  return(Result);
end GetAvoirdupois;

/
