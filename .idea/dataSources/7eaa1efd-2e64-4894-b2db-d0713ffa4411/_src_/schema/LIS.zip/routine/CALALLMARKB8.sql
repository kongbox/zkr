CREATE FUNCTION     "CALALLMARKB8" (tAgentCode  Laagent.Agentcode%TYPE,
                                        tAgentGrade latree.agentgrade%type,
                                        tIndexCalNo in varchar2
                                        ) return number is
  Result number;
  rate26 number(12, 2);
  mark26 number := 0;
  rate25 number(12, 2);
  mark25 number := 0;
  rate24 number(12, 2);
  mark24 number := 0;
  rate23 number(12, 2);
  mark23 number := 0;
  v_IsManager boolean := false; --?????????
  v_Count integer;
  assessmark number := 0;

begin
  --?????????????
  select count(*) into v_Count from labranchgroup
  where EndFlag<>'Y'
    		and branchlevel='3'
    		and  trim(branchManager) = tAgentCode ;
  if v_Count > 0 then
    v_IsManager := true;
  end if;

if v_IsManager then
  --???????
  select NVL(T26, 0),NVL(T25, 0) into rate26,rate25 from LAIndexInfo
   where trim(IndexCalNo) = tIndexCalNo and IndexType='04' and agentcode = tAgentCode;

  select NVL(Mark, 0) into mark26 from LARateToMark
   where StartRate <= rate26 and EndRate > rate26 and RateType = '05' and AgentGrade = tAgentGrade;

  --???????
  select NVL(Mark, 0) into mark25 from LARateToMark
   where StartRate <= rate25 and EndRate > rate25 and RateType = '06' and AgentGrade = tAgentGrade;

    --???????
    select NVL(T24, 0),NVL(T23, 0) into rate24,rate23 from LAIndexInfo
     where trim(IndexCalNo) = tIndexCalNo and agentcode = tAgentCode ;

    select NVL(Mark, 0) into mark24 from LARateToMark
     where StartRate <= rate24 and EndRate > rate24 and RateType = '03' and AgentGrade = tAgentGrade;

    --???????
    select NVL(Mark, 0) into mark23 from LARateToMark
     where StartRate <= rate23 and EndRate > rate23 and RateType = '04' and AgentGrade = tAgentGrade;

    select NVL(sum(AssessMark), 0) into assessmark from LAAssessMark
     where assessym=tIndexCalNo and assessmarktype='03' and AgentCode = tAgentCode;

 else
 --???????
  select NVL(T26, 0),NVL(T25, 0) into rate26,rate25 from LAIndexInfo
   where trim(IndexCalNo) = tIndexCalNo and IndexType='04' and agentcode = tAgentCode;

  select NVL(Mark, 0) into mark26 from LARateToMark
   where StartRate <= rate26 and EndRate > rate26 and RateType = '05' and AgentGrade = 'B07';

  --???????
  select NVL(Mark, 0) into mark25 from LARateToMark
   where StartRate <= rate25 and EndRate > rate25 and RateType = '06' and AgentGrade = 'B07';

   select NVL(sum(AssessMark), 0) into assessmark from LAAssessMark
     where AgentCode = tAgentCode And assessym=tIndexCalNo and assessmarktype='04';

end if;

  Result := mark26 + mark25 + mark24 + mark23 + assessmark;

  return(Result);
end CALALLMARKB8;

/
