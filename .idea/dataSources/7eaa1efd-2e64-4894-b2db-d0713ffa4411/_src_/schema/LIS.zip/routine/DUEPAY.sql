CREATE FUNCTION     "DUEPAY" (tagentobj in varchar2, tstartdate in date,tenddate in date,tpaycount lacommision.paycount%type
,tflag in varchar2) return number is
  Result number(12,4):=0 ;
  --tflag=1 ?????=0 ????

begin
   --???????????????? ?????? ,lacommision.commdate??????????????????
  if tflag='1' then
     if tpaycount<4  then
        select nvl(sum(a.sumDuePayMoney),0) into Result from ljspayperson a,lacommisiondetail b
        where a.agentcode = tagentobj and PayCount=tPayCount
        and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
        and b.poltype='1' and a.payintv<>-1 and not exists(select 1 from lacommision c where a.contno=c.contno
        and c.flag='2' and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
        return Result;
     else
        select nvl(sum(a.sumDuePayMoney),0) into Result from ljspayperson a,lacommisiondetail b
        where a.agentcode = tagentobj and PayCount>=tPayCount
        and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
        and b.poltype='1' and a.payintv<>-1 and not exists (select 1 from lacommision c where a.contno=c.contno
        and c.flag='2'and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
     end if;
   else--????
     if tpaycount<4  then
        select count(distinct a.contno) into Result from ljspayperson a,lacommisiondetail b
        where a.agentcode = tagentobj and PayCount=tPayCount
        and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
        and b.poltype='1' and a.payintv<>-1 and not exists (select 1 from lacommision c where a.contno=c.contno
        and c.flag='2'and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
        return Result;
     else
        select count(distinct a.contno) into Result from ljspayperson a,lacommisiondetail b
        where a.agentcode = tagentobj and PayCount>=tPayCount
        and LastPayToDate>=tstartdate-60 and lastpaytodate<=tEndDate-60 and a.contno=b.grpcontno
        and b.poltype='1' and a.payintv<>-1 and not exists (select 1 from lacommision c where a.contno=c.contno
        and c.flag='2'and c.commdate>=tStartDate-60 and c.commdate<=tenddate);
     end if;
   end if;

  return(Result);
end DuePay;

/
