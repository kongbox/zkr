CREATE FUNCTION     "FUNC_106CLAIM" (CaseNo in varchar2,GrpContNo in varchar2,ContType in char,ContPlanCode in char,DutyCode in varchar2,CustomerNo in varchar2,PolNo in varchar2,TotalInHosJe_gf in number) return number is
  Result number;
  --?????????
  tCaseNo        llcasereceipt.caseno%type;
  --????
  tTotalInHosJe_gf      number;
  --????????
  tInHosJe_gf    number;
  --??????????
  tGrpContNo     lldutyctrl.grpcontno%type;
  --?????
  tDutyCode      lldutyctrl.dutycode%type;
  --????
  tContType      lldutyctrl.conttype%type;
  --????
  tContPlanCode  lldutyctrl.contplancode%type;
  --??????
  t1             integer;
  t2             integer;
  tInhosExempt   lldutyctrl.inhosexempt%type;
  --?????
  tExempt        lldutyctrl.exempt%type;
  --?????
  tUnifyClaimRate lldutyctrl.unifyclaimrate%type;
  --??????
  tInHosClaimRate lldutyctrl.inhosclaimrate%type;
  --??????
  tJe_gf          number;
  --????????
  tTotalJe_gf     number;
  --?????????????????????
  tCustomerNo     llcase.customerno%type;
  --?????
  tPolNo          lcget.polno%type;
  tsumexempt      llclaimdutyfee.outdutyamnt%type;

begin
  --????????
  tCaseNo:=CaseNo;
  tTotalInHosJe_gf:=TotalInHosJe_gf;
  tInHosJe_gf:=0;
  tTotalJe_gf:=tTotalInHosJe_gf;
  tJe_gf:=0;
  tGrpContNo:=GrpContNo;
  tDutyCode:=DutyCode;
  tContType:=ContType;
  tContPlanCode:=ContPlanCode;
  t1:=0;
  t2:=0;
  tInhosExempt:=0;
  tExempt:=0;
  tUnifyClaimRate:=0;
  tInHosClaimRate:=0;
  tCustomerNo:=CustomerNo;
  Result:=0;
  tPolNo:=PolNo;
  tsumexempt:=0;

  select sum(AdjSum) into tInHosJe_gf from LLCaseReceipt where trim(FeeItemType) = 'B' and CustomerNo=tCustomerNo and caseno=tCaseNo;
  --??????????
  if tInHosJe_gf is null then
      tInHosJe_gf:=0;
  end if;
  tJe_gf:=tInHosJe_gf;
  select count(*) into t1 from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode and (exempt<>-1 or ClinicExempt<>-1 or InhosExempt<>-1);
  --????????????
  if t1=0 then
  --???????????????????????
      select count(*) into t1 from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0' and (exempt<>-1 or ClinicExempt<>-1 or InhosExempt<>-1);
      if t1=0 then
      --????????????????????
          select count(*) into t2 from lldutyctrllevel where contno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode;
          if t2=0 then
              select count(*) into t2 from lldutyctrllevel where contno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0';
              if t2=0 then
                 --???????????????????????????
                 select func_106_standard(tTotalJe_gf)-func_106_standard(tTotalJe_gf-tJe_gf) into Result from dual;
              else
                 select fun_claimctrl(tTotalJe_gf,tGrpContNo,tDutyCode,tContType,'0')-fun_claimctrl(tTotalJe_gf-tJe_gf,tGrpContNo,tDutyCode,tContType,'0') into Result from dual;
              end if;
          return(Result);
          else
             --??????????????????????
              select fun_claimctrl(tTotalJe_gf,tGrpContNo,tDutyCode,tContType,tContPlanCode)-fun_claimctrl(tTotalJe_gf-tJe_gf,tGrpContNo,tDutyCode,tContType,tContPlanCode) into Result from dual;
          return(Result);
          end if;
       else
       --???????????????
          select InhosExempt into tInhosExempt from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0';
          select Exempt into tExempt from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0';
          select UnifyClaimRate into tUnifyClaimRate from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0';
          select InHosClaimRate into tInHosClaimRate from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode='0';
       end if;
  else
  --????????????????
      select InhosExempt into tInhosExempt from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode;
      select Exempt into tExempt from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode;
      select UnifyClaimRate into tUnifyClaimRate from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode;
      select InHosClaimRate into tInHosClaimRate from lldutyctrl where grpcontno=tGrpContNo and DutyCode=tDutyCode and ContType=tContType and ContPlanCode=tContPlanCode;
  end if;
  --????????????????
  if tExempt<>-1 then
  --?????????
     select nvl((select sum(outdutyamnt) from llclaimdutyfee where getdutycode='106201' and customerno=tCustomerNo and clmno in (select rgtno from llregister where grpcontno=tGrpContNo and clmstate='60') and clmno<>tCaseNo),0) into tsumexempt from dual;
     if tExempt<=tsumexempt then
         select tInHosJe_gf*tUnifyClaimRate into Result from dual;
     else
         select (tInHosJe_gf-least((tExempt-tsumexempt),tJe_gf))*tUnifyClaimRate into Result from dual;
     end if;
  else
  --??????????????????????
     if (tInHosJe_gf=0 or tInHosJe_gf=-1) then
     --??????????
         Result:=0;
      else
      --?????????
         select nvl((select sum(outdutyamnt) from llclaimdutyfee where getdutycode='106201' and customerno=tCustomerNo and clmno in (select rgtno from llregister where grpcontno=tGrpContNo and clmstate='60') and clmno<>tCaseNo),0) into tsumexempt from dual;
         if tInhosExempt<=tsumexempt then
             select tInHosJe_gf*tInHosClaimRate into Result from dual;
         else
             select (tInHosJe_gf-least((tInhosExempt-tsumexempt),tInHosJe_gf))*tInHosClaimRate into Result from dual;
         end if;
      end if;
  end if;
  if Result<0 then
      Result:=0;
  end if;
  return(Result);
end func_106claim;

/
