CREATE FUNCTION     "ADVANCEREARGRPPREMSUM" (
       tagentcode in VARCHAR2,
       tbranchcode in VARCHAR2,
       tbranchseries in varchar2,
       tempbegin in date,
       tempend in date) return number is
-------------------??????????????---------------------------
  ACODELOOP VARCHAR2(26);
  DSTANDPREM NUMBER;
  SUMSTANDPREM NUMBER;
begin
  ACODELOOP := substr(tbranchseries,1,25)||'%';
  DSTANDPREM := 0;
  SUMSTANDPREM := 0;

  --????????????
 select sum(nvl(standprem,0)) into SUMSTANDPREM  from lacommision
 where commdire='1' and p6=0 and branchcode=tbranchcode
 and tmakedate>=tempbegin and tmakedate<=tempend;


  --??????????????
  SELECT SUM(nvl(a.StandPrem,0)) INTO SUMSTANDPREM FROM lacommision a,larearrelation b
   WHERE a.branchcode=b.agentgroup and b.rearlevel='01' and b.rearagentcode=tagentcode
   and b.rearflag='1' and b.state='0' and (b.rearedgens=1 or b.rearedgens=2)
   and a.commdire='1' and a.p6=0 and a.tmakedate>=tempbegin and a.tmakedate<=tempend
   and a.branchseries like ACODELOOP;

  SUMSTANDPREM := SUMSTANDPREM + DSTANDPREM;
  return SUMSTANDPREM;
end AdvanceRearGrpPremSum;

/
