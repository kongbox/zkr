CREATE FUNCTION     "ACTUPAYASSESS" (tagentobj in varchar2, tstartdate in date,tenddate in date,tpaycount lacommision.paycount%type
,tflag in varchar2) return number is
  Result number(12,6):=0 ;
  --tflag=1 ?????=0 ????

begin


  if tflag = '1' then

        if tpaycount<4  then
           select nvl(sum(transMoney),0) into Result from LACommision where agentcode = tagentobj
           and PayCount=tpaycount and LastPayToDate>=tstartDate-60
           and lastpaytodate<=tenddate-60 and p6=1 and transtype<>'FX' and flag='0'
           and payintv<>-1 and commdire='1';--????????? ???????????
        else
           select nvl(sum(transMoney),0) into Result from LACommision where agentcode = tagentobj
           and PayCount>=tpaycount and LastPayToDate>=tstartDate-60
           and lastpaytodate<=tenddate-60 and p6=1 and transtype<>'FX' and flag='0'
           and payintv<>-1 and commdire='1';--?????????  ,
        end if;


   else--??

        if tpaycount<4  then
           select count(distinct(contno)) into Result from LACommision where agentcode = tagentobj
           and PayCount=tpaycount and LastPayToDate>=tstartDate-60  and commdire='1'
           and lastpaytodate<=tenddate-60 and p6=1 and transtype<>'FX' and flag='0' and payintv<>-1;--?????????
        else
           select count(distinct(contno)) into Result from LACommision where agentcode = tagentobj
           and PayCount>=tpaycount and LastPayToDate>=tstartDate-60  and commdire='1'
           and lastpaytodate<=tenddate-60 and p6=1 and transtype<>'FX' and flag='0' and payintv<>-1;--?????????
        end if;

   end if;
  return(Result);
end ActuPayAssess;

/
