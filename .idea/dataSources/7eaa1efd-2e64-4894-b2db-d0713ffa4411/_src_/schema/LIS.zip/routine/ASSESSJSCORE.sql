CREATE FUNCTION     "ASSESSJSCORE" (
       tAgentCode laagent.agentcode%Type,

       tIndexCalNo laindexinfo.indexcalno%Type,
       tBranchType laagent.branchtype%Type,
       tManageCom latree.managecom%Type
)
  return number is
  Result number;
  ---??????

  tAgentStartDate  Varchar2(6);
  tCount           Integer;
  tScore          Number(4,2);
begin
   select T1*0.3+T3*0.4+T4*0.1+T18*0.2 Into tScore from laindexinfo where indexcalno=tIndexCalNo and agentcode=tAgentCode and managecom=tManageCom and indextype='04';
     Select to_char(StartDate,'yyyymm') Into tAgentStartDate From latree Where agentcode=tAgentCode And branchtype=tBranchType and branchtype2='03';
       tCount:=months_between(to_date(tIndexCalNo,'yyyymm'),to_date(tAgentStartDate,'yyyymm'));
     If (tCount>=2) then
        if(tScore>180)then
           Result:=180;
        else
         Result:=tscore;
        end If;
     else
        Result:=70;
     End If;
  return(Result);
end AssessJScore;

/
