CREATE FUNCTION     "GETEDORCONTENT" (tEdorNo in lpedoritem.edorno%type) return varchar2 is
  Content varchar2(3000);
  tEdorAppDate   varchar2(20);
  tGrpContNo     varchar2(20);
  tGrpName       varchar2(120);
  tOperator      varchar2(20);
  tUWOperator    varchar2(20);
  tmakedate      varchar2(10);
  tEdorType      varchar2(2);
  tNo            int ;
  tEdorName      varchar2(120);
  tEdorValiDate  varchar2(10);
  tPeoples       varchar2(120);
  tMoney         varchar2(120);
  tSumMoney      int;
  tPayMode       varchar2(120);
  tBankCode      varchar2(120);
  tBankAccNo     varchar2(120);
  tBankAccName   varchar2(120);



  CURSOR c_LPGrpEdorItem IS
    select edortype,EdorValiDate from LPGrpEdorItem where 1=1 and edorno=tEdorNo
   ;

begin
   execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';

   select EdorAppDate,grpcontno,Operator,UWOperator,makedate
   into tEdorAppDate,tGrpContNo,tOperator,tUWOperator,tmakedate
   from lpgrpedormain where edorno=tEdorNo;
   tEdorAppDate:=substr(tEdorAppDate,1,4)||'?'||substr(tEdorAppDate,6,2)||'?'||substr(tEdorAppDate,9,2)||'?';

   select max(GrpName) into tGrpName from LCGrpCont where GrpContNo=tGrpContNo;

   Content:=tEdorNo||' ?  ?  ?  ? '||'????/??'||tGrpName||' ???'||tGrpContNo||' ??????'||tEdorAppDate||' ???'||tEdorNo;

   Content:=Content||' ?????/?'||tGrpName||'??,????????'||tGrpContNo||'??????????:';

   --Content:=Content||'?????????????????';
   tNo:=0;
   for c_LPGrpEdorItem_rec in c_LPGrpEdorItem LOOP
   EXIT WHEN c_LPGrpEdorItem%NOTFOUND;
     tNo:=tNo+1;

     tEdorType:=c_LPGrpEdorItem_rec.Edortype;
     --???
     select edorname into tEdorName from lmedoritem where appobj='G' and edorcode=tEdorType;
     --??
     select count(distinct contno) into tPeoples from lpedoritem  where edorno = tEdorNo and edortype = tEdorType;
     if tPeoples = '0' then
       tPeoples:='---';
     end if;
       --??
       select nvl(to_number(sum(getmoney)),0) into tMoney from ljagetendorse where endorsementno = tEdorNo and feeoperationtype = tEdorType;
       --tSumMoney:=tSumMoney+tMoney;
     if tMoney = '0' then
       tMoney:='---';
     end if;
     --????
     tEdorValiDate:=c_LPGrpEdorItem_rec.Edorvalidate;
     Content:=Content||'????'||tNo||'.'||tEdorName||'????'||tPeoples||'????'||tMoney||'?????'||tEdorValiDate;
     --Content:=Content||tNo||'.'||tEdorName||tPeoples||tMoney||tEdorValiDate;
   END LOOP;
   select nvl((select to_number(sum(getmoney)) from ljagetendorse where endorsementno=tEdorNo ),0.00) into tSumMoney from dual;
   if tSumMoney = 0 then
     tSumMoney:=0;
     --Content:=Content||tSumMoney;
   else
     if tSumMoney > 0 then
       select (select codename from ldcode where code=a.paymode and codetype='paymode'),a.inbankcode,a.inbankaccno,a.inaccname
       into tPayMode,tBankCode,tBankAccNo,tBankAccName
       from ljtempfeeclass a,ljtempfee b where a.tempfeeno=b.tempfeeno and a.managecom=b.managecom and b.otherno=tEdorNo
       and b.othernotype='10' and b.tempfeetype='4';
       if tPayMode = '??' then
         Content:=Content||'????????'||tSumMoney||'? ???? '||tPayMode;
       else
         Content:=Content||'????????'||tSumMoney||'? ???? '||tPayMode||'?????'||tBankAccName||'??'||tBankAccNo;
       end if;
     else
       tSumMoney:=-1*tSumMoney;
       Content:=Content||'????????'||tSumMoney||'?';
     end if;
   end if;
   Content:=Content||'????! ??????';
   Content:=Content||'???????:'||tOperator;
   Content:=Content||'???:'||tUWOperator;
   Content:=Content||'????:'||tmakedate;
   Content:=Content||'???/?????:';
   Content:=Content||'??????:';
   --select (select codename from ldcode where code=a.paymode and codetype='paymode'),a.inbankcode,a.inbankaccno,a.inaccname
   --from ljtempfeeclass a,ljtempfee b where a.tempfeeno=b.tempfeeno and a.managecom=b.managecom and b.otherno=tEdorNo
   --and b.othernotype='10' and b.tempfeetype='4';
   Content:=getStringbyBits(Content,300);

  return(Content);
end getEdorContent;

/
