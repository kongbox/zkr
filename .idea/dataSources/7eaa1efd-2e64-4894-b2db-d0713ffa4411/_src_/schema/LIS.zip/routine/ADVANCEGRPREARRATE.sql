CREATE FUNCTION     "ADVANCEGRPREARRATE" (
       tagentcode in VARCHAR2,
       tbranchcode in VARCHAR2,
       tbranchseries in VARCHAR2,
       tempbegin in date,
       tempend in date) return number is
-------------------????????????????---------------------------
  ACODELOOP VARCHAR2(26);
  GrpRearRate                  number(12,6):=0;
  PremUp                       number(12,6):=0;
  PremDown                     number(12,6):=0;
  countup                      number(12,6):=0;
  countdown                    number(12,6):=0;
  RearPremUp                   number(12,6):=0;
  RearPremDown                 number(12,6):=0;
  Rearcountup                  number(12,6):=0;
  Rearcountdown                number(12,6):=0;
  premupsum                    number(12,6):=0;
  premdownsum                  number(12,6):=0;
  countupsum                   number(12,6):=0;
  countdownsum                 number(12,6):=0;
  rate1                        number(12,6):=0;
  rate2                        number(12,6):=0;

begin
  ACODELOOP := substr(tbranchseries,1,25)||'%';

  ---??????(????)
  select nvl(sum(transmoney),0) into PremUp from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd;
---??????(????)
  select nvl(sum(transmoney),1)into PremDown from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and paycount=1 and flag='0' and not (payyears=1 and payintv=12) and payintv<>0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14);
---??????(????)
  select nvl(count(distinct mainpolno),0) into countup from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd;
---??????(????)
  select nvl(count(distinct mainpolno),1) into countdown from lacommision
  where branchcode=tbranchcode and commdire='1' and p6=0 and paycount=1 and flag='0'
  and not (payyears=1 and payintv=12) and payintv<>0 and cvalidate>=add_months(TempBegin,-14)
  and cvalidate<=add_months(TempEnd,-14);

  ---??????(????)
  select nvl(sum(a.transmoney),0) into RearPremUp from lacommision a
  where exists(select agentcode from larearrelation where agentcode=a.agentcode and
               rearagentcode=tagentcode and rearlevel='01'and agentgroup=a.branchcode
               and (rearedgens=1 or rearedgens=2) and rearcommflag='1' and state='0')
  and commdire='1' and p6=0 and branchseries like ACODELOOP
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd;
---??????(????)
  select nvl(sum(a.transmoney),0)into RearPremDown from lacommision a
  where exists(select agentcode from larearrelation where agentcode=a.agentcode and
               rearagentcode=tagentcode and rearlevel='01' and agentgroup=a.branchcode
               and (rearedgens=1 or rearedgens=2) and rearcommflag='1' and state='0')
  and commdire='1' and p6=0 and branchseries like ACODELOOP
  and paycount=1 and flag='0' and not (payyears=1 and payintv=12) and payintv<>0
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14);
---??????(????)
  select nvl(count(distinct a.mainpolno),0) into Rearcountup from lacommision a
  where exists(select agentcode from larearrelation where agentcode=a.agentcode and
               rearagentcode=tagentcode and rearlevel='01'and agentgroup=a.branchcode
               and (rearedgens=1 or rearedgens=2) and rearcommflag='1' and state='0')
  and commdire='1' and p6=0 and branchseries like ACODELOOP
  and cvalidate>=add_months(TempBegin,-14) and cvalidate<=add_months(TempEnd,-14)
  and not (payyears=1 and payintv=12) and payintv<>0 and paycount>=2 and flag='0'
  and tmakedate>=add_months(TempBegin,-2) and tmakedate<=TempEnd;
---??????(????)
  select nvl(count(distinct a.mainpolno),0) into Rearcountdown from lacommision a
  where exists(select agentcode from larearrelation where agentcode=a.agentcode and
               rearagentcode=tagentcode and rearlevel='01'and agentgroup=a.branchcode
               and (rearedgens=1 or rearedgens=2) and rearcommflag='1' and state='0')
  and commdire='1' and p6=0 and paycount=1 and flag='0' and branchseries like ACODELOOP
  and not (payyears=1 and payintv=12) and payintv<>0 and cvalidate>=add_months(TempBegin,-14)
  and cvalidate<=add_months(TempEnd,-14);

  premupsum:=RearPremUp+premup;
  premdownsum:=RearPremDown+premDown;
  countupsum:=Rearcountup+countup;
  countdownsum:=Rearcountdown+countdown;

  if premdownsum>0 then
     rate1:=premupsum/premdownsum;
  else
     rate1:=1;
  end if;
  if countdownsum>0 then
     rate2:=countupsum/countdownsum;
  else
     rate2:=1;
  end if;

  GrpRearRate:=Round((rate1*0.5+rate2*0.5),2);

  return GrpRearRate;
end AdvanceGrpRearRate;

/
