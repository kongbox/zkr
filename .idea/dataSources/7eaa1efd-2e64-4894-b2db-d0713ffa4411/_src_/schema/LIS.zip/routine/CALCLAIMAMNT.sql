CREATE function     CalClaimAmnt(tClmNo in varchar2,
                                          tPolNo in varchar2,
                                          tRiskCode in varchar2,
                                          tDutyCode in varchar2,
                                          tGetDutyCode in varchar2,
                                          tGetDutykind in varchar2)
  return number is
  Result number;
  dutycode_s varchar2(6);
  dutycode_c varchar2(6);
  getdutycode_s varchar2(6);
  getdutycode_c varchar2(6);
  standmoney_s number;
  standmoney_c number;
  paymoney_s number;
  paymoney_c number;
begin
-----------该function主要是计算理算前实际保额
-----------新残标产品：40041411、70041411、40041412三款产品是残疾和身故共用身故的保额
if(tRiskCode='40041411' or tRiskCode='70041411' or tRiskCode='40041412') then
     ------ 以 40041411为例，身故、残疾共用身故的保额
     ------ 身故的保额 ：身故责任剩余保额 - 残疾责任的赔付)
     ------ 残疾的保额 min(残疾责任的剩余保额，身故责任的剩余保额-残疾责任的累计赔付)
     if(tGetDutyCode='902942' or tGetDutyCode='702442' or tGetDutyCode='903042') then
                ------残疾给付责任的保额
                select standmoney into standmoney_c  from lcget where polno = tPolNo and dutycode = tDutyCode and getdutycode = tGetDutyCode;
                ------残疾给付责任的累计赔付
                select summoney into paymoney_c  from lcget where polno = tPolNo and dutycode = tDutyCode and getdutycode = tGetDutyCode;
                ------身故责任
                select dutycode into dutycode_s from lmriskduty where riskcode=tRiskCode and dutycode <> tDutyCode;
                ------身故给付责任
                select getdutycode into getdutycode_s from lmdutygetrela where dutycode = dutycode_s;
                ------身故给付责任的剩余保额
                select (standmoney - summoney) into standmoney_s from lcget where polno = tPolNo and dutycode = dutycode_s and getdutycode =getdutycode_s ;
                ----共用保额取最小值
                if((standmoney_s - paymoney_c) >= (standmoney_c -paymoney_c)) then
                       Result := standmoney_c -paymoney_c;
                else
                       Result := standmoney_s - paymoney_c;
                end if;
     else
                ------身故给付责任的保额
                select standmoney into standmoney_s  from lcget where polno = tPolNo and dutycode = tDutyCode and getdutycode = tGetDutyCode;
                ------身故给付责任的累计赔付
                select summoney into paymoney_s  from lcget where polno = tPolNo and dutycode = tDutyCode and getdutycode = tGetDutyCode;
                ------残疾责任
                select dutycode into dutycode_c from lmriskduty where riskcode=tRiskCode and dutycode <> tDutyCode;
                ------残疾给付责任
                select getdutycode into getdutycode_c from lmdutygetrela where dutycode = dutycode_c;
                ------残疾给付责任的当前累计赔付
                select sum(summoney) into paymoney_c  from lcget where polno = tPolNo and dutycode = dutycode_c and getdutycode = getdutycode_c ;

                Result := standmoney_s - paymoney_s - paymoney_c;
     end if;
else
     select (standmoney - summoney) into Result from lcget where polno = tPolNo and dutycode = tDutyCode and getdutycode = tGetDutyCode;
end if;

   if(Result<0) then
        Result := 0;
   end if;
  return(Result);
end CalClaimAmnt;

/
