CREATE FUNCTION "AA_BQ0038" (tedorvalidate in date,tedorno in varchar2, tpolno in varchar2, tinsuredno in varchar2) return number is
  Result number;
  triskcode varchar2(3);
  toldamnt number;
  tincreamnt number;
  ainsuredamnt number;
  tcount integer;
  tinsuredage number;
  tbirthday date;
  tgrpcontno varchar2(14);
begin
  Result:=0;
  select grpcontno into tgrpcontno from lcpol where polno=tpolno;
  select riskcode into triskcode from lppol where edorno=tedorno and polno=tpolno and edortype='AA';
  if triskcode='182' then
     select peoples2 into tcount from lcgrppol where grpcontno=tgrpcontno and riskcode='182';
     select birthday into tbirthday from lcinsured where grpcontno=tgrpcontno and insuredno=tinsuredno;
     select floor(months_between(tedorvalidate,tbirthday)) into tinsuredage from dual;
     select sum(amnt) into toldamnt from lcpol where riskcode='182' and insuredno=tinsuredno and polstate='1';
     select chgamnt into tincreamnt from lpedoritem where edorno =tedorno and polno=tpolno and edortype='AA';
     ainsuredamnt:=tincreamnt+toldamnt;
     if tcount<=25 then
          if tinsuredage>=192 and tinsuredage<612 then
              if ainsuredamnt>100000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>50000 then
                   Result:=1;
              end if;
          end if;
      elsif tcount>=26 and tcount<=50 then
          if tinsuredage>=192 and tinsuredage<612 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>100000 then
                   Result:=1;
              end if;
          end if;
      elsif tcount>=51 and tcount<=200 then
          if tinsuredage>=192 and tinsuredage<492 then
              if ainsuredamnt>300000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=492 and tinsuredage<612 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>100000 then
                   Result:=1;
              end if;
          end if;
       elsif tcount>=201 then
          if tinsuredage>=192 and tinsuredage<492 then
              if ainsuredamnt>400000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=492 and tinsuredage<612 then
              if ainsuredamnt>300000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          end if;
        end if;
  end if;
  if triskcode='181' then
     select peoples2 into tcount from lcgrppol where grpcontno=tgrpcontno and riskcode='181';
     select birthday into tbirthday from lcinsured where grpcontno=tgrpcontno and insuredno=tinsuredno;
     select floor(months_between(tedorvalidate,tbirthday)) into tinsuredage from dual;
     select sum(amnt) into toldamnt from lcpol where riskcode='182' and insuredno=tinsuredno and polstate='1';
     select chgamnt into tincreamnt from lpedoritem where edorno =tedorno and polno=tpolno and edortype='AA';
     ainsuredamnt:=tincreamnt+toldamnt;
     if tcount<=25 then
          if tinsuredage>=192 and tinsuredage<492 then
              if ainsuredamnt>300000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=492 and tinsuredage<612 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>100000 then
                   Result:=1;
              end if;
          end if;
      elsif tcount>=26 and tcount<=50 then
          if tinsuredage>=192 and tinsuredage<492 then
              if ainsuredamnt>400000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=492 and tinsuredage<612 then
              if ainsuredamnt>300000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>100000 then
                   Result:=1;
              end if;
          end if;
      elsif tcount>=51 and tcount<=200 then
          if tinsuredage>=192 and tinsuredage<492 then
              if ainsuredamnt>500000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=492 and tinsuredage<612 then
              if ainsuredamnt>400000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          end if;
       elsif tcount>=201 then
          if tinsuredage>=192 and tinsuredage<612 then
              if ainsuredamnt>500000 then
                   Result:=1;
              end if;
          elsif tinsuredage>=612 and tinsuredage<792 then
              if ainsuredamnt>200000 then
                   Result:=1;
              end if;
          end if;
        end if;
  end if;
  return(Result);
end AA_BQ0038;

/
