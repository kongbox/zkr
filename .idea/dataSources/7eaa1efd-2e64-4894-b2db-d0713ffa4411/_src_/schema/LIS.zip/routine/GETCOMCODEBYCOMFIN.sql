CREATE FUNCTION     "GETCOMCODEBYCOMFIN" (tComCodeFin in varchar2) return LFComToFinCom.ComCode%type
as
tComCode LFFinXml.ComCode%type;
begin
select ComCode into tComCode from LFComToFinCom where trim(ComCodeFin)= trim(tComCodeFin);
return(tComCode);
end;

/
