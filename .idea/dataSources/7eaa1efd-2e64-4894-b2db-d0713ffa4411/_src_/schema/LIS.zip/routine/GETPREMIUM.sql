CREATE FUNCTION     "GETPREMIUM" (tGrpContNo in varchar2)
return number is
tPrem number;--?????
Result number;--????
begin
       SELECT NVL(SUM(NVL(sumactupaymoney,0)),0) INTO tPrem FROM ljapaygrp WHERE paytype='ZC' AND paycount=1 AND grpcontno=tGrpContNo;
       Result := tPrem;
return(Result);
end getPREMIUM;

/
