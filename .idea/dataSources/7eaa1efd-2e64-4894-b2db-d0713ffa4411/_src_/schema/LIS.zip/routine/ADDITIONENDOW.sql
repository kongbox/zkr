CREATE FUNCTION     "ADDITIONENDOW" (tagentcode in varchar2, tempend in date, tindexcalno in varchar2) return number is
  Result number(12,4):=0;
  cEmplydate date;
begin
--??????????
 select employdate into cEmplydate from laagent where agentcode=tagentcode;
 if months_between(tempend+1,cEmplydate)<12 then
    return Result;
 end if;
  select (select nvl(StartCareerRwd,0) from laindexinfo
  where indexcalno=tindexcalno and indextype='01' and agentcode=tagentcode and branchtype='4'
  and branchtype2='01')* (select nvl(sum(drawrate),1)  from lawelfareradix
  where objectcode=tagentcode and aclass='05' and state='1' and beginym<=tindexcalno ) into Result from ldsysvar where sysvar='onerow';
  return(Result);
end AdditionEndow;

/
