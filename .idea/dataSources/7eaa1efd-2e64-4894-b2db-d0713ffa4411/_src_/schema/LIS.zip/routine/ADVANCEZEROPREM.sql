CREATE FUNCTION     "ADVANCEZEROPREM" (
       tagentcode in VARCHAR2,
       tempbegin in date,
       tempend in date) RETURN INTEGER IS
-----------------????????????-----------------
  ZEROMONCOUNT INTEGER;
  DIRWAGE NUMBER(12,6):=0;
  COMPAREDATE date;
  startdate   date;
BEGIN

  ZEROMONCOUNT := 0;
  startdate:=tempbegin;
  Comparedate:=add_months(startdate,1);

  WHILE Comparedate<=tempend loop
    ---???????
    SELECT sum(nvl(standprem,0)) INTO DIRWAGE FROM lacommision
     WHERE agentcode=tagentcode and commdire='1' and p6=0 and
     tmakedate >=startdate and tmakedate<=Comparedate;
    IF DIRWAGE > 0 THEN
      ZEROMONCOUNT := 0;
    ELSE
      ZEROMONCOUNT := ZEROMONCOUNT + 1;  --????
    END IF;
    startdate:=add_months(startdate,1);
    Comparedate:=add_months(startdate,1);
  END LOOP;
  RETURN ZEROMONCOUNT;
END AdvanceZeroPrem;

/
