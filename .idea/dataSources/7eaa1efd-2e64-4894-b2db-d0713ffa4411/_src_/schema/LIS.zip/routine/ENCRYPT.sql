CREATE FUNCTION     "ENCRYPT" (tWage in varchar2) --????
       return char is
  middle number(15,2) ;
  Result char(16);
begin
  middle:=to_number(tWage);
  middle:=10000000000000-(middle+8351)*1743;
  Result:=to_char(middle);
  Result:=replace(Result,'0','M');
  Result:=replace(Result,'1','P');
  Result:=replace(Result,'2','C');
  Result:=replace(Result,'3','F');
  Result:=replace(Result,'4','Z');
  Result:=replace(Result,'5','Q');
  Result:=replace(Result,'6','H');
  Result:=replace(Result,'7','R');
  Result:=replace(Result,'8','A');
  Result:=replace(Result,'9','S');
  Result:=replace(Result,'.','V');
  Result:=replace(Result,'SSSS','GNWD');
  Result:=replace(Result,'   ','LYJ');
  Result:=replace(Result,' ','B');
  return(Result);
end encrypt;

/
