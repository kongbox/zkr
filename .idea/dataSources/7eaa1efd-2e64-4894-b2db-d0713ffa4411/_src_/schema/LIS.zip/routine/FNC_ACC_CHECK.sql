CREATE function fnc_acc_check(tRiskCode  in varchar,
                                      tAcceptno     in varchar,
                                      tYear         in int) return number is
  --Create by wujiang
  --参数说明
  /**
  tAcceptno ：受理号 ;  tRiskCode : 险种编码 tYear :多年期对应的第几年限
  **/
  --对应保费
  tPrem     number; --总保费
  tPremn    number; --对应第几年的保费
  tMultiYears         int;  --年期
  tAgeLimit           int;  --总年限

  str_sql     varchar2(1000); --绑定变量查询
  tsql        varchar2(1000); --查询对应的保费
  begin

  -------初始化
  tPrem         :=0;
  tPremn       :=0;


         -------年期查询------
      str_sql := 'select MultiYears from lccollectionpol where acceptno=:v_acceptno and riskcode =:v_riskcode';
      execute immediate str_sql
        into tMultiYears
        using tAcceptno, tRiskCode;
        --------总保费的查询-------
        str_sql :='select sum(to_number(d.p12)) from lcpol a, lccollectioncontstate b, lmriskapp c, lcpolother d
         where a.contno =: b.contno and b.acceptno =: l.acceptno and a.riskcode =: c.riskcode and a.polno =: d.polno
         and a.riskcode =: v_riskcode and  a.acceptno=:v_acceptno';
          execute immediate str_sql
        into tPrem
        using tAcceptno, tRiskCode;
        ---------对应年限的保费---------
         tsql := 'select sum(prem) from lcpol where contno in (select contno from lccollectioncontstate where acceptno = v_acceptno)
            and riskcode = v_riskcode';
            execute immediate tsql
            into tPremn
            using tAcceptno, tRiskCode;
       ------利用年期判断年限----------------
     if mod(tMultiYears,12)>0 then --多年期有零头月
        tAgeLimit :=floor(tMultiYears/12);--向下取整
        if tYear>tAgeLimit and (tYear-tAgeLimit)!=1 then--当输入的年度大于年期且不只是大于一年，清单中保费设为null
           tPremn := null;
        else --否则查询出保费
            if (tYear-tAgeLimit)=1 then --零头月的保费为总保费减去前面几年的保费
           tPremn := tPrem - tPremn*tAgeLimit;
           end if;
        end if;
     end if;
     if mod(tMultiYears,12)=0 then
        tAgeLimit :=tMultiYears/12;--计算出预交年限
        if tYear>tAgeLimit then --如果传入的年度大于预交年限，保费为null
           tPremn := null;
        end if;
     end if;

return (tPremn);
end fnc_acc_check;
/
