CREATE FUNCTION     "FUNC_110_STANDARD" (Je_gf in number) return number is
  Result number;
  tJe_gf number;
begin
  tJe_gf:=Je_gf;
  if tJe_gf<=500 then
    select 0 into Result from dual;
  elsif tJe_gf>=500 and tJe_gf<=5000 then
    select (tJe_gf-500)*0.6 into Result from dual;
  elsif tJe_gf>5000 and tJe_gf<=20000 then
    select 2700+(tJe_gf-5000)*0.7 into Result from dual;
  elsif tJe_gf>20000 and tJe_gf<=50000 then
    select 13200+(tJe_gf-20000)*0.8 into Result from dual;
  elsif tJe_gf>50000 and tJe_gf<=100000 then
    select 37200+(tJe_gf-50000)*0.9 into Result from dual;
  else
    select 82200 into Result from dual;
  end if;
  return(Result);
end func_110_standard;

/
