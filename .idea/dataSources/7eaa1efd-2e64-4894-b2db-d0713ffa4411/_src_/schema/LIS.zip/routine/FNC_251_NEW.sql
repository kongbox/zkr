CREATE function fnc_251_new(tAcceptnoIn   in char,
                                      tDutyCode     in lccontplandutyparam.dutycode%Type,
                                      tContPlanCode in char,
                                      tAmnt         in NUMBER,
                                      tVPU          in NUMBER,
                                      tCalType      in char,
                                      tPolno        in char) return number is
  --Create by wujiang
  --参数说明
  /**
  tAcceptno ：受理号 ;  tDutyCode ；责任编码 ； tVPN ： vpn ; tContPlanCode :保险计划编码 ;
  tCalType:保全处理标志   tPolno : 保全处理时，以polno查询acceptno
  **/
  --对应保费
  tPrem     number; --保费返回值
  tPrem1    number; --保额小于2000
  tPrem2    number; --保额大于2000
  tBasePrem number; --基准费率

  tRateMode         char; --费率模式标志
  tSocInsuGetRate   number; --赔付比例
  tSocInsuGetLimit  number; --免陪额

  tSGetLimitCoe  number; -- 免陪额调整系数
  tSGetRateCoe   number; -- 赔付比例调整系数
  tAmntCoe       number; -- 保额调整系数

  str_sql         varchar2(1000); --绑定变量查询
  tFlag       char(1); ---低于2000部分的保额来源标志，0代表首2000,1代表保额大于2000中2000以下的部分

  begin

  -------初始化
  tBasePrem     :=0;
  tPrem         :=0;
  tPrem1        :=0;
  tPrem2        :=0;
  tFlag         :='0';
         -------赔付比例------
      str_sql := 'select  to_number(nvl((select calfactorvalue from lcclctpolplanparam where acceptno=:v_acceptno ' ||
                 'and contplancode=:v_contplancode and  dutycode=:v_dutycode and calfactor=:v_factor),''0'')) from dual';
      execute immediate str_sql
        into tSocInsuGetRate
        using tAcceptnoIn, tContPlanCode, tDutyCode, 'GetRate';
        --------赔付比例调整系数-------
        if tSocInsuGetRate = 0.70 or tSocInsuGetRate = 0.7 then
          tSocInsuGetRate := 0.69;
        end if;
        if tSocInsuGetRate = 0.60 or tSocInsuGetRate = 0.6 then
          tSocInsuGetRate := 0.58;
        end if;
        if tSocInsuGetRate = 0.50 or tSocInsuGetRate = 0.5 then
          tSocInsuGetRate := 0.47;
        end if;
        tSGetRateCoe := tSocInsuGetRate;
  ------保险金额大于2000----------------
  if tAmnt > 2000 then
     tFlag :='1';
       -------费率计算模式--------
     str_sql := 'select ssflag from lcclctcontplan where acceptno=:v_acceptno and contplancode=:v_contplancode and plantype=''0''';
     execute immediate str_sql
     into tRateMode
     using tAcceptnoIn, tContPlanCode;
     if tRateMode = '1' then
             -------有社保基准费率------------
         tBasePrem := (tAmnt-2000)/1000*0.50;
     end if;
             --------无社保基准费率-----------
     if tRateMode = '2' then
          tBasePrem := (tAmnt-2000)/1000*0.80;
     end if;
         --------免赔额---------
     str_sql := 'select  to_number(nvl((select calfactorvalue from lcclctpolplanparam where acceptno=:v_acceptno ' ||
           'and contplancode=:v_contplancode and  dutycode=:v_dutycode and calfactor=:v_factor),''0'')) from dual';
     execute immediate str_sql
     into tSocInsuGetLimit
     using tAcceptnoIn, tContPlanCode, tDutyCode, 'GetLimit';
        --------免赔额调整系数---------
     str_sql := 'select rate from rt_251_getlimit e where e.getlimit= (select  max(c.getlimit) from rt_251_getlimit c where :v_getlimit >= c.getlimit)';
         execute immediate str_sql
     into tSGetLimitCoe
      using tSocInsuGetLimit;
        tPrem2 := tBasePrem * tSGetLimitCoe * tSGetRateCoe;
  end if;


  if tFlag = '0' then
         -------费率计算模式--------
       str_sql := 'select ssflag from lcclctcontplan where acceptno=:v_acceptno and contplancode=:v_contplancode and plantype=''0''';
       execute immediate str_sql
       into tRateMode
        using tAcceptnoIn, tContPlanCode;
        -------根据费率模式来选择计算方法,tRateMode  = 1; 有社保
        if tRateMode = '1' then
             -------有社保基准费率------------
             tBasePrem := 8.14*(tAmnt/1000);
            end if;
             --------无社保基准费率-----------
        if tRateMode = '2' then
            tBasePrem := 9.62*(tAmnt/1000);
            end if;
        --------免赔额---------
         str_sql := 'select  to_number(nvl((select calfactorvalue from lcclctpolplanparam where acceptno=:v_acceptno ' ||
               'and contplancode=:v_contplancode and  dutycode=:v_dutycode and calfactor=:v_factor),''0'')) from dual';
         execute immediate str_sql
         into tSocInsuGetLimit
         using tAcceptnoIn, tContPlanCode, tDutyCode, 'GetLimit';
         --------免赔额调整系数---------
         str_sql := 'select rate from rt_251_getlimit e where e.getlimit= (select max(c.getlimit) from rt_251_getlimit c where :v_getlimit >= c.getlimit)';
         execute immediate str_sql
      into tSGetLimitCoe
      using tSocInsuGetLimit;
      tPrem1 := tBasePrem * tSGetLimitCoe * tSGetRateCoe;
      tPrem :=  tPrem1 + tPrem2;
   end if;
   if tFlag= '1'  then
             -------费率计算模式--------
             str_sql := 'select ssflag from lcclctcontplan where acceptno=:v_acceptno and contplancode=:v_contplancode and plantype=''0''';
            execute immediate str_sql
            into tRateMode
            using tAcceptnoIn, tContPlanCode;
           if tRateMode = '1' then
             -------有社保基准费率------------
             tBasePrem := 8.14*(2000/1000);--大于2000的部分按1.1计算
           end if;
             --------无社保基准费率-----------
           if tRateMode = '2' then
            tBasePrem := 9.62*(2000/1000); ---大于2000的部分按1.32计算
           end if;
            --------免赔额---------
         str_sql := 'select  to_number(nvl((select calfactorvalue from lcclctpolplanparam where acceptno=:v_acceptno ' ||
               'and contplancode=:v_contplancode and  dutycode=:v_dutycode and calfactor=:v_factor),''0'')) from dual';
         execute immediate str_sql
         into tSocInsuGetLimit
         using tAcceptnoIn, tContPlanCode, tDutyCode, 'GetLimit';
         --------免赔额调整系数---------
         str_sql := 'select rate from rt_251_getlimit e where e.getlimit= (select max(c.getlimit) from rt_251_getlimit c where :v_getlimit >= c.getlimit)';
         execute immediate str_sql
      into tSGetLimitCoe
      using tSocInsuGetLimit;
        tPrem1 := tBasePrem * tSGetLimitCoe * tSGetRateCoe;
        tPrem := tPrem1 + tPrem2;
    end if;
return (tPrem);
end fnc_251_new;

/
