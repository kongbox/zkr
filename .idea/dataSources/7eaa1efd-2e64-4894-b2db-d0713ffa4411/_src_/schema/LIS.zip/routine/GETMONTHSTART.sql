CREATE FUNCTION     "GETMONTHSTART" (StartDate in date, intvl in integer,tStatType in varchar2) return date is
  tTempDate date;
  tNewDate  varchar2(10);
  tIntvl    integer:=0;

  Result    date;
begin
  tIntvl := intvl;
  tTempDate := add_months(StartDate,tIntvl);
  --select StartDate into tNewDate from LAStatSegment where startdate<=tTempDate and tTempDate<=EndDate and StatType= trim(tStatType);
  tNewDate := to_char(trunc(tTempDate,'mm'),'yyyy-mm-dd');
  Result := to_date(tNewDate,'yyyy-mm-dd');

  return(Result);
end getMonthStart;

/
