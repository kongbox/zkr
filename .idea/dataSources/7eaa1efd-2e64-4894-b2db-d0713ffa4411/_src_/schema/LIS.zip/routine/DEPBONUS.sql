CREATE FUNCTION     "DEPBONUS" (tagentcode in varchar2,tagentgrade in varchar2,
                                     twageno in varchar, tareatype in varchar,
                                     twagecode in varchar2,tbranchtype lawageradix.branchtype%type,
                                     tbranchtype2 in varchar2,tRearType lawageradix.reartype%type,TempEnd in date,
                                     tConnManagerState in varchar2,tAgentState in varchar2) return number is

  ---?????,??????
    ---tRearType='1'     ????
    ---tRearType='2'     ????

DepBonus                number(20,6):=0 ;
cdrawrate               lawageradix.drawrate%type;
cDepFYCSum              number(20,6):=0 ;
SingleBonus             number(20,6):=0 ;
cconnmanagerstate       latree.connmanagerstate%type;
cyear                   lawageradix.drawstart%type;
cstartdate              date;
crearstartyear          larearrelation.rearstartyear%type;
cagentcode              varchar2(30);
crearedgens             integer;
/*cED                     varchar2(8);
ED                      date;*/
begin
  ---??(agentstate=0)?10????????(agentstate=-1)???
     if tAgentState in ('-1','0') then
        return 0;
     end if;

   /*---???A301????10??????????????
     if tagentgrade='A301' then
        select employdate into ED from laagent where agentcode=tagentcode;
        cED:=to_char(ED,'yyyymmdd');
        if substr(cED,7,2)>'10' and twageno=substr(cED,1,6) then
           return 0;
        end if;
     end if;*/

  declare
  cursor c_rearrate is

  select a.startdate,a.rearstartyear,a.agentcode,b.connmanagerstate,a.rearedgens from larearrelation a,latree b
  where trim(rearagentcode)=tagentcode and a.agentcode=b.agentcode
  and a.rearedgens=tRearType and a.rearlevel='02' and a.rearcommflag='1' and a.state='0'
  and b.connmanagerstate<>'1' and b.connmanagerstate<>'2';


  begin
    open c_rearrate;
      loop
       fetch c_rearrate into cstartdate,crearstartyear,cagentcode,cconnmanagerstate,crearedgens;
       exit when c_rearrate%notfound;
        SingleBonus:=0;
        ---??????????
        cDepFYCSum:=0;
        select nvl(DepFYCSum,0) into cDepFYCSum from laindexinfo
        where agentcode=cagentcode and indextype='00' and indexcalno=twageno  and branchtype='1' and branchtype2='01';

        if cDepFYCSum<>0 then
        ---??????
          if crearstartyear=1 then
           cyear:=GetMonths(cstartdate,TempEnd);
           if cyear<=12 then
           cyear:=1;
           else
                if cyear>12 and cyear<=24
                then cyear:=2;
                else cyear:=3;
                end if;
           end if;
          else
           cyear:=2;
          end if;
      end if;
   ---???????
    select drawrate into cdrawrate from lawageradix
    where branchtype=tbranchtype and branchtype2=tbranchtype2
    and agentgrade=tagentgrade and areatype=tareatype and wagecode=twagecode
    and reartype=treartype and cyear>drawstart and cyear<=drawend;
      if crearedgens=2 and crearstartyear>1 then
         SingleBonus:=0;
      end if;

      if (tconnmanagerstate='0' or tconnmanagerstate='4')
          and (cconnmanagerstate='0' or cconnmanagerstate='4') then
        SingleBonus:=cDepFYCSum*cdrawrate;
     elsif  tconnmanagerstate='3' or cconnmanagerstate='3'
        or ( tconnmanagerstate='3' and cconnmanagerstate='3') then
           SingleBonus:=cDepFYCSum*cdrawrate*0.5;

     end if;
     DepBonus:=DepBonus+SingleBonus;

   end loop;
   close c_rearrate;
  end ;
 /* if tconnmanagerstate='3' then
     DepBonus:=0.5*DepBonus;
  end if;*/
  return (DepBonus);
 end DepBonus;

/
