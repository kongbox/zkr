CREATE function getLcBnfNameDes(bnfname varchar2)
  return varchar2 is
  Result        varchar2(50);
    flag        varchar(10);
begin
if bnfname like '%法定%' THEN
      flag:= '0';
 elsif bnfname like '%特别约定%' THEN
      flag:= '0';
 elsif lengthb(bnfname)>= length(bnfname) AND lengthb(bnfname)- length(bnfname)>=5 THEN 
        flag:= '0';
       ELSE
        flag:= '1'; 
    END if;
  Result :=flag;
  return(Result);
end getLcBnfNameDes;
/
