CREATE FUNCTION     "CREATEMAXNO" (cNoType in ldmaxno.notype%type,
                                       cNoLimit in ldmaxno.nolimit%type)
 return integer is
 pragma autonomous_transaction;
 tMaxNo integer := 0;  --??????

begin

    --????1
    update LDMaxNo set MaxNo = MaxNo+1 where NoType = cNoType and NoLimit = cNoLimit
    Returning MaxNo Into tMaxNo; --?????

    If(Sql%Notfound) then  --?????????????? 1 ???
       Insert Into LDMaxNo (NOTYPE,NOLIMIT,MAXNO) values(cNoType,cNoLimit,1) ;
       tMaxNo := 1;
     End If ;
     commit;
  return(tMaxNo); --????
end CreateMaxNo;

/
