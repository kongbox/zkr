CREATE FUNCTION     "GETPRICE" (tRiskCode in varchar2,tInsuAccNo in varchar2,tPriceDate in Date,tFlag in varchar2) return Number is


   tSellPrice number(12,8):=0;
   tBuyPrice number(12,8):=0;
   tUnitCount Lcinsureaccclass.Unitcount%Type;
   tActuPriceDate date; --?????
   tCount integer;
begin

   tActuPriceDate := getNextStartDate(tRiskCode,tInsuAccNo,tPriceDate);

   Select count(*) into tCount from LOAccUnitPrice where InsuAccNo=tInsuAccNo and riskcode=tRiskCode and  StartDate =tActuPriceDate and state='0';

   if tCount =0 then
   return 0;
   end if;

   Select UnitPriceBuy,UnitPriceSell into tBuyPrice,tSellPrice from LOAccUnitPrice where InsuAccNo=tInsuAccNo and riskcode=tRiskCode and  StartDate =tActuPriceDate and state='0';

   if tFlag ='1' then --????
   if tSellPrice is null then

      tSellPrice :=0;

   end if;
    return     tSellPrice;
      --return round(tSellPrice,4);
   end if;

  if tFlag ='2' then --????
   if tBuyPrice is null then

      tBuyPrice :=0;

   end if;
   return tBuyPrice;
      --return round(tBuyPrice,4);
   end if;

END;

/
