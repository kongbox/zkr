CREATE FUNCTION     "CURRMONEY" (tagentcode in varchar2, twageno in varchar2) return number  is
  currmoney   number(20,6) := 0;
  ownmoney    number(20,6):=0;
  lastmonth   varchar2(6);
  ---????(????)
begin
  select nvl(T27,0)-nvl(T8,0)-nvl(T49,0)-nvl(T17,0)-nvl(T18,0)-nvl(T19,0)
         -nvl(T20,0)-nvl(T23,0)-nvl(T65,0)-nvl(T66,0) into currmoney
  from laindexinfo where agentcode=tagentcode and indexcalno=twageno and indextype='01'  and branchtype='1' and branchtype2='01';
  --????????
 lastmonth:=to_char(add_months(to_date((substr(twageno,1,4)||'-'||substr(twageno,5,2)||'-01'),'yyyy-mm-dd'),-1),'yyyymm');
 select nvl(sum(T73),0) into ownmoney from laindexinfo
 where agentcode=tagentcode and indextype='01'
 and branchtype='1' and branchtype2='01' and indexcalno=lastmonth;
 currmoney:=currmoney+ownmoney;
  return(currmoney);
end CurrMoney;

/
