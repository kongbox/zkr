CREATE FUNCTION     "CALBACKDEPLABOR" (tagentcode in varchar2,
                                           tagentgrade in varchar2,
                                           tdestagentgrade in varchar2,
                                           tareatype in varchar2,
                                           tassesstype in varchar2,
                                           twagenobegin in varchar2,
                                           twagenoend in varchar2) return number is
----------------------------????????-------------------------------------------
n   integer;
cagentcode varchar2(20);
cstartdate   date;
startmonth  varchar2(6);
num         integer;
monthnum    integer;
begindate   date;
enddate     date;

backlabor   number(20,6):=0 ;
cdirteamfycsum   number(20,6):=0 ;


begin
  ---??????????
  if tagentgrade<='A203' then
     return 0;
  end if;
  n:=0;
  num:=0;
  monthnum:=0;

  Declare
  cursor c_backlabor is
    ---?????????????
    select a.agentcode,a.startdate from larearrelation a where
    exists (select agentcode from latree where agentcode=a.agentcode and initgrade<>'A201' and initgrade<>'A301')
    and trim(a.rearagentcode)=tagentcode and a.rearlevel='02'
    and a.rearedgens=1 and a.rearflag='1'
    group by a.agentcode;

    begin
      open c_backlabor;
        loop
          fetch c_backlabor into cagentcode,cstartdate;
          exit when c_backlabor%notfound;


               n:=0;
               cdirteamfycsum:=0;
               startmonth:=to_char(add_months(cstartdate,-1),'yyyymm');
                ---???????????????????????
                 select count(*) into num from laassessaccessory
                 where branchtype='1' and branchtype2='01'
                 and assesstype='00' and indexcalno=startmonth
                 and agentcode=tagentcode;

                 if num=0 then
                    if twagenobegin<=startmonth then
                       select sum(nvl(DRTeamCount,0)) into num from laindexinfo
                       where indextype='00' and indexcalno>=startmonth and indexcalno<=twagenoend
                       and branchtype='1' and branchtype2='01'
                       and agentcode=cagentcode;
                       if num is null then
                          num:=0;
                       end if;
                       ---????
                       begindate:=to_date(concat(startmonth,'01'),'yyyy-mm-dd');
                       enddate:=to_date(concat(twagenoend,'01'),'yyyy-mm-dd');
                       monthnum:=months_between(enddate,begindate);
                       ---????
                       cdirteamfycsum:=1;
                   elsif twagenobegin>startmonth then
                         select sum(nvl(DRTeamCount,0)) into num from laindexinfo
                         where indextype='00' and indexcalno>=twagenobegin and indexcalno<=twagenoend
                         and branchtype='1' and branchtype2='01'
                         and agentcode=cagentcode;
                         if num is null then
                            num:=0;
                         end if;
                         ---????
                         begindate:=to_date(concat(twagenobegin,'01'),'yyyy-mm-dd');
                         enddate:=to_date(concat(twagenoend,'01'),'yyyy-mm-dd');
                         monthnum:=months_between(enddate,begindate);
                         ---????
                         select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                         where agentgrade=tagentgrade and assesscode =tassesstype
                         and areatype =tareatype and destagentGrade =tdestagentgrade;
                   end if;
                 elsif num>0 then
                       select sum(nvl(DRTeamCount,0)) into num from laindexinfo
                       where indextype='00' and indexcalno>=twagenobegin and indexcalno<=twagenoend
                       and branchtype='1' and branchtype2='01'
                       and agentcode=cagentcode;
                       if  num is null then
                           num:=0;
                       end if;
                       if twagenobegin=startmonth then
                          ---?????????
                          cdirteamfycsum:=1;
                       elsif twagenobegin>startmonth then
                             ---?????????
                             select nvl(dirteamfycsum,0) into cdirteamfycsum  from laagentpromradix
                             where agentgrade=tagentgrade and assesscode =tassesstype
                             and areatype =tareatype and destagentGrade =tdestagentgrade;
                      end if;
                end if;

                if num/monthnum>=1 then
                   n:=n+1;
                end if;
           backlabor:=backlabor+n*cdirteamfycsum;
        end loop;
      close c_backlabor;
   end;
  return(backlabor);
end calbackdeplabor;

/
